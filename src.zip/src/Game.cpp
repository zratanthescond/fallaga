#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <GL/glut.h>
#include "Game.h"
#include "Character.h"
#include "Camera.h"
#include "Terrain.h"
#include "Horse.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include "Shader.h"
#include "CollisionSystem.h"
#include "AudioSystem.h"

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

Game::Game() : lastFrameTime(0.0), deltaTime(0.0), totalTime(0.0) {
    player = new Character();
    terrain = new Terrain();
    camera = new Camera(player);
    horse = new Horse();
    sky = new Sky();
    
    // Spawn player's primary car
    car = new Car();
    float gh = terrain->getHeight(10.0f, 10.0f);
    car->setPosition(Vec3(10.0f, gh + 1.0f, 10.0f));
    
    // Spawn traffic (Cars)
    // Some roaming, some parked
    npcCars.push_back(new Car(Car::State::ROAMING));
    npcCars.back()->setPosition(Vec3(-435, 12, 1315));
    
    npcCars.push_back(new Car(Car::State::ROAMING));
    npcCars.back()->setPosition(Vec3(-450, 12, 1330));
    npcCars.back()->setState(Car::State::ROAMING); // redundant but clear

    npcCars.push_back(new Car(Car::State::PARKED));
    npcCars.back()->setPosition(Vec3(-400, 12, 1280));

    npcCars.push_back(new Car(Car::State::PARKED));
    npcCars.back()->setPosition(Vec3(-380, 12, 1250));

    npcCars.push_back(new Car(Car::State::ROAMING));
    npcCars.back()->setPosition(Vec3(-460, 12, 1350));

    lastFrameTime = glfwGetTime();
    editMode = false;
    selectedLandmarkIdx = -1;
}

Game::~Game() {
    delete player;
    delete camera;
    delete terrain;
    delete sky;
    delete horse;
    delete car;
    for (auto* npc : npcCars) delete npc;
    AudioSystem::getInstance().cleanup();
}
void Game::setup(int width, int height) {
    std::cout << "[Game] Starting setup (" << width << "x" << height << ")..." << std::endl;
    windowWidth = width;
    windowHeight = height;
    setupFBO(width, height);
    AudioSystem::getInstance().init();
    std::cout << "[Game] Setup complete." << std::endl;
}


void Game::update(float mouseDeltaX, float mouseDeltaY, float mouseScroll) {
    double currentTime = glfwGetTime();
    deltaTime = currentTime - lastFrameTime;
    lastFrameTime = currentTime;
    
    // Cap deltaTime to avoid massive jumps during lag or debugging
    if (deltaTime > 0.1) deltaTime = 0.016;
    totalTime += deltaTime;

    // Sub-stepping for physics stability (especially for car suspension)
    const int numSteps = 4;
    float subDt = static_cast<float>(deltaTime) / static_cast<float>(numSteps);

    for (int step = 0; step < numSteps; ++step) {
        player->update(camera, subDt, terrain, static_cast<float>(totalTime));
        camera->update(mouseDeltaX / (float)numSteps, mouseDeltaY / (float)numSteps, mouseScroll / (float)numSteps, subDt);
        horse->update(subDt, terrain, static_cast<float>(totalTime));

        if (car) {
            car->update(subDt, terrain, static_cast<float>(totalTime), camera);
        }

        for (int i=0; i < (int)npcCars.size(); ++i) {
            npcCars[i]->update(subDt, terrain, static_cast<float>(totalTime));
        }




        // 5. Collision: Cars vs City Wall
        ObjModel* wallModel = terrain->getCityWallModel();
        if (wallModel) {
            glm::mat4 modelMat = terrain->getCityWallModelMatrix();
            glm::mat4 invModelMat = glm::inverse(modelMat);
            
            auto checkCarWall = [&](Car* vehicle, float rad) {
                Vec3 p = vehicle->getPosition();
                glm::vec3 cPos(p.x, p.y, p.z);
                
                glm::vec3 fwd = vehicle->getForwardVector();
                glm::vec3 rgt = vehicle->getRightVector();
                glm::vec3 corners[4] = {
                    cPos + fwd * 2.2f + rgt * 1.1f,
                    cPos + fwd * 2.2f - rgt * 1.1f,
                    cPos - fwd * 2.2f + rgt * 1.1f,
                    cPos - fwd * 2.2f - rgt * 1.1f
                };
                for (int c = 0; c < 4; ++c) {
                    glm::vec4 localPos4 = invModelMat * glm::vec4(corners[c], 1.0f);
                    glm::vec3 localPos = glm::vec3(localPos4);
                    glm::vec4 localOffset4 = invModelMat * glm::vec4(corners[c] + glm::vec3(rad, 0, 0), 1.0f);
                    float localRadius = glm::length(glm::vec3(localOffset4) - localPos);
                    
                    glm::vec3 outNormalLocal;
                    float outDepthLocal;
                    if (wallModel->checkSphereCollision(localPos, localRadius, outNormalLocal, outDepthLocal)) {
                        glm::mat3 normalMat = glm::transpose(glm::inverse(glm::mat3(modelMat)));
                        glm::vec3 worldNormal = glm::normalize(normalMat * outNormalLocal);
                        worldNormal.y = 0.0f;
                        if (glm::length(worldNormal) > 0.001f) worldNormal = glm::normalize(worldNormal);
                        
                        Vec3 v = vehicle->getVelocity();
                        glm::vec3 cv(v.x, v.y, v.z);
                        
                        if (glm::dot(worldNormal, cv) > 0) worldNormal = -worldNormal;
                        
                        glm::vec3 worldPushOut = glm::vec3(modelMat * glm::vec4(outNormalLocal * outDepthLocal, 0.0f));
                        float worldDepth = glm::length(worldPushOut);
                        
                        CollisionResult r;
                        r.hit = true;
                        r.normal = worldNormal;
                        r.depth = worldDepth;
                        
                        CollisionSystem::resolveStatic(cPos, cv, 1500.0f, r, 0.2f);
                        vehicle->setVelocity(Vec3(cv.x, cv.y, cv.z));
                        
                        vehicle->setPositionXZ(cPos.x, cPos.z);
                        vehicle->setVelocity(Vec3(cv.x, cv.y, cv.z));
                    }
                }
            };
            
            if (player->isDriving() && car) checkCarWall(car, 0.8f);
            for (auto* npc : npcCars) checkCarWall(npc, 0.8f);
        }
    }
}

// void Game::render() {
//   ///  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


//   // 1. Clear everything and reset global states
//     glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
//     glEnable(GL_DEPTH_TEST);
//     glDepthFunc(GL_LESS);
//     glDisable(GL_BLEND); // Start with blending OFF
   
// float aspectRatio = (float)windowWidth / (float)windowHeight;
//     // Apply camera transformation
//     glm::mat4 projection = glm::perspective(
//         glm::radians(camera->distance), 
//         aspectRatio, // Use your window dimensions here
//         0.5f, 1000.0f
//     );
//     glm::mat4 view = camera->getViewMatrix();
//     //camera->apply();
    
//     // Render terrain first (largest object)
   




//     Shader& characterShader = player->getShader(); // Supposons que Character a un getter pour le Shader
//     characterShader.use();
// Shader& OceanShader = terrain->getShader();
//     terrain->render(OceanShader);

//     // 1. Définir les matrices Model/View/Projection (Déjà fait dans player->render, mais assurez-vous que c'est bien la même chose)
//     // 2. Définir les uniforms d'éclairage
//    auto cameraPosCustom = camera->getPosition(); // Récupère l'objet Vec3
//     glm::vec3 cameraPosition = glm::vec3(cameraPosCustom.x, cameraPosCustom.y, cameraPosCustom.z);
//     // Les valeurs de la lumière du pipeline fixe ne sont pas utilisées, nous les définissons ici :
//     glm::vec3 lightWorldPos = glm::vec3(100.0f, 500.0f, 100.0f); // Reprend la position de main.cpp
//     glm::vec3 lightColor = glm::vec3(1.0f, 1.0f, 1.0f); // Lumière blanche par défaut
    
//     characterShader.setVec3("viewPos", cameraPosition);
//     characterShader.setVec3("lightPos", lightWorldPos);
//     characterShader.setVec3("lightColor", lightColor);
    
//     // --- FIN NOUVEAU CODE CRITIQUE ---
//   horse->render( projection, view);
//     // Le player->render() doit utiliser le shader déjà configuré
//     player->render( projection, view);
//     // Render player last
 
//     glUseProgram(0);
//     // --- A. Load Projection Matrix for Legacy Objects ---
//     // We must manually push the calculated GLM Projection matrix onto the GL_PROJECTION stack
//     glMatrixMode(GL_PROJECTION);
//     glLoadIdentity(); 
//     // Load the GLM matrix directly into the OpenGL state
//     glMultMatrixf(glm::value_ptr(projection)); 

//     // --- B. Load View Matrix for Legacy Objects ---
//     // We must manually push the calculated GLM View matrix onto the GL_MODELVIEW stack
//     glMatrixMode(GL_MODELVIEW);
//     glLoadIdentity(); 
//     // Load the GLM matrix directly into the OpenGL state
//     glMultMatrixf(glm::value_ptr(view));
     
// }
void Game::render() {
    // 1. Prepare FBO and Reset States
    glBindFramebuffer(GL_FRAMEBUFFER, sceneFBO);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    glDisable(GL_BLEND); 

    // 2. Prepare Matrices
    float aspectRatio = (float)windowWidth / (float)windowHeight;
    glm::mat4 projection = glm::perspective(
        glm::radians(camera->distance), 
        aspectRatio, 
        0.5f, 1000.0f
    );
    glm::mat4 view = camera->getViewMatrix();

    // 3. Render Sky (behind everything)
    float sunAngle = totalTime * (2.0f * 3.14159f / 120.0f);
    glm::vec3 lightDir = glm::normalize(glm::vec3(cos(sunAngle), sin(sunAngle), 0.2f));
    sky->render(projection, view, lightDir);

    // 4. Update Character & Object Shaders
    auto cameraPosCustom = camera->getPosition();
    glm::vec3 cameraPosition = glm::vec3(cameraPosCustom.x, cameraPosCustom.y, cameraPosCustom.z);
    glm::vec3 lColor = glm::vec3(1.0f); // Default light color

    Shader& characterShader = player->getShader();
    characterShader.use();
    characterShader.setVec3("viewPos", cameraPosition);
    characterShader.setVec3("lightPos", lightDir * 1000.0f);
    characterShader.setVec3("lightColor", lColor);
    
    Shader& horseShader = horse->getShader(); 
    horseShader.use();
    horseShader.setVec3("viewPos", cameraPosition);
    horseShader.setVec3("lightPos", lightDir * 1000.0f);
    horseShader.setVec3("lightColor", lColor);

    Shader& OceanShader = terrain->getShader();
    OceanShader.use();
    OceanShader.setVec3("lightDir", lightDir);
    
    // 5. Render World Objects
    terrain->render(OceanShader, projection, view, cameraPosition, lightDir, lColor);
    horse->render(projection, view);
    if (car) car->render(projection, view, terrain);
    for (auto* npc : npcCars) npc->render(projection, view, terrain);
    player->render(projection, view, lightDir, lColor, camera);
    
    // 6. Capture pass finished, return to default framebuffer
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Blit captured opaque scene to the default framebuffer
    glBindFramebuffer(GL_READ_FRAMEBUFFER, sceneFBO);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
    glBlitFramebuffer(0, 0, windowWidth, windowHeight, 0, 0, windowWidth, windowHeight, GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT, GL_NEAREST);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    // 7. Render water
    terrain->renderWater(projection, view, cameraPosition, lightDir, lColor,
                         sceneColorTex, sceneDepthTex);
    
    // 8. Cleanup
    glDisable(GL_LIGHTING);
    glUseProgram(0);
}



Camera& Game::getCamera() {
    return *camera;
}

void Game::keyDown(int key) {
    switch (key) {
        case GLFW_KEY_W: player->keyDown('z'); break;
        case GLFW_KEY_S: player->keyDown('s'); break;
        case GLFW_KEY_A: player->keyDown('q'); break;
        case GLFW_KEY_D: player->keyDown('d'); break;
        case GLFW_KEY_E:
        {
            Vec3 playerPos = player->getPosition();
            float interactionDistanceSq = 6.0f * 6.0f;

            if (player->isRiding()) {
                player->keyDown('e'); // Dismount Horse
            } else if (player->isDriving()) {
                if (m_playerNpcCar) {
                    m_playerNpcCar->dismountCharacter(player);
                    m_playerNpcCar = nullptr;
                } else {
                    player->keyDown('e'); // Dismount primary car (handled in Character::update)
                }
            } else {
                // Try mounting Horse
                Vec3 horsePos = horse->getPosition();
                float dHorseSq = (playerPos.x - horsePos.x) * (playerPos.x - horsePos.x) + 
                                (playerPos.z - horsePos.z) * (playerPos.z - horsePos.z);
                if (dHorseSq < interactionDistanceSq) {
                    horse->mountCharacter(player);
                } else {
                    // Try primary car
                    Vec3 carPos = car->getPosition();
                    float dCarSq = (playerPos.x - carPos.x) * (playerPos.x - carPos.x) + 
                                   (playerPos.z - carPos.z) * (playerPos.z - carPos.z);
                    if (dCarSq < interactionDistanceSq) {
                        player->startEnteringCar(car);
                    } else {
                        // Try hijacking Traffic Car
                        Car* bestCar = nullptr;
                        float bestDistSq = interactionDistanceSq;
                        for (auto* npc : npcCars) {
                            Vec3 p = npc->getPosition();
                            float dSq = (playerPos.x - p.x) * (playerPos.x - p.x) + 
                                        (playerPos.z - p.z) * (playerPos.z - p.z);
                            if (dSq < bestDistSq) {
                                bestDistSq = dSq;
                                bestCar = npc;
                            }
                        }
                        if (bestCar) {
                            bestCar->mountCharacter(player);
                            m_playerNpcCar = bestCar;
                        }
                    }
                }
            }
        }
        break;

    // ...

        case GLFW_KEY_ESCAPE:
        break;
        default:
            // Transmettre toutes les autres touches de mouvement au joueur
            // Utilisez 'z', 's', 'q', 'd', '<'
            if (key >= 65 && key <= 90) { // Si c'est une lettre majuscule
                 player->keyDown(tolower(key)); 
            } else {
                 player->keyDown(key); 
            }
            break;
    
    }
    
}

void Game::keyUp(int key) {
    switch (key) {
        case GLFW_KEY_W: player->keyUp('z'); break;
        case GLFW_KEY_S: player->keyUp('s'); break;
        case GLFW_KEY_A: player->keyUp('q'); break;
        case GLFW_KEY_D: player->keyUp('d'); break;
    }
}

void Game::mouseButton(int button, int action, double x, double y) {
    if (button == GLFW_MOUSE_BUTTON_RIGHT) {
        isRightMouseDown = (action == GLFW_PRESS);
    }
}

void Game::setupFBO(int width, int height) {
    if (sceneFBO) {
        glDeleteFramebuffers(1, &sceneFBO);
        glDeleteTextures(1, &sceneColorTex);
        glDeleteTextures(1, &sceneDepthTex);
    }

    glGenFramebuffers(1, &sceneFBO);
    glBindFramebuffer(GL_FRAMEBUFFER, sceneFBO);

    // Color texture
    glGenTextures(1, &sceneColorTex);
    glBindTexture(GL_TEXTURE_2D, sceneColorTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, sceneColorTex, 0);

    // Depth texture
    glGenTextures(1, &sceneDepthTex);
    glBindTexture(GL_TEXTURE_2D, sceneDepthTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, width, height, 0, GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, sceneDepthTex, 0);

    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
        std::cout << "ERROR::FRAMEBUFFER:: Framebuffer is not complete!" << std::endl;

    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

