#include "TerrainManager.h"
#include "TextureEngine.h"
#include <stb_image.h>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>

TerrainManager::TerrainManager(const std::string& hmPath, const std::string& pmPath, float minX, float maxX, float minZ, float maxZ, float minH, float maxH)
    : worldMinX(minX), worldMaxX(maxX), worldMinZ(minZ), worldMaxZ(maxZ), minHeight(minH), maxHeight(maxH) {
    std::cout << "[TerrainManager] Creating Shader..." << std::endl;
    terrainShader = new Shader("src/shaders/terrain_chunk.vert", "src/shaders/terrain_chunk.frag");
    std::cout << "[TerrainManager] Shader ID: " << terrainShader->ID << std::endl;
    
    std::cout << "[TerrainManager] Loading Heightmap: " << hmPath << std::endl;
    loadHeightmap(hmPath); 
    
    std::cout << "[TerrainManager] Setting up textures..." << std::endl;
    setupTextures(pmPath);
    
    if (gridW <= 0 || gridH <= 0) {
        std::cerr << "[TerrainManager] CRITICAL ERROR: Heightmap failed to load. Chunks will not be generated." << std::endl;
        return;
    }

    std::cout << "[TerrainManager] Generating chunks..." << std::endl;
    int stride = CHUNK_SIZE - 1;
    int numChunksX = (gridW + stride - 2) / stride;
    int numChunksZ = (gridH + stride - 2) / stride;
    
    std::cout << "[TerrainManager] Grid: " << gridW << "x" << gridH << " -> " << numChunksX << "x" << numChunksZ << " chunks." << std::endl;

    for (int z = 0; z < numChunksZ; ++z) {
        for (int x = 0; x < numChunksX; ++x) {
            TerrainChunk* chunk = new TerrainChunk(x, z, CHUNK_SIZE);
            chunk->generateMesh(heights, gridW, gridH, worldMinX, worldMaxX, worldMinZ, worldMaxZ,
                               &roadMaskData, roadW, roadH);
            chunks.push_back(chunk);
        }
    }
    std::cout << "[TerrainManager] Initialization Complete." << std::endl;
}

TerrainManager::~TerrainManager() { for (auto c : chunks) delete c; delete terrainShader; }

void TerrainManager::loadHeightmap(const std::string& path) {
    int w, h, ch; stbi_set_flip_vertically_on_load(false);
    unsigned short* rawData = stbi_load_16(path.c_str(), &w, &h, &ch, 1);
    if (rawData) {
        int targetW = 2048;
        int targetH = 2048;
        std::cout << "[TerrainManager] Upsampling Heightmap to Ultra-Res: " << targetW << "x" << targetH << "..." << std::endl;
        
        gridW = targetW; 
        gridH = targetH; 
        heights.resize(targetW * targetH);

        for (int y = 0; y < targetH; ++y) {
            for (int x = 0; x < targetW; ++x) {
                float gx = (float)x / (targetW - 1) * (w - 1);
                float gy = (float)y / (targetH - 1) * (h - 1);
                int ix = (int)gx;
                int iy = (int)gy;
                float fx = gx - ix;
                float fy = gy - iy;
                
                int ix1 = std::min(ix + 1, w - 1);
                int iy1 = std::min(iy + 1, h - 1);
                
                float h00 = rawData[iy * w + ix] / 65535.0f;
                float h10 = rawData[iy * w + ix1] / 65535.0f;
                float h01 = rawData[iy1 * w + ix] / 65535.0f;
                float h11 = rawData[iy1 * w + ix1] / 65535.0f;
                
                float val = h00 * (1-fx) * (1-fy) + h10 * fx * (1-fy) + h01 * (1-fx) * fy + h11 * fx * fy;
                heights[y * targetW + x] = minHeight + val * (maxHeight - minHeight);
            }
        }

        int rw, rh, rch;
        unsigned char* roadData = stbi_load("assets/terrain/roadMap.png", &rw, &rh, &rch, 4);
        if (roadData) {
            std::cout << "[TerrainManager] Applying Ultra-Res Gaussian Smoothing and Road Flattening..." << std::endl;
            
            for (int pass = 0; pass < 2; pass++) {
                std::vector<float> tempHeights = heights;
                for (int y = 2; y < targetH - 2; ++y) {
                    for (int x = 2; x < targetW - 2; ++x) {
                        float sum = 0.0f, wSum = 0.0f;
                        for (int dy = -2; dy <= 2; dy++) {
                            for (int dx = -2; dx <= 2; dx++) {
                                float weight = std::exp(-(dx*dx + dy*dy) / 4.0f);
                                sum += heights[(y+dy)*targetW + (x+dx)] * weight;
                                wSum += weight;
                            }
                        }
                        tempHeights[y*targetW + x] = sum / wSum;
                    }
                }
                heights = tempHeights;
            }

            std::vector<float> roadMaskGrid(targetW * targetH, 0.0f);
            for (int y = 0; y < targetH; ++y) {
                for (int x = 0; x < targetW; ++x) {
                    float gx = (float)x / (targetW - 1) * (rw - 1);
                    float gy = (float)y / (targetH - 1) * (rh - 1);
                    int ix = (int)gx; int iy = (int)gy;
                    float fx = gx - ix; float fy = gy - iy;
                    int ix1 = std::min(ix + 1, rw - 1), iy1 = std::min(iy + 1, rh - 1);
                    float m00 = roadData[(iy * rw + ix) * 4] / 255.0f;
                    float m10 = roadData[(iy * rw + ix1) * 4] / 255.0f;
                    float m01 = roadData[(iy1 * rw + ix) * 4] / 255.0f;
                    float m11 = roadData[(iy1 * rw + ix1) * 4] / 255.0f;
                    roadMaskGrid[y * targetW + x] = m00 * (1-fx) * (1-fy) + m10 * fx * (1-fy) + m01 * (1-fx) * fy + m11 * fx * fy;
                }
            }

            int blurRadius = 15; 
            std::vector<float> tempBlur(targetW * targetH);
            for (int y = 0; y < targetH; ++y) {
                for (int x = 0; x < targetW; ++x) {
                    if (roadMaskGrid[y * targetW + x] < 0.8f) {
                        tempBlur[y * targetW + x] = heights[y * targetW + x];
                        continue;
                    }
                    float sum = 0, wSum = 0;
                    for (int dx = -blurRadius; dx <= blurRadius; ++dx) {
                        int nx = std::clamp(x + dx, 0, targetW - 1);
                        float w = std::exp(-(dx*dx) / 50.0f);
                        sum += heights[y * targetW + nx] * w;
                        wSum += w;
                    }
                    tempBlur[y * targetW + x] = sum / wSum;
                }
            }

            // Create a blurred road mask to find the "center" for crowning
            std::vector<float> blurredMask(targetW * targetH);
            int maskBlurRad = 8;
            for (int y = 0; y < targetH; ++y) {
                for (int x = 0; x < targetW; ++x) {
                    if (roadMaskGrid[y * targetW + x] < 0.8f) { blurredMask[y * targetW + x] = 0; continue; }
                    float sum = 0, wSum = 0;
                    for (int dx = -maskBlurRad; dx <= maskBlurRad; ++dx) {
                        int nx = std::clamp(x + dx, 0, targetW - 1);
                        float w = std::exp(-(dx*dx) / 32.0f);
                        sum += roadMaskGrid[y * targetW + nx] * w;
                        wSum += w;
                    }
                    blurredMask[y * targetW + x] = sum / wSum;
                }
            }

            for (int y = 0; y < targetH; ++y) {
                for (int x = 0; x < targetW; ++x) {
                    float mask = roadMaskGrid[y * targetW + x];
                    if (mask < 0.8f || heights[y * targetW + x] < 6.0f) continue;
                    float sum = 0, wSum = 0;
                    for (int dy = -blurRadius; dy <= blurRadius; ++dy) {
                        int ny = std::clamp(y + dy, 0, targetH - 1);
                        float w = std::exp(-(dy*dy) / 50.0f);
                        sum += tempBlur[ny * targetW + x] * w;
                        wSum += w;
                    }
                    float roadBaseHeight = sum / wSum;
                    // Crowning: use the blurred mask to get a smooth bump in the middle
                    float crowning = blurredMask[y * targetW + x] * 0.22f; 
                    heights[y * targetW + x] = heights[y * targetW + x] * (1.0f - mask) + roadBaseHeight * mask + crowning;
                }
            }
            stbi_image_free(roadData);
        }

        std::vector<unsigned short> texData(targetW * targetH);
        for (int i = 0; i < targetW * targetH; ++i) {
            float norm = std::clamp((heights[i] - minHeight) / (maxHeight - minHeight), 0.0f, 1.0f);
            texData[i] = (unsigned short)(norm * 65535.0f);
        }

        glGenTextures(1, &heightmapTexID); glBindTexture(GL_TEXTURE_2D, heightmapTexID);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_R16, targetW, targetH, 0, GL_RED, GL_UNSIGNED_SHORT, texData.data());
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        
        stbi_image_free(rawData);
    }
}

void TerrainManager::setupTextures(const std::string& pmPath) {
    portMask = TextureEngine::Instance().loadTexture(pmPath, false);
    
    int rw, rh, rch;
    unsigned char* roadData = stbi_load("assets/terrain/roadMap.png", &rw, &rh, &rch, 4);
    if (roadData) {
        for (int y = 0; y < rh; ++y) {
            for (int x = 0; x < rw; ++x) {
                if (x < 5 || x > rw - 6 || y < 5 || y > rh - 6) {
                    roadData[(y * rw + x) * 4 + 0] = 0; 
                }
            }
        }
        roadW = rw; roadH = rh;
        roadMaskData.assign(roadData, roadData + (rw * rh * 4));

        if (roadMask == 0) glGenTextures(1, &roadMask);
        glBindTexture(GL_TEXTURE_2D, roadMask);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, rw, rh, 0, GL_RGBA, GL_UNSIGNED_BYTE, roadData);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        stbi_image_free(roadData);
        hasRoadMask = true;
    } else {
        std::cerr << "[TerrainManager] FAILED to load assets/terrain/roadMap.png" << std::endl;
        hasRoadMask = false;
    }
    
    std::vector<std::string> layers = { 
        "assets/terrain/coast_sand_01_diff_2k.jpg", 
        "assets/terrain/aerial_rocks_01_diff_2k.jpg", 
        "assets/terrain/gravel_concrete_03_diff_2k.jpg",
        "assets/terrain/tarred_gravel_2k/textures/tarred_gravel_diff_2k.jpg", 
        "assets/terrain/sandy_gravel_2k/textures/sandy_gravel_diff_2k.jpg" 
    };
    terrainLayerArray = TextureEngine::Instance().loadTextureArray(layers, 2048, 2048, true);

    std::vector<std::string> normLayers = {
        "assets/terrain/coast_sand_01_nor_gl_2k.jpg",
        "assets/terrain/aerial_rocks_01_nor_gl_2k.jpg",
        "assets/terrain/aerial_rocks_01_nor_gl_2k.jpg", // Fallback for concrete
        "assets/terrain/tarred_gravel_2k/textures/tarred_gravel_nor_dx_2k.png",
        "assets/terrain/sandy_gravel_2k/textures/sandy_gravel_nor_dx_2k.png"
    };
    terrainNormalArray = TextureEngine::Instance().loadTextureArray(normLayers, 2048, 2048, false);

    std::vector<std::string> dispLayers = {
        "assets/terrain/coast_sand_01_nor_gl_2k.jpg",
        "assets/terrain/aerial_rocks_01_nor_gl_2k.jpg",
        "assets/terrain/gravel_concrete_texture/gravel_concrete_03_disp_2k.png",
        "assets/terrain/tarred_gravel_2k/textures/tarred_gravel_disp_2k.png",
        "assets/terrain/sandy_gravel_2k/textures/sandy_gravel_disp_2k.png"
    };
    terrainDispArray = TextureEngine::Instance().loadTextureArray(dispLayers, 2048, 2048, false);

    // Optional roughness/rough maps (if present) — used to improve PBR response
    std::vector<std::string> roughLayers = {
        "assets/terrain/coast_sand_01_nor_gl_2k.jpg", // fallback (no dedicated rough)
        "assets/terrain/aerial_rocks_01_nor_gl_2k.jpg",
        "assets/terrain/gravel_concrete_texture/gravel_concrete_03_rough_2k.exr",
        "assets/terrain/tarred_gravel_2k/textures/tarred_gravel_rough_2k.exr",
        "assets/terrain/sandy_gravel_2k/textures/sandy_gravel_rough_2k.exr"
    };
    terrainRoughArray = TextureEngine::Instance().loadTextureArray(roughLayers, 2048, 2048, false);
}

void TerrainManager::update(const glm::vec3& camPos) {}

void TerrainManager::render(const glm::mat4& proj, const glm::mat4& view, const glm::vec3& camPos, const glm::vec3& lightDir, const glm::vec3& lightColor) {
    if (!terrainShader) return;
    terrainShader->use();
    terrainShader->setMat4("projection", proj); terrainShader->setMat4("view", view); terrainShader->setMat4("model", glm::mat4(1.0f));
    terrainShader->setVec3("viewPos", camPos); terrainShader->setVec3("lightDir", lightDir); terrainShader->setVec3("lightColor", lightColor);
    terrainShader->setFloat("sunTilt", lightDir.y); 
    
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D_ARRAY, terrainLayerArray); terrainShader->setInt("terrainTex", 0);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, portMask); terrainShader->setInt("portMask", 1);
    glActiveTexture(GL_TEXTURE2); glBindTexture(GL_TEXTURE_2D_ARRAY, terrainNormalArray); terrainShader->setInt("terrainNormal", 2);
    glActiveTexture(GL_TEXTURE3); glBindTexture(GL_TEXTURE_2D_ARRAY, terrainDispArray); terrainShader->setInt("terrainDisp", 3);
    // Bind optional roughness array to unit 4 if loaded, otherwise bind a default
    if (terrainRoughArray != 0) {
        glActiveTexture(GL_TEXTURE4); glBindTexture(GL_TEXTURE_2D_ARRAY, terrainRoughArray); terrainShader->setInt("terrainRough", 4);
        glActiveTexture(GL_TEXTURE5); glBindTexture(GL_TEXTURE_2D, roadMask); terrainShader->setInt("roadMask", 5);
    } else {
        glActiveTexture(GL_TEXTURE4); glBindTexture(GL_TEXTURE_2D, roadMask); terrainShader->setInt("roadMask", 4);
    }
    terrainShader->setBool("hasRoadMask", hasRoadMask);
    
    for (auto c : chunks) c->render();
    glUseProgram(0);
}

float TerrainManager::getHeightAt(float x, float z) const {
    float ux = std::clamp((x - worldMinX) / (worldMaxX - worldMinX), 0.0f, 1.0f);
    float uz = std::clamp((z - worldMinZ) / (worldMaxZ - worldMinZ), 0.0f, 1.0f);
    float fx = ux * (gridW - 1), fz = uz * (gridH - 1);
    int x0 = (int)fx, x1 = std::min(x0+1, gridW-1), z0 = (int)fz, z1 = std::min(z0+1, gridH-1);
    float tx = fx - x0, tz = fz - z0;
    return heights[z0*gridW+x0]*(1-tx)*(1-tz) + heights[z0*gridW+x1]*tx*(1-tz) + heights[z1*gridW+x0]*(1-tx)*tz + heights[z1*gridW+x1]*tx*tz;
}

void TerrainManager::exportToOBJ(const std::string& filename, int downsample) const {
    std::cout << "[TerrainManager] Exporting terrain to OBJ: " << filename << " (downsample=" << downsample << ")" << std::endl;
    std::ofstream out(filename);
    if (!out.is_open()) {
        std::cerr << "[TerrainManager] Failed to open " << filename << " for export." << std::endl;
        return;
    }

    // Grid dimensions for OBJ
    int dw = gridW / downsample;
    int dh = gridH / downsample;

    // Write vertices
    for (int z = 0; z < dh; ++z) {
        for (int x = 0; x < dw; ++x) {
            float ux = (float)x / (dw - 1);
            float uz = (float)z / (dh - 1);
            float worldX = worldMinX + ux * (worldMaxX - worldMinX);
            float worldZ = worldMinZ + uz * (worldMaxZ - worldMinZ);
            float worldY = heights[(z * downsample) * gridW + (x * downsample)];
            out << "v " << worldX << " " << worldY << " " << worldZ << "\n";
        }
    }

    // Write faces (1-based indices)
    for (int z = 0; z < dh - 1; ++z) {
        for (int x = 0; x < dw - 1; ++x) {
            int i0 = z * dw + x + 1;
            int i1 = z * dw + (x + 1) + 1;
            int i2 = (z + 1) * dw + (x + 1) + 1;
            int i3 = (z + 1) * dw + x + 1;
            out << "f " << i0 << " " << i1 << " " << i2 << " " << i3 << "\n";
        }
    }

    out.close();
    std::cout << "[TerrainManager] Export Complete." << std::endl;
}

glm::vec3 TerrainManager::getNormalAt(float x, float z) const {
    float e = 1.0f; float hL = getHeightAt(x-e, z), hR = getHeightAt(x+e, z), hS = getHeightAt(x, z-e), hN = getHeightAt(x, z+e);
    return glm::normalize(glm::vec3(hL - hR, 2.0f * e, hS - hN));
}

float TerrainManager::getRoadAt(float x, float z) const {
    if (roadMaskData.empty()) return 0.0f;
    float ux = std::clamp((x - worldMinX) / (worldMaxX - worldMinX), 0.0f, 1.0f);
    float uz = std::clamp((z - worldMinZ) / (worldMaxZ - worldMinZ), 0.0f, 1.0f);
    float fx = ux * (roadW - 1), fz = uz * (roadH - 1);
    int x0 = (int)fx, x1 = std::min(x0+1, roadW-1), z0 = (int)fz, z1 = std::min(z0+1, roadH-1);
    float tx = fx - x0, tz = fz - z0;
    float r00 = roadMaskData[(z0*roadW+x0)*4+0]/255.0f, r10 = roadMaskData[(z0*roadW+x1)*4+0]/255.0f;
    float r01 = roadMaskData[(z1*roadW+x0)*4+0]/255.0f, r11 = roadMaskData[(z1*roadW+x1)*4+0]/255.0f;
    return r00*(1-tx)*(1-tz) + r10*tx*(1-tz) + r01*(1-tx)*tz + r11*tx*tz;
}
