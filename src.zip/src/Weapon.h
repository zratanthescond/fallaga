#pragma once

#include "ObjectModel.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/euler_angles.hpp>
#include <vector>

struct Weapon {
    ObjModel* model = nullptr;
    glm::vec3 positionOffset = glm::vec3(0.0f);
    glm::vec3 rotationOffset = glm::vec3(0.0f); // degrees: x=pitch, y=yaw, z=roll
    glm::vec3 scaleOffset = glm::vec3(1.0f);
    int handBoneID = -1;
};

class WeaponManager {
public:
    std::vector<Weapon> weapons;
    int currentWeapon = -1;

    void addWeapon(const Weapon& weapon) {
        weapons.push_back(weapon);
        if (currentWeapon == -1) {
            currentWeapon = 0;
        }
    }

    Weapon* getCurrentWeapon() {
        if (currentWeapon >= 0 && currentWeapon < (int)weapons.size()) {
            return &weapons[currentWeapon];
        }
        return nullptr;
    }

    void switchWeapon(int index) {
        if (index >= 0 && index < (int)weapons.size()) {
            currentWeapon = index;
        }
    }

    void cycleWeapon() {
        if (!weapons.empty()) {
            currentWeapon = (currentWeapon + 1) % weapons.size();
        }
    }

    glm::mat4 createWeaponOffset(const Weapon& weapon) {
        glm::mat4 offset = glm::mat4(1.0f);
        offset = glm::translate(offset, weapon.positionOffset);
        
        offset *= glm::yawPitchRoll(
            glm::radians(weapon.rotationOffset.y),
            glm::radians(weapon.rotationOffset.x),
            glm::radians(weapon.rotationOffset.z)
        );
        
        offset = glm::scale(offset, weapon.scaleOffset);
        return offset;
    }
    
    ~WeaponManager() {
        for (auto& w : weapons) {
            delete w.model;
        }
    }
};
