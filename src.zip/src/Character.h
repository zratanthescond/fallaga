#pragma once

#include "Shader.h"
#include "Vec3.h"
#include <algorithm>
#include <cmath>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <map>

// Forward declarations to avoid circular includes
class Camera;
class AnimatedModel;
class Horse;
class Car;
class Terrain;
class WeaponManager;

class Character {
  Shader *characterShader; // Si le shader est géré par Character
private:
  // ========================================================
  // RDR2-STYLE PHYSICAL SIMULATION CONSTANTS (1 unit = 1 meter)
  // ========================================================
  // Linear Force & Mass
  static constexpr float MASS = 80.0f; // kg
  static constexpr float DRAG_COEFFICIENT =
      4.0f; // Environmental drag (velocity multiplier)

  // Realistic human forces to achieve realistic m/s terminal speeds
  // Terminal Velocity = Thrust / (Mass * Drag)
  static constexpr float THRUST_FORCE_WALK = 480.0f; // Reaches 1.5 m/s terminal
  static constexpr float THRUST_FORCE_SPRINT =
      1920.0f; // Reaches 6.0 m/s terminal

  // Rotational Torque & Inertia (The "Weight" of turning)
  static constexpr float INERTIA =
      25.0f; // High resistance to rotational change
  static constexpr float ANGULAR_DRAG =
      4.0f; // Allows for ~1.5s 360-degree turns
  static constexpr float TORQUE_STRENGTH = 150.0f; // Softened turn authority

  // Target speeds for Animation Scaling (realistic m/s)
  static constexpr float WALK_SPEED = 1.5f;   // 1.5 m/s (~5.4 km/h)
  static constexpr float JOG_SPEED = 3.5f;    // 3.5 m/s (~12.5 km/h)
  static constexpr float SPRINT_SPEED = 6.0f; // 6.0 m/s (~21.6 km/h)

  // State Variables
  Vec3 position;
  Vec3 velocity;                // Current movement velocity (horizontal XZ)
  float angularVelocity = 0.0f; // Current rotational speed (rad/sec)
  float currentYAngle; // Current direction the character model is facing (for
                       // rendering)
  bool m_isRiding = false;
  bool m_isDriving = false;
  bool m_isDrivingNpcCar = false;
  bool m_isGrounded = true;

  // NOUVEAU MEMBRE CRITIQUE: Le cheval sur lequel le joueur est monté
  Horse *m_MountedHorse = nullptr;
  Car *m_MountedCar = nullptr;

  // Input state

  AnimatedModel *model;
  float m_RotationAngle = 0.0f;
  glm::vec3 m_ForwardDirection =
      glm::vec3(0.0f, 1.0f, 0.0f); // Rotation AXIS (always Y-up)
  std::string m_CurrentAnim = "Idle";

  // Weapon System
  WeaponManager* weaponManager = nullptr;
  Shader* weaponShader = nullptr;
  bool m_IsWeaponDrawn = false;

public:
  Character();
  ~Character();
  glm::vec3 m_TerrainNormal = glm::vec3(0.0f, 1.0f, 0.0f);
  Shader &getShader();
  std::map<int, bool> keys;
  void update(Camera *camera, float deltaTime, class Terrain *terrain,
              float time);
  void render(const glm::mat4 &projection, const glm::mat4 &view, 
              const glm::vec3& lightDir, const glm::vec3& lightColor, Camera* camera);

  // Input handlers
  void keyDown(int key);
  void keyUp(int key);

  // Accessors
  Vec3 getPosition() const { return position; }
  void setPosition(const Vec3 &newPos) { position = newPos; }
  Vec3 getVelocity() const { return velocity; }
  void setVelocity(const Vec3 &v) { velocity = v; }
  float getSpeed() const {
    return std::sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
  }
  float getYaw() const { return m_RotationAngle; }

  // Méthodes de Monture
  void setMountedHorse(Horse *horse);
  bool isRiding() const { return m_isRiding; }

  void setMountedCar(Car *car);
  void setDrivingNpcCar(bool driving);
  bool isDriving() const { return m_isDriving || m_isDrivingNpcCar; }
  
  // Weapon Management
  void initWeapons();
  void drawWeapon(bool draw);
  bool isWeaponDrawn() const { return m_IsWeaponDrawn; }
  WeaponManager* getWeaponManager() { return weaponManager; }
  bool isDrivingNpcCar() const { return m_isDrivingNpcCar; }
  Car *getMountedCar() const { return m_MountedCar; }

  // CORRECTION: Retourne une référence constante à la carte
  const std::map<int, bool> &getKeys() const { return keys; }

  void setRotation(float angle, const glm::vec3 &axis);
  Vec3 getRight() const;
  bool m_isMounting = false;
  bool m_isEnteringCar = false;
  void startEnteringCar(Car *car);
  void snapToTerrain(class Terrain* terrain);

  // Car entry animation interpolation
  Vec3 m_entryStartPos;
  Vec3 m_entryTargetPos;
  float m_entryTimer = 0.0f;
  float m_entryDuration = 3.0f; // 3 seconds for full entry
};