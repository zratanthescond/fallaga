#pragma once

#include "Vec3.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// ================================================================
// RDR2-STYLE CAMERA CONSTANTS
// ================================================================
// Distance: How far behind the player the camera sits
const float CAMERA_DEFAULT_DISTANCE = 3.5f;   // Closer RDR2 default orbit distance
const float CAMERA_MIN_DISTANCE = 1.0f;        // Closest zoom
const float CAMERA_MAX_DISTANCE = 300.0f;      // Furthest zoom (for Architect mode)

// Pitch: Vertical angle limits (degrees)
const float CAMERA_PITCH_MIN = 1.0f;           // Slightly above horizon
const float CAMERA_PITCH_MAX = 75.0f;          // Looking down

// Input sensitivity
const float CAMERA_SENSITIVITY = 0.3f;         // Mouse look sensitivity
const float CAMERA_ZOOM_SENSITIVITY = 0.5f;    // Scroll zoom sensitivity

// Spring-Damper Physics: The "Weight" of the camera
const float CAMERA_MASS = 1.0f;
const float CAMERA_SPRING_STIFFNESS = 150.0f;    // Pull strength to goal
const float CAMERA_SPRING_DAMPING = 2.0f * std::sqrt(CAMERA_MASS * CAMERA_SPRING_STIFFNESS); // Critically damped

const float TARGET_SPRING_STIFFNESS = 250.0f;    // Target follows faster
const float TARGET_SPRING_DAMPING = 2.0f * std::sqrt(CAMERA_MASS * TARGET_SPRING_STIFFNESS);

// Auto-alignment: Camera gradually centers behind the player when moving
const float CAMERA_AUTO_ALIGN_SPEED = 1.2f;    // deg/sec alignment rate
const float CAMERA_AUTO_ALIGN_THRESHOLD = 1.0f; // Min player speed to trigger alignment 

// Vertical offset: Look at the character's chest/shoulders, not feet
const float CAMERA_LOOK_HEIGHT = 1.4f;         // Units above character position


class Character; // Forward declaration
class ObjModel; // Forward declaration

class Camera {
public:
    Camera(Character* target);
    ~Camera();
    void setTerrain(ObjModel* terrain);
    glm::mat4 getViewMatrix();
    void update(float mouseDeltaX, float mouseDeltaY, float mouseScroll, float dt);
    void setFreeCam(bool free);
    bool isFreeCam() const { return freeCam; }
    void moveFree(float dx, float dz, float dy, float dt);
    glm::vec3 getRay(float mx, float my, int w, int h) const;

    Vec3 getPosition() const;
    Vec3 getForward() const;
    Vec3 getDirection() const { return getForward(); }
    Vec3 getRight() const;

private:
    Character* target;
    ObjModel* terrainModel = nullptr;

    float angleAroundTarget; // Horizontal orbit angle (degrees)
    float pitch;             // Vertical orbit angle (degrees)
    
    float lastTargetYaw = 0.0f; // Track target rotation for relative follow
    float autoAlignTimer = 0.0f; // Delay before auto-alignment kicks in
    
    // Physical camera state
    Vec3 smoothedPosition;
    Vec3 cameraVelocity;
    
    Vec3 smoothedTarget;
    Vec3 targetVelocity;

    // Goal position (what we're smoothing towards)
    Vec3 goalPosition;
    
    // Camera vectors
    Vec3 forward;
    Vec3 up;
    Vec3 right;
    
    // FreeCam state
    bool freeCam = false;
    Vec3 freePos;
    float freeYaw = 0.0f;
    float freePitch = 0.0f;

    // Internal methods
    void calculateGoalPosition();
    void applySmoothingAndClamp(float deltaTime);

public:
    float distance; // Current orbit distance
};