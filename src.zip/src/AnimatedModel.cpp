#include "AnimatedModel.h"
#include <assimp/anim.h>
#include <assimp/quaternion.h>
#include <assimp/vector3.h>
#include <glm/gtc/type_ptr.hpp>
#define GLM_ENABLE_EXPERIMENTAL
#include "stb_image.h"
#include <cmath>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/quaternion.hpp>
#include <iostream>
#include <stddef.h>
#include <vector>
#include <GLFW/glfw3.h>

void loadTexture(const std::string &textureFilename, unsigned int &textureID,
                 const std::string &basepath) {
  std::string fullPath = basepath + textureFilename;
  glGenTextures(1, &textureID);
  glBindTexture(GL_TEXTURE_2D, textureID);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
                  GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  int width, height, nrChannels;
  stbi_set_flip_vertically_on_load(true);
  unsigned char *data =
      stbi_load(fullPath.c_str(), &width, &height, &nrChannels, 0);
  if (data) {
    GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format,
                 GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
  } else {
    std::cerr << "Failed to load texture at: " << fullPath << std::endl;
  }
  stbi_image_free(data);
}

glm::mat4 AssimpToGLMMat4(const aiMatrix4x4 &from) {
  glm::mat4 to;
  // Map Assimp columns directly to GLM columns
  to[0][0] = from.a1; to[0][1] = from.b1; to[0][2] = from.c1; to[0][3] = from.d1;
  to[1][0] = from.a2; to[1][1] = from.b2; to[1][2] = from.c2; to[1][3] = from.d2;
  to[2][0] = from.a3; to[2][1] = from.b3; to[2][2] = from.c3; to[2][3] = from.d3;
  to[3][0] = from.a4; to[3][1] = from.b4; to[3][2] = from.c4; to[3][3] = from.d4;
  return to;
}

// ---------------------------------------------------------------------------
// FIX #4: Do NOT skip _$AssimpFbx$_ nodes. Instead, strip that suffix in the
// canonical name so pre-rotation virtual nodes are matched correctly against
// their animation channels — critical for Mixamo FBX with pre-rotations.
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// IMPROVED: Robust Node Animation Discovery
// This function now uses "contains" logic to match bones like 'mixamorig:Hips' 
// to 'Hips', which is common when mixing assets from different sources.
// ---------------------------------------------------------------------------
aiNodeAnim *findNodeAnim(const aiAnimation *animation,
                         const std::string &nodeName) {
  // 1. Try Exact Match
  for (unsigned int i = 0; i < animation->mNumChannels; i++) {
    if (std::string(animation->mChannels[i]->mNodeName.data) == nodeName) {
      return animation->mChannels[i];
    }
  }

  // 2. Try Canonical Match (Strip prefixes and common separators)
  auto getBase = [](const std::string& n) {
      std::string res = n;
      // Handle namespace separators
      size_t colon = res.find_last_of(':');
      if (colon != std::string::npos) res = res.substr(colon + 1);
      
      size_t pipe = res.find_last_of('|');
      if (pipe != std::string::npos) res = res.substr(pipe + 1);
      
      // Handle _$AssimpFbx$_
      size_t fbx = res.find("_$AssimpFbx$_");
      if (fbx != std::string::npos) res = res.substr(0, fbx);

      return res;
  };
  
  std::string nodeBase = getBase(nodeName);
  for (unsigned int i = 0; i < animation->mNumChannels; i++) {
      if (getBase(animation->mChannels[i]->mNodeName.data) == nodeBase) {
          return animation->mChannels[i];
      }
  }

  return nullptr;
}

glm::vec3 AssimpToGLMVec3(const aiVector3D &from) {
  return glm::vec3(from.x, from.y, from.z);
}
glm::quat AssimpToGLMQuat(const aiQuaternion &from) {
  return glm::quat(from.w, from.x, from.y, from.z);
}

// ---------------------------------------------------------------------------
// FIX #3: Return the last valid index instead of 0 when animationTime is
// past the final keyframe. Returning 0 caused a visible snap/pop at the end
// of every animation cycle as interpolation jumped back to the curve start.
// ---------------------------------------------------------------------------
unsigned int AnimatedModel::GetPositionIndex(float animationTime,
                                             const aiNodeAnim *nodeAnim) {
  for (unsigned int i = 0; i < nodeAnim->mNumPositionKeys - 1; i++) {
    if (animationTime < (float)nodeAnim->mPositionKeys[i + 1].mTime)
      return i;
  }
  // Clamp to the last valid interpolation pair
  return nodeAnim->mNumPositionKeys - 2;
}

unsigned int AnimatedModel::GetRotationIndex(float animationTime,
                                             const aiNodeAnim *nodeAnim) {
  for (unsigned int i = 0; i < nodeAnim->mNumRotationKeys - 1; i++) {
    if (animationTime < (float)nodeAnim->mRotationKeys[i + 1].mTime)
      return i;
  }
  return nodeAnim->mNumRotationKeys - 2;
}

unsigned int AnimatedModel::GetScalingIndex(float animationTime,
                                            const aiNodeAnim *nodeAnim) {
  for (unsigned int i = 0; i < nodeAnim->mNumScalingKeys - 1; i++) {
    if (animationTime < (float)nodeAnim->mScalingKeys[i + 1].mTime)
      return i;
  }
  return nodeAnim->mNumScalingKeys - 2;
}

glm::mat4 AnimatedModel::InterpolatePosition(float animationTime,
                                             const aiNodeAnim *nodeAnim) {
  if (nodeAnim->mNumPositionKeys == 1)
    return glm::translate(glm::mat4(1.0f),
                          AssimpToGLMVec3(nodeAnim->mPositionKeys[0].mValue));
  unsigned int pIndex0 = GetPositionIndex(animationTime, nodeAnim);
  unsigned int pIndex1 = pIndex0 + 1;
  float delta = (float)nodeAnim->mPositionKeys[pIndex1].mTime -
                (float)nodeAnim->mPositionKeys[pIndex0].mTime;
  float factor =
      (delta == 0.0f)
          ? 0.0f
          : (animationTime - (float)nodeAnim->mPositionKeys[pIndex0].mTime) /
                delta;
  return glm::translate(
      glm::mat4(1.0f),
      glm::mix(AssimpToGLMVec3(nodeAnim->mPositionKeys[pIndex0].mValue),
               AssimpToGLMVec3(nodeAnim->mPositionKeys[pIndex1].mValue),
               glm::clamp(factor, 0.0f, 1.0f)));
}

glm::mat4 AnimatedModel::InterpolateRotation(float animationTime,
                                             const aiNodeAnim *nodeAnim) {
  if (nodeAnim->mNumRotationKeys == 1)
    return glm::toMat4(AssimpToGLMQuat(nodeAnim->mRotationKeys[0].mValue));
  unsigned int rIndex0 = GetRotationIndex(animationTime, nodeAnim);
  unsigned int rIndex1 = rIndex0 + 1;
  float delta = (float)nodeAnim->mRotationKeys[rIndex1].mTime -
                (float)nodeAnim->mRotationKeys[rIndex0].mTime;
  float factor =
      (delta == 0.0f)
          ? 0.0f
          : (animationTime - (float)nodeAnim->mRotationKeys[rIndex0].mTime) /
                delta;
  glm::quat finalRot =
      glm::slerp(AssimpToGLMQuat(nodeAnim->mRotationKeys[rIndex0].mValue),
                 AssimpToGLMQuat(nodeAnim->mRotationKeys[rIndex1].mValue),
                 glm::clamp(factor, 0.0f, 1.0f));
  return glm::toMat4(glm::normalize(finalRot));
}

glm::mat4 AnimatedModel::InterpolateScaling(float animationTime,
                                            const aiNodeAnim *nodeAnim) {
  if (nodeAnim->mNumScalingKeys == 1)
    return glm::scale(glm::mat4(1.0f),
                        AssimpToGLMVec3(nodeAnim->mScalingKeys[0].mValue));

  unsigned int index0 = GetScalingIndex(animationTime, nodeAnim);
  unsigned int index1 = index0 + 1;
  float delta = (float)nodeAnim->mScalingKeys[index1].mTime -
                (float)nodeAnim->mScalingKeys[index0].mTime;
  float factor =
      (delta == 0.0f)
          ? 0.0f
          : (animationTime - (float)nodeAnim->mScalingKeys[index0].mTime) /
                delta;
  factor = glm::clamp(factor, 0.0f, 1.0f);

  glm::vec3 scale = glm::mix(AssimpToGLMVec3(nodeAnim->mScalingKeys[index0].mValue),
                             AssimpToGLMVec3(nodeAnim->mScalingKeys[index1].mValue),
                             factor);
  return glm::scale(glm::mat4(1.0f), scale);
}

void AnimatedModel::setAnimationCyclic(const std::string &animName,
                                       bool isCyclic) {
  if (m_AnimationMap.count(animName))
    m_IsCyclicMap[animName] = isCyclic;
}

// ---------------------------------------------------------------------------
// FIX #2: Removed the early-exit guard that silently rejected loading a
// dedicated animation file for a name that was already auto-mapped (e.g.
// "Idle", "Run"). Now properly cleans up the old importer before replacing.
// ---------------------------------------------------------------------------
bool AnimatedModel::loadAnimation(const std::string &animFilename,
                                  const std::string &animName) {
  // Clean up any existing importer for this animation name so we don't leak
  if (m_AnimationImporters.count(animName)) {
    delete m_AnimationImporters[animName];
    m_AnimationImporters.erase(animName);
  }

  Assimp::Importer *animImporter = new Assimp::Importer();
  const aiScene *animScene = animImporter->ReadFile(
      animFilename, aiProcess_LimitBoneWeights | aiProcess_Triangulate);
  if (!animScene || !animScene->mRootNode || !animScene->HasAnimations()) {
    std::cerr << "[AnimatedModel] Failed to load animation: " << animFilename
              << std::endl;
    delete animImporter;
    return false;
  }
  const aiAnimation *anim = animScene->mAnimations[0];
  
  // Debug animation root transform
  aiMatrix4x4 animRootT = animScene->mRootNode->mTransformation;
  std::cout << "[AnimatedModel] Animation '" << animName << "' Root Transform diag: " << animRootT.a1 << " " << animRootT.b2 << " " << animRootT.c3 << " " << animRootT.d4 << std::endl;

  m_AnimationImporters[animName] = animImporter;
  m_AnimationMap[animName] = anim;
  m_IsCyclicMap[animName] = true;
  
  // DEBUG: Count matched bones
  int matched = 0;
  for (unsigned int i = 0; i < anim->mNumChannels; i++) {
      std::string chanName = anim->mChannels[i]->mNodeName.C_Str();
      // We check if this channel name (canonical) exists in our rig's bone map
      std::string cName = chanName;
      size_t fbx_pos = cName.find("_$AssimpFbx$_");
      if (fbx_pos != std::string::npos) cName = cName.substr(0, fbx_pos);
      if (cName.rfind("mixamorig:", 0) == 0) cName = cName.substr(10);
      size_t colon_pos = cName.find_last_of(':');
      if (colon_pos != std::string::npos) cName = cName.substr(colon_pos + 1);

      // Check if this exists in our rig
      bool found = false;
      for (auto const& [rigBone, info] : m_BoneInfoMap) {
          if (getCanonicalBoneName(rigBone) == cName) { found = true; break; }
      }
      if (found) matched++;
  }
  std::cout << "[AnimatedModel] Animation '" << animName << "' matched " << matched << "/" << anim->mNumChannels << " channels to Rig." << std::endl;

  if (m_CurrentAnimationName.empty()) {
    m_CurrentAnimationName = animName;
    m_Duration = (float)anim->mDuration /
                 (anim->mTicksPerSecond != 0 ? anim->mTicksPerSecond : 25.0f);
  }
  return true;
}

AnimatedModel::AnimatedModel(const std::string &rigFilename)
    : m_Scene(nullptr), m_BoneCounter(0) {
  m_FinalBoneMatrices.resize(MAX_BONES, glm::mat4(1.0f));

  size_t lastSlash = rigFilename.find_last_of("/\\");
  m_BasePath = (lastSlash == std::string::npos)
                   ? ""
                   : rigFilename.substr(0, lastSlash + 1);

  // FIX #5: Added aiProcess_LimitBoneWeights so Assimp enforces the 4-influence
  // limit during import, keeping bone weights consistent with the Vertex
  // struct.
  m_Scene = m_Importer.ReadFile(
      rigFilename, aiProcess_Triangulate | aiProcess_GenSmoothNormals |
                       aiProcess_CalcTangentSpace | aiProcess_FlipUVs |
                       aiProcess_LimitBoneWeights);
  if (!m_Scene || !m_Scene->mRootNode) {
    std::cerr << "[AnimatedModel ERROR] Failed to load: " << rigFilename
              << std::endl;
    return;
  }
  // CLEAN SLATE: Ignore the FBX's root transform which often causes Z-up/Y-up confusion.
  // We treat the model as if it's already in our world space.
  m_GlobalInverseTransform = glm::mat4(1.0f);
  m_Scene->mRootNode->mTransformation = aiMatrix4x4(); // Identity
  
  std::cout << "[AnimatedModel] Clean Slate: Root transform forced to Identity." << std::endl;
  
  m_BoneCounter = 0;
  m_FinalBoneMatrices.assign(MAX_BONES, glm::mat4(1.0f));

  // Auto-load animations embedded in the mesh file
  std::cout << "[AnimatedModel] Loading " << m_Scene->mNumAnimations
            << " animations from " << rigFilename << std::endl;
  for (unsigned int i = 0; i < m_Scene->mNumAnimations; i++) {
    const aiAnimation *anim = m_Scene->mAnimations[i];
    std::string animName = anim->mName.C_Str();
    if (animName.empty())
      animName = "Default_" + std::to_string(i);

    std::string loName = animName;
    for (auto &c : loName)
      c = (char)tolower(c);

    // Map the first animation to "Idle" as a safe fallback
    if (i == 0) {
      m_AnimationMap["Idle"] = anim;
      std::cout << "  -> Mapping first animation '" << animName << "' to 'Idle'"
                << std::endl;
    }
    if (loName.find("idle") != std::string::npos) {
      m_AnimationMap["Idle"] = anim;
      std::cout << "  -> Mapping '" << animName << "' to 'Idle' (name match)"
                << std::endl;
    }
    if (loName.find("run") != std::string::npos ||
        loName.find("walk") != std::string::npos) {
      m_AnimationMap["Run"] = anim;
      std::cout << "  -> Mapping '" << animName << "' to 'Run' (name match)"
                << std::endl;
    }

    // Store under original name
    m_AnimationMap[animName] = anim;
    m_IsCyclicMap[animName] = true;
    std::cout << "  - Animation[" << i << "]: '" << animName << "' (" << anim->mNumChannels << " channels)" << std::endl;
  }

  m_IsCyclicMap["Idle"] = true;
  m_IsCyclicMap["Run"] = true;

  if (!m_CurrentAnimationName.empty() &&
      m_AnimationMap.count(m_CurrentAnimationName)) {
    const aiAnimation *anim = m_AnimationMap[m_CurrentAnimationName];
    m_Duration = (float)anim->mDuration /
                 (anim->mTicksPerSecond != 0 ? anim->mTicksPerSecond : 25.0f);
  } else if (m_Scene->HasAnimations()) {
    m_CurrentAnimationName = "Idle";
    const aiAnimation *anim = m_Scene->mAnimations[0];
    m_Duration = (float)anim->mDuration /
                 (anim->mTicksPerSecond != 0 ? anim->mTicksPerSecond : 25.0f);
  }

  preScanNodes(m_Scene->mRootNode);
  processNode(m_Scene->mRootNode);
}

void AnimatedModel::preScanNodes(aiNode *node) {
  std::string name = node->mName.C_Str();
  
  // Register every node in the scene as a potential bone
  if (m_BoneInfoMap.find(name) == m_BoneInfoMap.end()) {
    if (m_BoneCounter < MAX_BONES) {
        BoneInfo info;
        info.id = m_BoneCounter++;
        info.offsetMatrix = glm::mat4(1.0f); // Will be updated by mesh if it's a real bone
        m_BoneInfoMap[name] = info;
    } else {
        static bool warned = false;
        if (!warned) {
            std::cerr << "[AnimatedModel] WARNING: Exceeded MAX_BONES (" << MAX_BONES << ") during pre-scan!" << std::endl;
            warned = true;
        }
    }
  }

  for (unsigned int i = 0; i < node->mNumChildren; i++)
    preScanNodes(node->mChildren[i]);
}

AnimatedModel::~AnimatedModel() {
  for (auto &meshInfo : m_Meshes) {
    glDeleteVertexArrays(1, &meshInfo.VAO);
    glDeleteBuffers(1, &meshInfo.VBO);
    glDeleteBuffers(1, &meshInfo.EBO);
    if (meshInfo.textureID)
      glDeleteTextures(1, &meshInfo.textureID);
  }
  for (auto const &pair : m_AnimationImporters)
    delete pair.second;
}

void AnimatedModel::processNode(aiNode *node) {
  for (unsigned int i = 0; i < node->mNumMeshes; i++)
    processMesh(m_Scene->mMeshes[node->mMeshes[i]]);
  for (unsigned int i = 0; i < node->mNumChildren; i++)
    processNode(node->mChildren[i]);
}

void AnimatedModel::loadTextureFromMemory(const aiTexture *embeddedTexture,
                                          unsigned int &textureID) {
  glGenTextures(1, &textureID);
  glBindTexture(GL_TEXTURE_2D, textureID);
  int width, height, nrChannels;
  unsigned char *data =
      (embeddedTexture->mHeight == 0)
          ? stbi_load_from_memory(
                reinterpret_cast<unsigned char *>(embeddedTexture->pcData),
                embeddedTexture->mWidth, &width, &height, &nrChannels, 0)
          : stbi_load_from_memory(
                reinterpret_cast<unsigned char *>(embeddedTexture->pcData),
                embeddedTexture->mWidth * embeddedTexture->mHeight, &width,
                &height, &nrChannels, 0);
  if (data) {
    GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format,
                 GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(data);
  }
}

void AnimatedModel::processMesh(aiMesh *mesh) {
  std::vector<Vertex> vertices;
  std::vector<unsigned int> indices;
  for (unsigned int i = 0; i < mesh->mNumVertices; i++) {
    Vertex vertex;
    vertex.Position = glm::vec3(mesh->mVertices[i].x, mesh->mVertices[i].y,
                                mesh->mVertices[i].z);
    if (mesh->HasNormals())
      vertex.Normal = glm::vec3(mesh->mNormals[i].x, mesh->mNormals[i].y,
                                mesh->mNormals[i].z);
    if (mesh->mTextureCoords[0])
      vertex.TexCoords =
          glm::vec2(mesh->mTextureCoords[0][i].x, mesh->mTextureCoords[0][i].y);
    for (int j = 0; j < MAX_BONE_INFLUENCE; ++j) {
      vertex.m_BoneIDs[j] = -1;
      vertex.m_Weights[j] = 0.0f;
    }
    vertices.push_back(vertex);
  }
  
  // Debug mesh bounds
  if (mesh->mNumVertices > 0) {
      glm::vec3 vMin(1e10), vMax(-1e10);
      for (unsigned int i = 0; i < mesh->mNumVertices; i++) {
          vMin = glm::min(vMin, vertices[i].Position);
          vMax = glm::max(vMax, vertices[i].Position);
      }
      std::cout << "[AnimatedModel] Mesh '" << mesh->mName.C_Str() << "' bounds: min(" << vMin.x << "," << vMin.y << "," << vMin.z << ") max(" << vMax.x << "," << vMax.y << "," << vMax.z << ")" << std::endl;
  }
  
  for (unsigned int j = 0; j < mesh->mNumFaces; j++)
    for (unsigned int k = 0; k < mesh->mFaces[j].mNumIndices; k++)
      indices.push_back(mesh->mFaces[j].mIndices[k]);
  if (mesh->HasBones())
    extractBoneWeightForVertices(vertices, mesh);
  MeshData newMesh;
  newMesh.indices = indices;
  if (m_Scene->HasMaterials()) {
    aiMaterial *material = m_Scene->mMaterials[mesh->mMaterialIndex];
    aiString str;
    if (material->GetTexture(aiTextureType_DIFFUSE, 0, &str) == AI_SUCCESS) {
      const aiTexture *embeddedTexture =
          m_Scene->GetEmbeddedTexture(str.C_Str());
      if (embeddedTexture)
        loadTextureFromMemory(embeddedTexture, newMesh.textureID);
      else
        loadTexture(str.C_Str(), newMesh.textureID, m_BasePath);
    }
  }
  setupMeshGL(vertices, indices, newMesh);
  m_Meshes.push_back(newMesh);
}

void AnimatedModel::extractBoneWeightForVertices(std::vector<Vertex> &vertices,
                                                 aiMesh *mesh) {
  int linkedBones = 0;
  for (unsigned int i = 0; i < mesh->mNumBones; i++) {
    int boneID = -1;
    std::string boneName = mesh->mBones[i]->mName.C_Str();

    // SMART LINKER: Try to find this bone in our rig using multiple naming styles
    auto findRigBone = [&](const std::string& name) -> std::string {
        if (m_BoneInfoMap.count(name)) return name;
        
        // Try stripping namespaces
        std::string canonical = name;
        size_t colon = canonical.find_last_of(':');
        if (colon != std::string::npos) canonical = canonical.substr(colon + 1);
        
        for (auto const& [rigName, info] : m_BoneInfoMap) {
            std::string rigCanonical = rigName;
            size_t rColon = rigCanonical.find_last_of(':');
            if (rColon != std::string::npos) rigCanonical = rigCanonical.substr(rColon + 1);
            
            if (rigCanonical == canonical) return rigName;
        }
        return "";
    };

    std::string rigBoneName = findRigBone(boneName);

    if (rigBoneName == "") {
      std::cout << "[AnimatedModel] Mesh Bone '" << boneName << "' could NOT be linked to Rig!" << std::endl;
      BoneInfo newBoneInfo;
      newBoneInfo.id = m_BoneCounter++;
      newBoneInfo.offsetMatrix = AssimpToGLMMat4(mesh->mBones[i]->mOffsetMatrix);
      m_BoneInfoMap[boneName] = newBoneInfo;
      boneID = newBoneInfo.id;
    } else {
      std::cout << "[AnimatedModel] Mesh Bone '" << boneName << "' -> Linked to Rig Node '" << rigBoneName << "' (ID: " << m_BoneInfoMap[rigBoneName].id << ")" << std::endl;
      boneID = m_BoneInfoMap[rigBoneName].id;
      m_BoneInfoMap[rigBoneName].offsetMatrix = AssimpToGLMMat4(mesh->mBones[i]->mOffsetMatrix);
      linkedBones++;
    }

    assert(boneID != -1);
    auto weights = mesh->mBones[i]->mWeights;
    int numWeights = mesh->mBones[i]->mNumWeights;

    for (int weightIndex = 0; weightIndex < numWeights; ++weightIndex) {
      unsigned int vertexId = weights[weightIndex].mVertexId;
      float weight = weights[weightIndex].mWeight;
      
      for (int j = 0; j < MAX_BONE_INFLUENCE; ++j) {
        if (vertices[vertexId].m_BoneIDs[j] < 0) {
          vertices[vertexId].m_Weights[j] = weight;
          vertices[vertexId].m_BoneIDs[j] = boneID;
          break;
        }
      }
    }
  }
  std::cout << "[AnimatedModel] Mesh processing: " << mesh->mNumBones << " bones, " << linkedBones << " linked to Rig." << std::endl;
  for (auto &v : vertices) {
    float tw = 0.0f;
    for (int i = 0; i < MAX_BONE_INFLUENCE; i++)
      if (v.m_BoneIDs[i] != -1)
        tw += v.m_Weights[i];
    if (tw > 0.0f)
      for (int i = 0; i < MAX_BONE_INFLUENCE; i++)
        v.m_Weights[i] /= tw;
  }
}

void AnimatedModel::setupMeshGL(const std::vector<Vertex> &vertices,
                                const std::vector<unsigned int> &indices,
                                MeshData &meshData) {
  glGenVertexArrays(1, &meshData.VAO);
  glGenBuffers(1, &meshData.VBO);
  glGenBuffers(1, &meshData.EBO);
  glBindVertexArray(meshData.VAO);
  glBindBuffer(GL_ARRAY_BUFFER, meshData.VBO);
  glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vertex), &vertices[0],
               GL_STATIC_DRAW);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, meshData.EBO);
  glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int),
               &indices[0], GL_STATIC_DRAW);
  glEnableVertexAttribArray(0);
  glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void *)0);
  glEnableVertexAttribArray(1);
  glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                        (void *)offsetof(Vertex, Normal));
  glEnableVertexAttribArray(2);
  glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                        (void *)offsetof(Vertex, TexCoords));
  glEnableVertexAttribArray(3);
  glVertexAttribIPointer(3, MAX_BONE_INFLUENCE, GL_INT, sizeof(Vertex),
                         (void *)offsetof(Vertex, m_BoneIDs));
  glEnableVertexAttribArray(4);
  glVertexAttribPointer(4, MAX_BONE_INFLUENCE, GL_FLOAT, GL_FALSE,
                        sizeof(Vertex), (void *)offsetof(Vertex, m_Weights));
  glBindVertexArray(0);
}

void AnimatedModel::updateAnimation(const std::string &animName,
                                    float deltaTime) {
  if (!m_Scene || m_AnimationMap.empty())
    return;

  if (!animName.empty() && animName != "None") {
    if (m_AnimationMap.count(animName) && m_CurrentAnimationName != animName) {
      if (!m_CurrentAnimationName.empty()) {
          m_PreviousAnimationName = m_CurrentAnimationName;
          m_PreviousAnimationTime = m_AnimationTime;
          m_IsBlending = true;
          m_BlendTimer = 0.0f;
          m_BlendTime = 0.2f; // 200ms crossfade
      }

      m_CurrentAnimationName = animName;
      m_AnimationTime = 0.0f;
      m_AnimationIsFinished = false;
      const aiAnimation *anim = m_AnimationMap.at(animName);
      m_Duration = (float)anim->mDuration /
                   (anim->mTicksPerSecond != 0 ? anim->mTicksPerSecond : 25.0f);
    }
  }

  if (m_CurrentAnimationName.empty() ||
      m_AnimationMap.find(m_CurrentAnimationName) == m_AnimationMap.end()) {
    static bool warned = false;
    if (!warned) {
      std::cout << "[AnimatedModel] WARNING: No animation to play or '"
                << m_CurrentAnimationName << "' not found." << std::endl;
      warned = true;
    }
    return;
  }

  const aiAnimation *animation = m_AnimationMap.at(m_CurrentAnimationName);

  float tps =
      animation->mTicksPerSecond != 0 ? animation->mTicksPerSecond : 25.0f;
  m_AnimationTime += deltaTime * tps;

  if (m_IsCyclicMap.count(m_CurrentAnimationName) &&
      m_IsCyclicMap.at(m_CurrentAnimationName)) {
    m_AnimationTime = fmod(m_AnimationTime, (float)animation->mDuration);
  } else if (m_AnimationTime >= (float)animation->mDuration) {
    m_AnimationTime = (float)animation->mDuration;
    m_AnimationIsFinished = true;
  }

  // Update previous animation time if blending
  if (m_IsBlending) {
      m_BlendTimer += deltaTime;
      if (m_BlendTimer >= m_BlendTime) {
          m_IsBlending = false;
          m_PreviousAnimationName = "";
      } else {
          if (m_AnimationMap.count(m_PreviousAnimationName)) {
              const aiAnimation* prevAnim = m_AnimationMap.at(m_PreviousAnimationName);
              float prevTps = prevAnim->mTicksPerSecond != 0 ? prevAnim->mTicksPerSecond : 25.0f;
              m_PreviousAnimationTime += deltaTime * prevTps;
               if (m_IsCyclicMap.count(m_PreviousAnimationName) && m_IsCyclicMap.at(m_PreviousAnimationName)) {
                   m_PreviousAnimationTime = fmodf(m_PreviousAnimationTime, (float)prevAnim->mDuration);
               } else {
                  m_PreviousAnimationTime = std::min(m_PreviousAnimationTime, (float)prevAnim->mDuration);
              }
          }
      }
  }

  calculateBoneTransform(m_Scene->mRootNode, glm::mat4(1.0f), animation);
}

std::string
AnimatedModel::getCanonicalBoneName(const std::string &nodeName) const {
  std::string canonicalName = nodeName;
  size_t fbx_pos = canonicalName.find("_$AssimpFbx$_");
  if (fbx_pos != std::string::npos)
    canonicalName = canonicalName.substr(0, fbx_pos);
  size_t mix_pos = canonicalName.find("mixamorig:");
  if (mix_pos == 0)
    canonicalName = canonicalName.substr(10);
  size_t colon_pos = canonicalName.find_last_of(':');
  if (colon_pos != std::string::npos)
    canonicalName = canonicalName.substr(colon_pos + 1);
  return canonicalName;
}

void AnimatedModel::calculateBoneTransform(const aiNode *node,
                                           glm::mat4 parentTransform,
                                           const aiAnimation *animation) {
  if (node == m_Scene->mRootNode) m_ActiveNodesLastFrame = 0;

  std::string nodeName = node->mName.data;
  glm::mat4 nodeTransform = AssimpToGLMMat4(node->mTransformation);

  aiNodeAnim* boneNodeAnim = findNodeAnim(animation, nodeName);
  
  if (m_IsBlending && !m_PreviousAnimationName.empty()) {
      aiNodeAnim* prevNodeAnim = findNodeAnim(m_AnimationMap.at(m_PreviousAnimationName), nodeName);
      float blendFactor = glm::clamp(m_BlendTimer / m_BlendTime, 0.0f, 1.0f);

      if (boneNodeAnim && prevNodeAnim) {
          glm::mat4 currentLocal = InterpolatePosition(m_AnimationTime, boneNodeAnim) *
                                   InterpolateRotation(m_AnimationTime, boneNodeAnim) *
                                   InterpolateScaling(m_AnimationTime, boneNodeAnim);
          
          glm::mat4 prevLocal = InterpolatePosition(m_PreviousAnimationTime, prevNodeAnim) *
                                InterpolateRotation(m_PreviousAnimationTime, prevNodeAnim) *
                                InterpolateScaling(m_PreviousAnimationTime, prevNodeAnim);

          nodeTransform = prevLocal * (1.0f - blendFactor) + currentLocal * blendFactor;
          m_ActiveNodesLastFrame++;
      } else if (boneNodeAnim) {
          nodeTransform = InterpolatePosition(m_AnimationTime, boneNodeAnim) *
                          InterpolateRotation(m_AnimationTime, boneNodeAnim) *
                          InterpolateScaling(m_AnimationTime, boneNodeAnim);
          m_ActiveNodesLastFrame++;
      } else if (prevNodeAnim) {
          nodeTransform = InterpolatePosition(m_PreviousAnimationTime, prevNodeAnim) *
                          InterpolateRotation(m_PreviousAnimationTime, prevNodeAnim) *
                          InterpolateScaling(m_PreviousAnimationTime, prevNodeAnim);
      }
  } else if (boneNodeAnim) {
    nodeTransform = InterpolatePosition(m_AnimationTime, boneNodeAnim) *
                    InterpolateRotation(m_AnimationTime, boneNodeAnim) *
                    InterpolateScaling(m_AnimationTime, boneNodeAnim);
    m_ActiveNodesLastFrame++;
  }

  glm::mat4 globalTransform = parentTransform * nodeTransform;

  if (m_BoneInfoMap.count(nodeName)) {
    int id = m_BoneInfoMap.at(nodeName).id;
    m_FinalBoneMatrices[id] = m_GlobalInverseTransform * globalTransform * m_BoneInfoMap.at(nodeName).offsetMatrix;
  }

  for (unsigned int i = 0; i < node->mNumChildren; ++i)
    calculateBoneTransform(node->mChildren[i], globalTransform, animation);

  if (node == m_Scene->mRootNode) {
      static double lastLog = 0;
      if (glfwGetTime() - lastLog > 2.0) {
          std::cout << "[AnimatedModel] Active Animated Nodes: " << m_ActiveNodesLastFrame << " (Model: " << m_Scene->mRootNode->mName.C_Str() << ")" << std::endl;
          lastLog = glfwGetTime();
      }
  }
}

void AnimatedModel::setBoneUniforms(Shader &shader) {
  if (m_FinalBoneMatrices.empty())
    return;
    
  GLint loc = shader.getUniformLocation("gBones");
  if (loc != -1) {
    glUniformMatrix4fv(loc, MAX_BONES, GL_FALSE, glm::value_ptr(m_FinalBoneMatrices[0]));
    
    static bool printedLoc = false;
    if (!printedLoc) {
        std::cout << "[AnimatedModel] Uniform 'gBones' linked at Location " << loc << " (Shader " << shader.ID << ")" << std::endl;
        printedLoc = true;
    }
  } else {
    static bool warned = false;
    if (!warned) {
        std::cerr << "[AnimatedModel ERROR] Uniform 'gBones' not found in shader ID " << shader.ID << "!" << std::endl;
        warned = true;
    }
  }

  // Debug: Print Hips transformation every 2 seconds to verify motion in code
  static double lastPrintTime = 0;
  double currentTime = glfwGetTime();
  if (currentTime - lastPrintTime > 2.0) {
      int hipsID = -1;
      // Try multiple canonical variants for Hips
      for (auto const& [name, info] : m_BoneInfoMap) {
          if (getCanonicalBoneName(name) == "Hips") {
              hipsID = info.id;
              break;
          }
      }

      if (hipsID != -1 && hipsID < (int)m_FinalBoneMatrices.size()) {
          glm::mat4 m = m_FinalBoneMatrices[hipsID];
          std::cout << "[BONE CHECK] Hips Matrix[3].y: " << m[3][1] << " (Moving?)" << std::endl;
      } else {
          std::cout << "[BONE CHECK] Hips bone not found or ID out of range! (Rig has " << m_BoneCounter << " nodes)" << std::endl;
      }
      lastPrintTime = currentTime;
  }

  shader.setInt("texture_diffuse1", 0);
  shader.setInt("ourTexture", 0); // Fallback
}

void AnimatedModel::draw() {
  for (const auto &mesh : m_Meshes) {
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, mesh.textureID);
    glBindVertexArray(mesh.VAO);
    glDrawElements(GL_TRIANGLES, (GLsizei)mesh.indices.size(), GL_UNSIGNED_INT,
                   0);
    glBindVertexArray(0);
  }
}

float AnimatedModel::getAnimationDuration() const { return m_Duration; }

int AnimatedModel::getBoneID(const std::string &boneName) const {
  if (m_BoneInfoMap.count(boneName))
    return m_BoneInfoMap.at(boneName).id;
  return -1;
}

glm::mat4 AnimatedModel::getFinalBoneMatrix(int boneID) const {
  return (boneID >= 0 && boneID < (int)m_FinalBoneMatrices.size())
             ? m_FinalBoneMatrices[boneID]
             : glm::mat4(1.0f);
}