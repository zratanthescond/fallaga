#include "Character.h"
#include "AnimatedModel.h"
#include "Camera.h"
#include "Car.h"
#include "CollisionSystem.h"
#include "Horse.h"
#include "PhysicsSystem.h"
#include "Terrain.h"
#include <GLFW/glfw3.h>
#include <algorithm>
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>

// ---------------------------------------------------------------------------
// HELPER: Smooth Normal Lerp
// ---------------------------------------------------------------------------
static glm::vec3 smoothNormal(const glm::vec3 &current, const glm::vec3 &target,
                              float speed, float dt) {
  if (glm::length(target) < 0.01f)
    return current;
  glm::vec3 result =
      glm::mix(current, target, glm::clamp(speed * dt, 0.0f, 1.0f));
  if (glm::length(result) > 0.001f)
    return glm::normalize(result);
  return current;
}

// ---------------------------------------------------------------------------
// HELPER: Sample Terrain Normal
// ---------------------------------------------------------------------------
static glm::vec3 sampleTerrainNormal(Terrain *terrain, float x, float z) {
  if (!terrain)
    return glm::vec3(0, 1, 0);
  return terrain->getNormalAt(x, z);
}

// ---------------------------------------------------------------------------
// HELPER: Build Terrain-Aligned Matrix (Yaw + Slope)
// ---------------------------------------------------------------------------
static glm::mat4 buildTerrainOrientMatrix(const glm::vec3 &upVec,
                                          float rotationYaw) {
  // Character facing direction in flat world XZ plane (Aligned with Car.cpp)
  glm::vec3 charForwardFlat(std::sin(rotationYaw), 0.0f,
                            -std::cos(rotationYaw));

  glm::vec3 right = glm::normalize(glm::cross(charForwardFlat, upVec));
  glm::vec3 forward = glm::normalize(glm::cross(upVec, right));

  glm::mat4 m(1.0f);
  m[0] = glm::vec4(right, 0.0f);
  m[1] = glm::vec4(upVec, 0.0f);
  m[2] = glm::vec4(forward, 0.0f);
  return m;
}

Character::Character()
    : characterShader(new Shader("src/shaders/character.vert",
                                 "src/shaders/character.frag")),
      model(nullptr), m_RotationAngle(0.0f), angularVelocity(0.0f),
      m_TerrainNormal(0, 1, 0), m_isDriving(false), m_isDrivingNpcCar(false),
      m_isRiding(false), m_isEnteringCar(false), m_MountedCar(nullptr),
      m_MountedHorse(nullptr) {
  std::cout << "[Character] Shader loaded successfully from src/shaders/" << std::endl;
  model = new AnimatedModel("assets/character/mainCharacter.fbx");
  if (model) {
      ((AnimatedModel*)model)->loadAnimation("assets/character/Idle.fbx", "Idle");
      ((AnimatedModel*)model)->loadAnimation("assets/character/Walking.fbx", "Walk");
      ((AnimatedModel*)model)->loadAnimation("assets/character/fastrun.fbx", "Run");
      ((AnimatedModel*)model)->loadAnimation("assets/character/EntringCar.fbx", "EnterCar");
      ((AnimatedModel*)model)->loadAnimation("assets/character/DrivingCar.fbx", "Drive");
  }
  weaponShader = new Shader("src/shaders/model.vert", "src/shaders/model.frag");
  position = Vec3(0, 50, 0);
  velocity = Vec3(0, 0, 0);
  m_CurrentAnim = "Idle";
}

void Character::snapToTerrain(Terrain *terrain) {
  if (terrain) {
    position.y = terrain->getHeight(position.x, position.z);
  }
}

Character::~Character() {
  if (model)
    delete (AnimatedModel *)model;
}

void Character::startEnteringCar(Car *car) {
  if (!car)
    return;
  m_isEnteringCar = true;
  m_MountedCar = car;
  m_entryTimer = 0.0f;
  m_entryStartPos = position;
  // Target the driver-side door (approx 1.2m to the left of car center)
  glm::vec3 carPos(car->getPosition().x, car->getPosition().y, car->getPosition().z);
  glm::vec3 right = car->getRightVector();
  glm::vec3 doorPos = carPos - right * 1.2f; 
  m_entryTargetPos = Vec3(doorPos.x, doorPos.y, doorPos.z);
}

void Character::update(Camera *camera, float deltaTime, Terrain *terrain,
                       float totalTime) {
  if (deltaTime > 0.1f)
    deltaTime = 0.033f;

  if (m_isDriving || m_isDrivingNpcCar) {
    m_TerrainNormal = smoothNormal(m_TerrainNormal, glm::vec3(0.0f, 1.0f, 0.0f),
                                   6.0f, deltaTime);
    if (m_isDriving && !m_isDrivingNpcCar) {
      if (keys['E'] || keys['e']) {
        if (m_MountedCar)
          m_MountedCar->dismountCharacter(this);
        keys['E'] = keys['e'] = false;
      }
    }
    velocity = Vec3(0, 0, 0);
  } else if (m_isEnteringCar) {
    glm::vec3 rawNormal = sampleTerrainNormal(terrain, position.x, position.z);
    m_TerrainNormal =
        smoothNormal(m_TerrainNormal, rawNormal, 12.0f, deltaTime);
    float actualDuration = 3.0f;
    m_entryTimer += deltaTime;
    float interpT = std::min(m_entryTimer / actualDuration, 1.0f);
    float smoothT = interpT * interpT * (3.0f - 2.0f * interpT);
    position.x =
        m_entryStartPos.x * (1.0f - smoothT) + m_entryTargetPos.x * smoothT;
    position.z =
        m_entryStartPos.z * (1.0f - smoothT) + m_entryTargetPos.z * smoothT;

    // Face the car while entering
    Vec3 carPos = m_MountedCar->getPosition();
    float dx = carPos.x - position.x;
    float dz = carPos.z - position.z;
    if (std::abs(dx) > 0.1f || std::abs(dz) > 0.1f) {
        float targetAngle = std::atan2(dx, -dz);
        m_RotationAngle = targetAngle; // Snapping for now, can be smoothed
    }

    if (terrain)
      PhysicsSystem::applyGravity(position, velocity, deltaTime, terrain,
                                  totalTime, 0.01f);
    if (m_entryTimer >= actualDuration) {
      if (m_MountedCar)
        m_MountedCar->mountCharacter(this);
      m_isEnteringCar = false;
    }
  } else if (m_isRiding) {
    if (keys['E'] || keys['e']) {
      if (m_MountedHorse)
        m_MountedHorse->dismountCharacter(this);
      keys['E'] = keys['e'] = false;
    }
    if (m_MountedHorse)
      m_MountedHorse->updateMovement(camera, deltaTime, terrain, totalTime);
    glm::vec3 rawNormal = sampleTerrainNormal(terrain, position.x, position.z);
    m_TerrainNormal =
        smoothNormal(m_TerrainNormal, rawNormal, 10.0f, deltaTime);
  } else {
    // ON FOOT
    Vec3 inputDir(0, 0, 0);
    Vec3 camFwd = camera->getForward();
    Vec3 camRight = camera->getRight();
    camFwd.y = 0;
    camRight.y = 0;
    if (camFwd.length() > 0.001f)
      camFwd.normalize();
    if (camRight.length() > 0.001f)
      camRight.normalize();
    if (keys['w'] || keys['W'] || keys['z'] || keys['Z'])
      inputDir += camFwd;
    if (keys['s'] || keys['S'])
      inputDir -= camFwd;
    if (keys['a'] || keys['A'] || keys['q'] || keys['Q'])
      inputDir -= camRight;
    if (keys['d'] || keys['D'])
      inputDir += camRight;

    bool isInputActive = (inputDir.length() > 0.01f);
    bool isShiftHeld = (glfwGetKey(glfwGetCurrentContext(),
                                   GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS);

    if (isInputActive) {
      inputDir.normalize();
      // Rotation logic removed by user request
    }
    // angularVelocity logic removed
    // m_RotationAngle logic removed

    if (isInputActive) {
      float thrust = (isShiftHeld ? THRUST_FORCE_SPRINT : THRUST_FORCE_WALK) *
                     deltaTime / MASS;
      velocity.x += inputDir.x * thrust;
      velocity.z += inputDir.z * thrust;

      // Update rotation to face movement direction
      float targetAngle = std::atan2(inputDir.x, -inputDir.z);
      // Smooth rotation (optional, but realistic)
      float angleDiff = targetAngle - m_RotationAngle;
      while (angleDiff > glm::pi<float>())
        angleDiff -= 2.0f * glm::pi<float>();
      while (angleDiff < -glm::pi<float>())
        angleDiff += 2.0f * glm::pi<float>();
      m_RotationAngle += angleDiff * std::min(deltaTime * 10.0f, 1.0f);
    }

    velocity.x *= std::exp(-DRAG_COEFFICIENT * deltaTime);
    velocity.z *= std::exp(-DRAG_COEFFICIENT * deltaTime);
    position.x += velocity.x * deltaTime;
    position.z += velocity.z * deltaTime;

    // Use the improved physics system for gravity and grounding
    if (terrain) {
      m_isGrounded = PhysicsSystem::applyGravity(position, velocity, deltaTime,
                                                 terrain, totalTime, 1.0f);
    }
    glm::vec3 rawNormal = sampleTerrainNormal(terrain, position.x, position.z);
    m_TerrainNormal = smoothNormal(m_TerrainNormal, rawNormal,
                                   isInputActive ? 8.0f : 5.0f, deltaTime);
  }

  if (model) {
    // FOR DEBUG: Force rest pose (T-pose)
    // 4. Update Animation
    bool isInputActive = keys['z'] || keys['s'] || keys['q'] || keys['d'] ||
                         keys['W'] || keys['S'] || keys['A'] || keys['D'];
    bool isShiftHeld = (glfwGetKey(glfwGetCurrentContext(),
                                   GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS);

    if (m_isGrounded) {
      if (isInputActive) {
        if (isShiftHeld) {
            m_CurrentAnim = "Run";
        } else {
            m_CurrentAnim = "Walk";
        }
      } else {
        m_CurrentAnim = "Idle";
      }
    } else {
      m_CurrentAnim = "Idle";
    }

    if (m_isEnteringCar) {
      m_CurrentAnim = "EnterCar";
    }

    if (m_isDriving || m_isDrivingNpcCar) {
      m_CurrentAnim = "Drive";
    }

    // Check if the model has the requested animation, otherwise fallback to
    // first available
    if (!((AnimatedModel *)model)->hasAnimation(m_CurrentAnim)) {
      m_CurrentAnim = "Idle";
    }

    static std::string lastAnim = "";
    if (m_CurrentAnim != lastAnim) {
      std::cout << "[Char] Switched to animation: " << m_CurrentAnim
                << std::endl;
      lastAnim = m_CurrentAnim;
    }

    ((AnimatedModel *)model)->updateAnimation(m_CurrentAnim, deltaTime);
  }
}

void Character::render(const glm::mat4 &projection, const glm::mat4 &view,
                       const glm::vec3 &lightDir, const glm::vec3 &lightColor,
                       Camera *camera) {
  if (!model || !characterShader)
    return;
  glm::vec3 upVec = (m_isDriving) ? glm::vec3(0, 1, 0) : m_TerrainNormal;
  if (glm::length(upVec) < 0.001f)
    upVec = glm::vec3(0, 1, 0);

  // Debug: print position every 60 frames
  static int dbgFrame = 0;
  if (dbgFrame % 60 == 0) {
    std::cout << "[Char] pos=(" << position.x << ", " << position.y << ", "
              << position.z << ")" << std::endl;
  }
  dbgFrame++;

  // Character's feet are at the bottom of the model (y=0 in local space).
  // After scale (0.01) and Z-up to Y-up rotation, feet stay at local y=0.
  // The model is placed so feet = position.y (ground level).
  // Correct Transformation Order: Translate * Rotate * Scale
  // 1. Translate to world position
  glm::mat4 modelMatrix = glm::translate(
      glm::mat4(1.0f), glm::vec3(position.x, position.y, position.z));

  // 2. Apply orientation (Yaw + Slope Alignment)
  glm::mat4 orientMat = buildTerrainOrientMatrix(upVec, m_RotationAngle);
  modelMatrix = modelMatrix * orientMat;

  // Model-space correction (Many FBXs are Z-up)
  modelMatrix = glm::rotate(modelMatrix, glm::radians(-90.0f), glm::vec3(1, 0, 0));

  // 3. Scale the model (0.01 for Mixamo FBX usually)
  modelMatrix = glm::scale(modelMatrix, glm::vec3(0.01f));

  characterShader->use();
  characterShader->setMat4("projection", projection);
  characterShader->setMat4("view", view);
  characterShader->setMat4("model", modelMatrix);
  characterShader->setVec3("lightPos", lightDir);
  Vec3 camPos = camera->getPosition();
  characterShader->setVec3("viewPos", glm::vec3(camPos.x, camPos.y, camPos.z));
  characterShader->setVec3("lightColor", lightColor);

  if (model) {
      ((AnimatedModel*)model)->setBoneUniforms(*characterShader);
      ((AnimatedModel*)model)->draw();
  }
}

void Character::setMountedHorse(Horse *horse) {
  m_isRiding = (horse != nullptr);
  m_MountedHorse = horse;
}

void Character::setMountedCar(Car *car) {
  m_isDriving = (car != nullptr);
  m_MountedCar = car;
}
void Character::setDrivingNpcCar(bool d) { m_isDrivingNpcCar = d; }
Shader &Character::getShader() { return *characterShader; }

void Character::keyDown(int key) { keys[key] = true; }
void Character::keyUp(int key) { keys[key] = false; }

void Character::setRotation(float angle, const glm::vec3 &axis) {
  m_RotationAngle = angle;
  m_ForwardDirection = axis;
}

Vec3 Character::getRight() const {
  glm::vec3 forward(std::sin(m_RotationAngle), 0.0f, -std::cos(m_RotationAngle));
  glm::vec3 right = glm::normalize(glm::cross(forward, glm::vec3(0, 1, 0)));
  return Vec3(right.x, right.y, right.z);
}