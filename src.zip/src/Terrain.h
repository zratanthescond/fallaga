#ifndef TERRAIN_H
#define TERRAIN_H

#pragma once
#include "Shader.h"
#include "TerrainManager.h"
#include "ObjectModel.h"
#include <glm/glm.hpp>
#include <map>
#include <string>
#include <vector>

struct Monument {
  char id;
  float x, z, w, h;
  const char *name;
};
struct Street {
  float x1, z1, x2, z2, width;
};

// A named street polyline: chain of (x,z) points with a width
struct StreetPolyline {
  std::string name;
  float width;
  std::vector<glm::vec2> points; // (x, z) waypoints
};

class Terrain {
public:
  Shader *oceanShader = nullptr;
  Shader *terrainShader = nullptr;
  Shader *modelShader = nullptr; 
  static bool isFlatMode;
  static constexpr float WATER_LEVEL = 2.5f;

  mutable std::map<std::string, ObjModel *> assetCache;

  Terrain();
  ~Terrain();

    void renderOpaque(const glm::mat4 &projection, const glm::mat4 &view,
                    const glm::vec3 &camPos, const glm::vec3 &lightDir,
                    const glm::vec3 &lightColor,
                    int selectedIdx = -1, bool editMode = false) const;

  void renderWater(const glm::mat4 &projection, const glm::mat4 &view,
                   const glm::vec3 &camPos, const glm::vec3 &lightDir,
                   const glm::vec3 &lightColor,
                   unsigned int sceneColorTex,
                   unsigned int sceneDepthTex) const;

  void render(Shader & /*ignored*/, const glm::mat4 &projection,
              const glm::mat4 &view, const glm::vec3 &camPos,
              const glm::vec3 &lightDir, const glm::vec3 &lightColor,
              int selectedIdx = -1,
              bool editMode = false) const {
    renderOpaque(projection, view, camPos, lightDir, lightColor, selectedIdx, editMode);
  }

  Shader &getShader() const { return *oceanShader; }
  void printDebugMap() const {}

  float getHeight(float x, float z) const;
  glm::vec3 getNormalAt(float x, float z) const;
  float getRoadAt(float x, float z) const;

  enum class Zone {
    SEA,
    PORT,
    MEDINA,
    WADI,
    VILLE_NOUVELLE,
    PLAIN,
    BEACH,
    KASBAH
  };
  Zone getZoneAt(float x, float z) const;
  mutable std::map<std::string, std::vector<glm::mat4>> cachedBatches;
  mutable bool batchesDirty = true;

  bool pointInPolygon(float x, float z,
                      const std::vector<glm::vec2> &polygon) const;

  ObjModel* getCityWallModel() const { return cityWallModel; }
  glm::mat4 getCityWallModelMatrix() const { return cityWallModelMat; }

private:
  mutable glm::mat4 cityWallModelMat = glm::mat4(1.0f);
  TerrainManager *terrainManager = nullptr;
  ObjModel *trainStationModel = nullptr;
  ObjModel *cityWallModel = nullptr;
  ObjModel *rockModel = nullptr;

  unsigned int waterVAO = 0, waterVBO = 0, waterEBO = 0;
  int waterIndexCount = 0;
  mutable unsigned int wallVAO = 0, wallVBO = 0, wallEBO = 0;
  mutable int wallIndexCount = 0;
  unsigned int flatNormalTex = 0;
  unsigned int normalMap1 = 0;
  unsigned int normalMap2 = 0;
  unsigned int foamTex = 0;
  unsigned int mapTexture = 0; // 1899 Sousse map projected onto terrain
  unsigned int sandDiff = 0;
  unsigned int sandNorm = 0;
  unsigned int rockDiff = 0;
  unsigned int rockNorm = 0;

  // Street rendering
  unsigned int streetVAO = 0, streetVBO = 0;
  int streetVertexCount = 0;
  Shader *streetShader = nullptr;

  std::vector<Monument> monuments;
  std::vector<Street> streets;
  std::vector<StreetPolyline> streetPolylines;

public:
  void renderStreets(const glm::mat4 &proj, const glm::mat4 &view,
                     const glm::vec3 &lightDir) const;
private:
  void buildWaterMesh();
  void initStreets();
  void buildStreetMesh();
  float distToSegment(float px, float pz, float x1, float z1, float x2,
                      float z2) const;
};

#endif