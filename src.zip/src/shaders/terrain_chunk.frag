#version 330 core
out vec4 FragColor;
in vec3 WorldPos, Normal;
in vec2 UV;

uniform sampler2DArray terrainTex;
uniform sampler2DArray terrainNormal;
uniform sampler2DArray terrainDisp;
// Optional roughness texture array (if bound)
uniform sampler2DArray terrainRough;
uniform sampler2D portMask;
uniform sampler2D roadMask;

uniform vec3 viewPos, lightDir, lightColor;
uniform float sunTilt;
uniform bool hasRoadMask;

// --- UTILS ---
float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x),
               mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}

// --- AAA PARALLAX OCCLUSION MAPPING ---
vec2 parallaxOcclusionMapping(vec2 texCoords, vec3 viewDirTangent, int layer, float heightScale) {
    float dist = length(viewPos - WorldPos);
    float stepFade = 1.0 - smoothstep(10.0, 45.0, dist);
    if (stepFade < 0.01) return texCoords;

    // Dynamic steps based on view angle for performance
    int numSteps = int(mix(12.0, 36.0, clamp(1.0 - viewDirTangent.z, 0.0, 1.0) * stepFade));
    float layerDepth = 1.0 / float(numSteps);
    float currentLayerDepth = 0.0;

    vec2 P = viewDirTangent.xy * heightScale * stepFade;
    vec2 deltaTexCoords = P / float(numSteps);
    vec2 currentTexCoords = texCoords;
    float currentDepth = texture(terrainDisp, vec3(currentTexCoords, float(layer))).r;

    for (int i = 0; i < 36; ++i) {
        if (i >= numSteps || currentLayerDepth >= currentDepth) break;
        currentTexCoords -= deltaTexCoords;
        currentDepth = texture(terrainDisp, vec3(currentTexCoords, float(layer))).r;
        currentLayerDepth += layerDepth;
    }

    vec2 prevTexCoords = currentTexCoords + deltaTexCoords;
    float afterDepth = currentDepth - currentLayerDepth;
    float beforeDepth = texture(terrainDisp, vec3(prevTexCoords, float(layer))).r - (currentLayerDepth - layerDepth);
    float weight = afterDepth / max(afterDepth - beforeDepth, 0.0001);
    return mix(currentTexCoords, prevTexCoords, weight);
}

// --- HEIGHT BLENDING ---
vec3 heightBlend(vec3 col1, float h1, vec3 col2, float h2, float factor) {
    float depth = 0.2;
    float ma = max(h1 + factor, h2 + (1.0 - factor)) - depth;
    float b1 = max(h1 + factor - ma, 0.0);
    float b2 = max(h2 + (1.0 - factor) - ma, 0.0);
    return (col1 * b1 + col2 * b2) / (b1 + b2);
}

#define DEBUG_LAYER_VIS 0  // Set to 1 for debug layer visualization

void main()
{
    vec3 N = normalize(Normal);
    vec3 V = normalize(viewPos - WorldPos);
    float dist = length(viewPos - WorldPos);

    // ── 1. CLASSIFICATION ────────────
    float splatVal = texture(portMask, UV).r;
    bool isHarbor = (splatVal > 0.3);

    float slope = 1.0 - N.y;
    float rockFactor = smoothstep(0.12, 0.38, slope + (hash(WorldPos.xz * 0.5) - 0.5) * 0.1);
    
    int baseLayer = isHarbor ? 2 : 0;
    int slopeLayer = 1;

    // Specular mask base initialization
    float specMask = isHarbor ? 0.4 : (WorldPos.y < 12.0 ? 0.3 : 0.05);

    // ── 2. TRIPLANAR SETUP ───────────
    float texScale = 0.045; 
    vec2 uvX = WorldPos.zy * texScale;
    vec2 uvY = WorldPos.xz * texScale;
    vec2 uvZ = WorldPos.xy * texScale;

    // Macro-variation to hide tiling
    float macro = noise(WorldPos.xz * 0.005) * 0.5 + 0.5;
    macro = mix(0.85, 1.15, macro);

    vec3 absN = abs(N);
    vec3 blending = pow(absN, vec3(10.0)); 
    blending /= (blending.x + blending.y + blending.z);

    // ── 3. PARALLAX (Only for top-down surfaces mostly) ──────────
    if (dist < 45.0) {
        vec3 viewW = normalize(WorldPos - viewPos);
        int pomLayer = (rockFactor > 0.5) ? slopeLayer : baseLayer;
        float basePomStr = isHarbor ? 0.04 : 0.03;
        // Fade POM based on how dominant the Y (top-down) projection is. This
        // prevents parallax artifacts on steep slopes where X/Z projections
        // dominate.
        float pomStr = basePomStr * blending.y;
        if (pomStr > 0.001) {
            uvY = parallaxOcclusionMapping(uvY, vec3(viewW.xz / max(abs(viewW.y), 0.1), 1.0), pomLayer, pomStr);
        }
    }

    // ── 4. TRIPLANAR SAMPLING WITH HEIGHT BLENDING ──────────────

    // ---- Base LAYER (sand, plain, etc) ----
    // Diffuse, normal, rough triplanar
    vec3 cXs = texture(terrainTex, vec3(uvX, float(baseLayer))).rgb;
    vec3 cYs = texture(terrainTex, vec3(uvY, float(baseLayer))).rgb;
    vec3 cZs = texture(terrainTex, vec3(uvZ, float(baseLayer))).rgb;
    float hXs = texture(terrainDisp, vec3(uvX, float(baseLayer))).r;
    float hYs = texture(terrainDisp, vec3(uvY, float(baseLayer))).r;
    float hZs = texture(terrainDisp, vec3(uvZ, float(baseLayer))).r;
    vec3 nXs = texture(terrainNormal, vec3(uvX, float(baseLayer))).rgb * 2.0 - 1.0;
    vec3 nYs = texture(terrainNormal, vec3(uvY, float(baseLayer))).rgb * 2.0 - 1.0;
    vec3 nZs = texture(terrainNormal, vec3(uvZ, float(baseLayer))).rgb * 2.0 - 1.0;
    float rXs = texture(terrainRough, vec3(uvX, float(baseLayer))).r;
    float rYs = texture(terrainRough, vec3(uvY, float(baseLayer))).r;
    float rZs = texture(terrainRough, vec3(uvZ, float(baseLayer))).r;
    vec3 colBase = (cXs * blending.x + cYs * blending.y + cZs * blending.z);
    float hBase = hXs * blending.x + hYs * blending.y + hZs * blending.z;
    vec3 nBase = normalize(vec3(nXs.z, nXs.y, nXs.x) * blending.x + vec3(nYs.x, nYs.z, nYs.y) * blending.y + vec3(nZs.x, nZs.y, nZs.z) * blending.z);
    float roughBase = rXs * blending.x + rYs * blending.y + rZs * blending.z;

    // ---- Slope LAYER (rock, etc) ----
    vec3 cXr = texture(terrainTex, vec3(uvX, float(slopeLayer))).rgb;
    vec3 cYr = texture(terrainTex, vec3(uvY, float(slopeLayer))).rgb;
    vec3 cZr = texture(terrainTex, vec3(uvZ, float(slopeLayer))).rgb;
    float hXr = texture(terrainDisp, vec3(uvX, float(slopeLayer))).r;
    float hYr = texture(terrainDisp, vec3(uvY, float(slopeLayer))).r;
    float hZr = texture(terrainDisp, vec3(uvZ, float(slopeLayer))).r;
    vec3 nXr = texture(terrainNormal, vec3(uvX, float(slopeLayer))).rgb * 2.0 - 1.0;
    vec3 nYr = texture(terrainNormal, vec3(uvY, float(slopeLayer))).rgb * 2.0 - 1.0;
    vec3 nZr = texture(terrainNormal, vec3(uvZ, float(slopeLayer))).rgb * 2.0 - 1.0;
    float rXr = texture(terrainRough, vec3(uvX, float(slopeLayer))).r;
    float rYr = texture(terrainRough, vec3(uvY, float(slopeLayer))).r;
    float rZr = texture(terrainRough, vec3(uvZ, float(slopeLayer))).r;
    vec3 colRock = (cXr * blending.x + cYr * blending.y + cZr * blending.z);
    float hRock = hXr * blending.x + hYr * blending.y + hZr * blending.z;
    vec3 nRock = normalize(vec3(nXr.z, nXr.y, nXr.x) * blending.x + vec3(nYr.x, nYr.z, nYr.y) * blending.y + vec3(nZr.x, nZr.y, nZr.z) * blending.z);
    float roughRock = rXr * blending.x + rYr * blending.y + rZr * blending.z;

    colBase = pow(max(colBase, vec3(0.0)), vec3(2.2));
    colRock = pow(max(colRock, vec3(0.0)), vec3(2.2));
    
    float blendFac = 1.0 - rockFactor;
    vec3 col = heightBlend(colBase, hBase, colRock, hRock, blendFac);
    col *= macro;
    vec3 nBlended = normalize(mix(nBase, nRock, rockFactor));
    float roughBlended = mix(roughBase, roughRock, rockFactor);


    // ── 5. ADVANCED NORMALS ──────────
    // Sample tangent-space normals for each projection plane (already done above)


    // Convert the per-plane (tangent-space) normals into world space using each
    // plane's basis vectors, then blend them. This is proper triplanar normal
    // (UDN-style) blending instead of naively adding tangent normals to N.
    float sx = sign(N.x);
    float sy = sign(N.y);
    float sz = sign(N.z);

    // For X projection (uvX = WorldPos.zy): tangent = +Z, bitangent = +Y, normal = +X
    vec3 nX_world = vec3(nXs.z * sx, nXs.y, nXs.x);
    // For Y projection (uvY = WorldPos.xz): tangent = +X, bitangent = +Z, normal = +Y
    vec3 nY_world = vec3(nYs.x, nYs.z * sy, nYs.y);
    // For Z projection (uvZ = WorldPos.xy): tangent = +X, bitangent = +Y, normal = +Z
    vec3 nZ_world = vec3(nZs.x, nZs.y, nZs.z * sz);

    vec3 blendedNormalWS = normalize(nX_world * blending.x + nY_world * blending.y + nZ_world * blending.z);

    // Maintain the previous "normal bump strength" (~0.7) by mixing the
    // geometric normal with the blended normal in world space.
    vec3 worldNormal = normalize(mix(N, blendedNormalWS, 0.7));

    // Optional: sample roughness map if available to override gloss heuristics later
    float sampledRough = -1.0;
    #ifdef GL_ES
    // nothing
    #endif
    // Note: we can't detect at compile-time whether the array is bound, but the
    // application binds terrainRough to unit 4 when available. To avoid runtime
    // errors when not bound, the CPU side ensures terrainRoughArray==0 is not
    // bound. Here we optimistically sample; if not bound the result may be 0.
    sampledRough = texture(terrainRough, vec3(uvY, float(baseLayer))).r;

    // ── 6. BEACH & WATERLINE ─────────
    if (!isHarbor && WorldPos.y < 12.5) {
        float beachFade = smoothstep(12.5, 7.5, WorldPos.y);
        // Use triplanar for beach to prevent stretching on dunes
        vec3 cXb = texture(terrainTex, vec3(uvX, 4.0)).rgb;
        vec3 cYb = texture(terrainTex, vec3(uvY, 4.0)).rgb;
        vec3 cZb = texture(terrainTex, vec3(uvZ, 4.0)).rgb;
        vec3 beachCol = (cXb * blending.x + cYb * blending.y + cZb * blending.z) * 1.4;
        beachCol = pow(beachCol, vec3(2.2)); // Linearize beach
        col = mix(col, beachCol, beachFade * (1.0 - rockFactor));
    }

    // ── 7. ROADS (Red-Channel Masking) ──────────────────────────
    if (hasRoadMask && WorldPos.y > 5.1 && !isHarbor) {
        float roadWeight = texture(roadMask, UV).r;
        float edgeFade = smoothstep(0.0, 0.02, UV.x) * smoothstep(1.0, 0.98, UV.x) *
                         smoothstep(0.0, 0.02, UV.y) * smoothstep(1.0, 0.98, UV.y);
        float roadFactor = smoothstep(0.8, 0.95, roadWeight) * edgeFade;

        if (roadFactor > 0.01) {
            vec2 rUV = UV * 12.0; 
            vec3 rCol = texture(terrainTex, vec3(rUV, 3.0)).rgb;
            rCol = pow(rCol, vec3(2.2)); // Linearize road
            
            vec3 rNorm = texture(terrainNormal, vec3(rUV, 3.0)).rgb * 2.0 - 1.0;
            vec3 rNorm_world = vec3(rNorm.x, rNorm.z, -rNorm.y);
            worldNormal = normalize(mix(worldNormal, normalize(rNorm_world * 0.8 + N * 0.2), roadFactor));
            
            vec3 dirtCol = texture(terrainTex, vec3(rUV * 0.2, 0.0)).rgb;
            dirtCol = pow(dirtCol, vec3(2.2)); // Linearize dirt
            rCol = mix(rCol, dirtCol, 0.08);
            rCol += (hash(WorldPos.xz * 15.0) - 0.5) * 0.015; // Subtle noise
            
            col = mix(col, rCol, roadFactor);
            specMask = mix(specMask, 0.2, roadFactor); 
        }
    }

    // ── 8. LIGHTING (PBR-LITE) ───────
    vec3 L = normalize(lightDir);
    float NdL = clamp(dot(worldNormal, L), 0.0, 1.0);
    float dayFactor = smoothstep(-0.15, 0.25, sunTilt);
    
    // Subsurface scattering-like bounce for sand/rocks
    float wrap = 0.2;
    float wrapNdL = clamp((dot(worldNormal, L) + wrap) / (1.0 + wrap), 0.0, 1.0);
    
    // Hemisphere Ambient (Sky/Ground mix)
    vec3 skyCol = vec3(0.4, 0.6, 1.0) * mix(0.1, 0.7, dayFactor);
    vec3 groundCol = vec3(0.3, 0.2, 0.1) * mix(0.05, 0.3, dayFactor);
    vec3 ambient = mix(groundCol, skyCol, worldNormal.y * 0.5 + 0.5) * col;

    // Vibrant Direct Sunlight (1.4x boost)
    vec3 diffuse = col * wrapNdL * (lightColor * 1.4) * dayFactor;
    
    float baseGloss = 0.12; 
    baseGloss = mix(baseGloss, 0.35, isHarbor ? 1.0 : 0.0);
    baseGloss = mix(baseGloss, 0.50, smoothstep(5.0, 12.0, WorldPos.y));

    float roadGloss = 0.0;
    if (hasRoadMask && WorldPos.y > 5.1 && !isHarbor) {
        float roadWeight = texture(roadMask, UV).r;
        float edgeFade = smoothstep(0.0, 0.02, UV.x) * smoothstep(1.0, 0.98, UV.x) *
                         smoothstep(0.0, 0.02, UV.y) * smoothstep(1.0, 0.98, UV.y);
        float rFactor = smoothstep(0.8, 0.95, roadWeight) * edgeFade;
        roadGloss = rFactor * 1.3;
    }

    float slopeMatte = 1.0 - smoothstep(0.25, 0.70, slope);
    baseGloss *= slopeMatte;

    float gloss = clamp(max(baseGloss, roadGloss), 0.01, 1.0);
    if (sampledRough >= 0.0) {
        gloss = mix(gloss, 1.0 - clamp(sampledRough, 0.0, 1.0), 0.6);
    }

    float specExp = mix(6.0, 196.0, gloss);
    vec3 halfwayDir = normalize(L + V);
    float spec = pow(max(dot(worldNormal, halfwayDir), 0.0), specExp);

    float finalSpecMask = specMask;
    finalSpecMask *= mix(1.0, 0.4, smoothstep(0.25, 0.6, slope));
    finalSpecMask = max(finalSpecMask, roadGloss * 1.2);

    vec3 specular = spec * finalSpecMask * lightColor * dayFactor;

    vec3 result = ambient + diffuse + specular;

    // ACES Tonemapping
    result = (result * (2.51 * result + 0.03)) / (result * (2.43 * result + 0.59) + 0.14);
    
    // Gamma Correction
    result = pow(max(result, vec3(0.0)), vec3(1.0 / 2.2));

    // Fog
    float fogAmt = clamp(1.0 - exp(-dist * 0.00015), 0.0, 0.85);
    vec3 fogCol = mix(vec3(0.6, 0.62, 0.65), vec3(0.85, 0.83, 0.78), dayFactor);
    
    FragColor = vec4(mix(result, fogCol, fogAmt), 1.0);
}
