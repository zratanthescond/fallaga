#version 330 core

layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in vec2 aTexCoords;
layout (location = 3) in ivec4 aBoneIDs;
layout (location = 4) in vec4 aWeights;

out vec2 TexCoords;
out vec3 Normal;
out vec3 FragPos;

const int MAX_BONES = 200;
uniform mat4 gBones[MAX_BONES];
uniform mat4 projection;
uniform mat4 view;
uniform mat4 model;

void main() {
    mat4 boneTransform = mat4(0.0);
    float totalWeight = 0.0;
    
    // Safety check for bone IDs and weights
    for(int i = 0; i < 4; i++) {
        if(aBoneIDs[i] >= 0 && aBoneIDs[i] < MAX_BONES) {
            boneTransform += gBones[aBoneIDs[i]] * aWeights[i];
            totalWeight += aWeights[i];
        }
    }
    
    // If no valid weights found, use identity (T-pose fallback)
    if(totalWeight < 0.01) {
        boneTransform = mat4(1.0);
    }

    vec4 pos = boneTransform * vec4(aPos, 1.0);
    gl_Position = projection * view * model * pos;
    
    // Transform normals
    mat3 normalMatrix = mat3(transpose(inverse(model * boneTransform)));
    Normal = normalMatrix * aNormal;
    
    FragPos = vec3(model * pos);
    TexCoords = aTexCoords;
}