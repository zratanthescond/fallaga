#version 330 core
out vec4 FragColor;

in vec2 TexCoords;
in vec3 FragPos;
in vec3 Normal;      // analytic Gerstner normal from vertex shader
in float WaveHeight;

uniform sampler2D depthMap;
uniform sampler2D sceneColor;
uniform sampler2D reflectionTex;
uniform sampler2D normalMap1;
uniform sampler2D normalMap2;
uniform sampler2D foamTexture;
uniform sampler2D causticsTex;
uniform sampler2D heightmapTex;   // terrain heightmap for exact land masking

uniform vec3  cameraPos;
uniform vec3  lightDir;    // real-time sun/moon direction from Game.cpp
uniform mat4  projection;
uniform mat4  view;
uniform float time;
uniform float sunTilt;     // lightDir.y: >0 day, ~0 sunset, <0 night

// Heightmap terrain bounds (set from C++)
uniform float hmMinElev;
uniform float hmMaxElev;
uniform float hmWorldMinX;
uniform float hmWorldMaxX;
uniform float hmWorldMinZ;
uniform float hmWorldMaxZ;
uniform float waterLevel;   // WATER_BASE from C++ = 5.0
uniform int   useHeightmap;

// ================================================================
//  UTILITIES
// ================================================================
float linearizeDepth(float d)
{
    const float near = 0.1, far = 1000.0;
    float z = d * 2.0 - 1.0;
    return (2.0 * near * far) / (far + near - z * (far - near));
}

vec2 getScreenUV(vec4 clip)
{
    return clip.xy / clip.w * 0.5 + 0.5;
}

// Schlick Fresnel — physically based
float fresnel_schlick(float cosTheta, float F0)
{
    return F0 + (1.0 - F0) * pow(1.0 - cosTheta, 5.0);
}

// ================================================================
//  PROCEDURAL SKY  — mirrors sky.frag; uses real-time lightDir/sunTilt
// ================================================================
vec3 skyColor(vec3 dir)
{
    dir = normalize(dir);

    // Sky gradient matching sky.frag zones
    vec3 dayZ  = vec3(0.10, 0.50, 0.90), dayH  = vec3(0.50, 0.80, 1.00);
    vec3 setZ  = vec3(0.20, 0.10, 0.40), setH  = vec3(1.00, 0.40, 0.20);
    vec3 ngtZ  = vec3(0.01, 0.02, 0.06), ngtH  = vec3(0.03, 0.06, 0.12);

    vec3 skyZ, skyH;
    if (sunTilt > 0.1) {
        float f = smoothstep(0.1, 0.5, sunTilt);
        skyZ = mix(setZ, dayZ, f);  skyH = mix(setH, dayH, f);
    } else if (sunTilt > -0.1) {
        float f = smoothstep(-0.1, 0.1, sunTilt);
        skyZ = mix(ngtZ, setZ, f);  skyH = mix(ngtH, setH, f);
    } else {
        skyZ = ngtZ;  skyH = ngtH;
    }
    float t = clamp(dir.y * 0.5 + 0.5, 0.0, 1.0);
    vec3  sky = mix(skyH, skyZ, pow(t, 0.8));

    // Sun disc + halo
    float sunDot = max(dot(dir, normalize(lightDir)), 0.0);
    sky += vec3(1.0, 0.95, 0.80) * pow(sunDot, 200.0) * 8.0 * smoothstep(-0.1, 0.1, sunTilt);
    sky += vec3(1.0, 0.85, 0.60) * pow(sunDot,  12.0) * 0.4 * smoothstep(-0.1, 0.1, sunTilt);

    // Moon disc + halo (opposite dir)
    float moonDot = max(dot(dir, normalize(-lightDir)), 0.0);
    sky += vec3(0.80, 0.90, 1.00) * pow(moonDot, 300.0) * 2.0 * smoothstep(0.1, -0.1, sunTilt);
    sky += vec3(0.60, 0.70, 0.90) * pow(moonDot,  20.0) * 0.15 * smoothstep(0.1, -0.1, sunTilt);

    // Stars (night only) 
    vec2 starUV = floor(dir.xz / (abs(dir.y) + 0.01) * 60.0) / 60.0;
    float star  = fract(sin(dot(starUV, vec2(127.1, 311.7))) * 43758.5);
    star = step(0.985, star);
    sky += vec3(0.90, 0.95, 1.00) * star * 0.7 * clamp(-sunTilt * 4.0, 0.0, 1.0);

    return sky;
}

// ================================================================
//  SCREEN SPACE REFLECTION
// ================================================================
vec3 SSR(vec3 reflDir, vec2 uv, float startDepth)
{
    // Water reflects sky/scene ABOVE the surface.
    // Downward rays would sample the seafloor — reject them.
    if (reflDir.y < 0.01) return vec3(0.0);

    vec4 reflPt  = projection * view * vec4(cameraPos + reflDir * 3.0, 1.0);
    vec2 reflUV  = reflPt.xy / reflPt.w * 0.5 + 0.5;
    vec2 screenD = reflUV - uv;
    if (length(screenD) < 0.001) return vec3(0.0);
    screenD = normalize(screenD);

    const int   STEPS   = 24;
    const float STEP_SZ = 0.008;

    vec2  pos      = uv;
    float rayDepth = startDepth;

    for (int i = 0; i < STEPS; i++)
    {
        pos      += screenD * STEP_SZ;
        rayDepth -= STEP_SZ * 60.0;

        if (pos.x < 0.0 || pos.x > 1.0 || pos.y < 0.0 || pos.y > 1.0)
            return vec3(0.0);

        float sceneD = linearizeDepth(texture(depthMap, pos).r);

        if (sceneD < rayDepth)
        {
            vec2  e    = min(pos, 1.0 - pos);
            float fade = smoothstep(0.0, 0.07, min(e.x, e.y));
            float dist = float(i) / float(STEPS);
            return texture(sceneColor, pos).rgb * fade * (1.0 - dist * 0.5);
        }
    }
    return vec3(0.0);
}

// ================================================================
//  MAIN
// ================================================================
void main()
{
    // ---- Clip / Screen ----
    vec4 clipPos  = projection * view * vec4(FragPos, 1.0);
    if (clipPos.w <= 0.0) discard;
    vec2 screenUV = getScreenUV(clipPos);

    // ================================================================
    // TERRAIN HEIGHT MASK — discard water that is inside / on top of land
    // This is the most reliable method since it uses the actual heightmap,
    // independent of depth buffer precision or blit issues.
    // ================================================================
    if (useHeightmap == 1) {
        vec2 hmUV = vec2(
            (FragPos.x - hmWorldMinX) / (hmWorldMaxX - hmWorldMinX),
            (FragPos.z - hmWorldMinZ) / (hmWorldMaxZ - hmWorldMinZ)
        );
        hmUV = clamp(hmUV, 0.001, 0.999);

        float rawHM = texture(heightmapTex, hmUV).r;
        float terrainH = rawHM * (hmMaxElev - hmMinElev) + hmMinElev;

        // Organic shore: perturb the discard threshold with procedural noise
        // so the water edge is never a perfectly straight line
        float noiseUV = sin(FragPos.x * 0.07 + time * 0.3) * cos(FragPos.z * 0.05 - time * 0.2);
        float margin = 0.4 + noiseUV * 0.6;  // wavy margin: 0 to ~1.0m

        if (terrainH > waterLevel + margin)
            discard;

        // Smooth alpha fade as terrain approaches water level from below
        // This blends the water surface into the beach without a sharp polygon edge
        float shoreBlend = smoothstep(waterLevel + margin, waterLevel - 1.0, terrainH);
        // Store in a "global-like" fashion — we'll use it later for alpha
        // (alpha is multiplied at the end)

    // Use shoreBlend below to soften alpha
    }

    float rawScene   = texture(depthMap, screenUV).r;
    float waterNDC   = (clipPos.z / clipPos.w) * 0.5 + 0.5;
    float sceneL     = linearizeDepth(rawScene);
    float waterL     = linearizeDepth(waterNDC);
    float depthDiff  = sceneL - waterL;

    // Discard solid geometry occluding water
    if (depthDiff < -0.01) discard;

    float shore = clamp(depthDiff * 20.0, 0.0, 1.0);

    // ---- Normal ----
    // Two layers scrolling at calm Mediterranean pace
    vec2 nu1 = TexCoords * 2.5 + vec2(time * 0.008,  time * 0.004);
    vec2 nu2 = TexCoords * 7.0 + vec2(-time * 0.005, time * 0.007);
    vec3 dn1 = texture(normalMap1, nu1).rgb * 2.0 - 1.0;
    vec3 dn2 = texture(normalMap2, nu2).rgb * 2.0 - 1.0;

    // Blend detail normals with geometric normal (Gerstner vertex normal)
    // and flatten near shore for calm-looking shallow water
    vec3 geomN  = normalize(Normal);
    vec3 detailN = normalize(geomN + (dn1 + dn2) * 0.35);
    vec3 normal  = normalize(mix(vec3(0.0, 1.0, 0.0), detailN, shore));

    vec3 viewDir    = normalize(cameraPos - FragPos);
    vec3 reflectDir = reflect(-viewDir, normal);

    // ---- Sun direction (world) ----
    // Warm afternoon Mediterranean sun
    vec3 sunDir = normalize(vec3(0.55, 0.48, 0.40));

    // ---- Refraction ----
    vec2 distort   = normal.xz * 0.018 * shore;
    vec2 refractUV = clamp(screenUV + distort, 0.001, 0.999);
    vec3 refracted = texture(sceneColor, refractUV).rgb;
    refracted = pow(refracted, vec3(2.2)); // Linearize refracted background

    // ---- Water tint / Beer's law absorption ----
    // Strong Mediterranean palette — turquoise → cyan → deep navy
    vec3 colShallow = vec3(0.25, 0.82, 0.88);   // bright turquoise shallow
    vec3 colMid     = vec3(0.06, 0.52, 0.72);   // cyan mid-water
    vec3 colDeep    = vec3(0.00, 0.14, 0.30);   // deep navy blue
    vec3 colSSS     = vec3(0.10, 0.80, 0.88);   // subsurface scatter glow

    float dd = clamp(depthDiff * 0.28, 0.0, 1.0);
    vec3  waterTint = mix(colShallow, colMid, dd);
          waterTint = mix(waterTint, colDeep, dd * dd);

    // Subsurface scattering hint: shallows glow bright cyan from inside
    float sssStrength = (1.0 - shore) * 0.35;
    waterTint = mix(waterTint, colSSS, sssStrength);

    // Absorption: deep = strong tint, shallow = more refracted scene visible
    // Use a strong blend so the water doesn't look transparent
    float absorb = clamp(0.35 + depthDiff * 0.4, 0.35, 0.88);
    vec3  absorbed = mix(refracted, waterTint, absorb);

    // ---- Reflections ----
    vec3 ssr       = SSR(reflectDir, screenUV, waterL);
    vec3 sky       = skyColor(reflectDir);

    // Blend SSR hit with sky fallback
    float ssrHit   = smoothstep(0.0, 0.04, length(ssr));
    vec3  reflected = mix(sky, ssr, ssrHit);

    // ---- Fresnel (Schlick, physically based) ----
    float F0      = 0.04;  // water F0
    float NdotV   = max(dot(normal, viewDir), 0.0);
    float fresnelF = fresnel_schlick(NdotV, F0);

    // Smoothly capped — not pure 1 so we always see some water colour
    float fresnelCapped = min(fresnelF, 0.90);

    vec3 color = mix(absorbed, reflected, fresnelCapped);

    // ---- Sun/Moon specular on water surface ----
    // Day: bright warm sun glitter; Night: cool silver moon glitter
    vec3  realSunDir = normalize(lightDir);
    vec3  halfDir = normalize(viewDir + realSunDir);
    float NdotH   = max(dot(normal, halfDir), 0.0);

    // Day specular (sun)
    float specDay  = pow(NdotH, 256.0);
    vec3  sunSpec  = vec3(1.0, 0.95, 0.80) * specDay * 1.2
                   * smoothstep(-0.05, 0.15, sunTilt);  // fade out at sunset

    // Night specular (moon = opposite direction)
    vec3  moonDir  = normalize(-lightDir);
    vec3  halfMoon = normalize(viewDir + moonDir);
    float MdotH    = max(dot(normal, halfMoon), 0.0);
    float specNight = pow(MdotH, 128.0);
    vec3  moonSpec = vec3(0.70, 0.80, 1.00) * specNight * 0.6
                   * smoothstep(0.05, -0.15, sunTilt);  // fade in at night

    // Ambient light level from sky (dark at night, bright at day)
    float ambientLevel = mix(0.04, 1.0, smoothstep(-0.15, 0.2, sunTilt));

    color *= ambientLevel;  // Darken entire water at night
    color = mix(color, reflected, fresnelCapped);  // Re-blend after darkening
    color += sunSpec + moonSpec;

    // ---- Foam ----
    // Very large UV scale so foam looks organic, not tiled grids
    vec2 fuv1 = FragPos.xz * 0.012 + vec2(time * 0.035, time * 0.018);
    vec2 fuv2 = FragPos.xz * 0.007 - vec2(time * 0.022, time * 0.014);
    float f1  = texture(foamTexture, fuv1).r;
    float f2  = texture(foamTexture, fuv2).r;
    float foam = (f1 * 0.6 + f2 * 0.4);

    // Shore foam band — stronger nearer to land
    float shoreFoam = smoothstep(0.15, 0.0, depthDiff) * 1.2;
    // Wave crest foam — visible from steep portions of Gerstner waves
    float crestFoam = smoothstep(0.5, 1.0, WaveHeight) * 0.5;

    foam = clamp(foam * 0.4 + shoreFoam + crestFoam, 0.0, 1.0);

    // Foam slightly lit by sun — not pure white in shadows
    vec3 foamCol = mix(vec3(0.7, 0.75, 0.78), vec3(1.0), 0.5 + 0.5 * max(dot(normal, sunDir), 0.0));
    color = mix(color, foamCol, foam * 0.65);

    // ---- Caustics (shallow only) ----
    vec2 cauv1 = FragPos.xz * 0.16 + vec2(time * 0.07,  0.0);
    vec2 cauv2 = FragPos.xz * 0.16 + vec2(-time * 0.05, time * 0.03);
    float caus = texture(causticsTex, cauv1).r * texture(causticsTex, cauv2).r * 6.0;
    caus = pow(caus, 1.5);

    float causticMask = (1.0 - dd) * (1.0 - shoreFoam);
    color += vec3(0.2, 0.6, 0.7) * caus * 0.18 * causticMask;

    // ---- Final ----
    color = clamp(color, 0.0, 1.2);

    // ACES Tonemapping
    color = (color * (2.51 * color + 0.03)) / (color * (2.43 * color + 0.59) + 0.14);
    
    // Gamma Correction
    color = pow(color, vec3(1.0 / 2.2));

    // Transparent at shoreline, opaque on open water
    float alpha = mix(0.72, 0.98, fresnelCapped);
    alpha *= smoothstep(0.0, 0.12, depthDiff);

    FragColor = vec4(color, alpha);
}