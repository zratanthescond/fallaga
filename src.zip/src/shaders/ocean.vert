#version 330 core
layout (location = 0) in vec3 aPos;

out vec2 TexCoords;
out vec3 FragPos;
out vec3 Normal;
out float WaveHeight;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
uniform float time;

// =============================================================
//  Gerstner wave with analytic normal derivation
// =============================================================
struct GWave { vec2 dir; float steep, wavelength, speed; };

vec3 gerstner(inout vec3 pos, inout vec3 tangent, inout vec3 binorm,
              GWave w)
{
    float k  = 6.28318 / w.wavelength;
    float c  = sqrt(9.8 / k);
    vec2  d  = normalize(w.dir);
    float f  = k * dot(d, pos.xz) - w.speed * c * time;
    float a  = w.steep / k;

    tangent += vec3(
        -d.x * d.x * w.steep * sin(f),
        d.x  * w.steep * cos(f),
        -d.x * d.y * w.steep * sin(f)
    );
    binorm += vec3(
        -d.x * d.y * w.steep * sin(f),
        d.y  * w.steep * cos(f),
        -d.y * d.y * w.steep * sin(f)
    );

    pos.x += d.x * (a * cos(f));
    pos.z += d.y * (a * cos(f));
    pos.y += a * sin(f);
    return pos;
}

void main()
{
    // UV from world position (large scale so normals tile nicely)
    TexCoords = aPos.xz / 2500.0 * 80.0;

    vec3 pos    = aPos;
    vec3 tang   = vec3(1.0, 0.0, 0.0);
    vec3 binorm = vec3(0.0, 0.0, 1.0);

    // 4 overlapping Gerstner waves (sea swell → ripples)
    // Steepness MUST be kept low — total across all waves < 1.0
    // Otherwise vertices loop/spiral (Gerstner oversteep artifact)
    GWave waves[4];
    waves[0] = GWave(vec2(1.0,  0.2), 0.12, 30.0, 0.45);  // long ocean swell
    waves[1] = GWave(vec2(0.3,  1.0), 0.10, 16.0, 0.30);  // cross swell
    waves[2] = GWave(vec2(-0.7, 0.6), 0.07,  8.0, 0.35);  // medium ripple
    waves[3] = GWave(vec2(0.5, -0.9), 0.05,  4.0, 0.40);  // small ripple

    gerstner(pos, tang, binorm, waves[0]);
    gerstner(pos, tang, binorm, waves[1]);
    gerstner(pos, tang, binorm, waves[2]);
    gerstner(pos, tang, binorm, waves[3]);

    // Analytic normal from tangent & binormal (much smoother than flat!)
    Normal     = normalize(cross(binorm, tang));
    WaveHeight = pos.y;
    FragPos    = vec3(model * vec4(pos, 1.0));
    gl_Position = projection * view * vec4(FragPos, 1.0);
}