#version 330 core

in vec2 TexCoords;
in vec3 Normal;
in vec3 FragPos;

uniform sampler2D texture_diffuse1;
uniform sampler2D ourTexture; 
uniform vec3 lightPos;
uniform vec3 viewPos;
uniform vec3 lightColor;

out vec4 FragColor;

void main() {
    vec4 texColor = texture(texture_diffuse1, TexCoords);
    if (texColor.a < 0.01) texColor = texture(ourTexture, TexCoords);
    
    vec3 objectColor = texColor.rgb;
    
    // If texture is black, use a medium grey so we can see the mesh and motion
    if (length(objectColor) < 0.01) {
        objectColor = vec3(0.4); 
    } else {
        objectColor = pow(objectColor, vec3(2.2));
    }
    
    vec3 norm = normalize(Normal);
    vec3 L = normalize(lightPos); 
    vec3 V = normalize(viewPos - FragPos);
    float NdV = max(dot(norm, V), 0.0);
    float NdL = max(dot(norm, L), 0.0);

    float dayFactor = smoothstep(-0.15, 0.3, L.y);

    vec3 skyCol = vec3(0.4, 0.6, 1.0) * mix(0.1, 0.65, dayFactor);
    vec3 groundCol = vec3(0.3, 0.2, 0.1) * mix(0.05, 0.3, dayFactor);
    vec3 ambient = mix(groundCol, skyCol, norm.y * 0.5 + 0.5) * objectColor;

    vec3 diffuse = NdL * (lightColor * 1.45) * objectColor * dayFactor;

    vec3 halfwayDir = normalize(L + V);
    float spec = pow(max(dot(norm, halfwayDir), 0.0), 32.0);
    vec3 specular = spec * 0.15 * lightColor * dayFactor;
    
    float fresnel = pow(1.0 - NdV, 4.0) * 0.12;
    specular += fresnel * skyCol * dayFactor;

    vec3 result = ambient + diffuse + specular;
    
    // ACES Tonemapping
    result = (result * (2.51 * result + 0.03)) / (result * (2.43 * result + 0.59) + 0.14);
    result = pow(max(result, vec3(0.0)), vec3(1.0 / 2.2));

    FragColor = vec4(result, 1.0);
}