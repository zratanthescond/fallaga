#version 330 core

in vec3  FragPos;
in vec3  Normal;
in vec2  TexCoords;
in float WorldY;

out vec4 FragColor;

uniform vec3  lightDir;
uniform vec3  viewPos;
uniform float minHeight;
uniform float maxHeight;
uniform float lightning;
uniform float sunTilt;

uniform sampler2D sandDiff;
uniform sampler2D sandNorm;
uniform sampler2D rockDiff;
uniform sampler2D rockNorm;

// ── Utility ─────────────────────────────────────────────────────────────────
float remap(float v, float lo, float hi) {
    return clamp((v - lo) / (hi - lo), 0.0, 1.0);
}

// Classic smooth hash noise (no textures needed)
float hash(vec2 p) {
    p = fract(p * vec2(443.897, 441.423));
    p += dot(p, p + 19.19);
    return fract(p.x * p.y);
}
float noise2(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i),           hash(i + vec2(1,0)), f.x),
               mix(hash(i+vec2(0,1)), hash(i + vec2(1,1)), f.x), f.y);
}
float fbm(vec2 p, int oct) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < oct; i++) { v += a * (noise2(p) * 2.0 - 1.0); p *= 2.1; a *= 0.5; }
    return v;
}

// ── Triplanar Mapping ────────────────────────────────────────────────────────
// Projects 2D textures onto 3D surfaces without stretching/tearing
vec3 triplanar(sampler2D tex, vec3 p, vec3 n, float scale) {
    vec3 blending = abs(n);
    blending = normalize(max(blending, 0.00001)); // Force sum > 0
    float b = (blending.x + blending.y + blending.z);
    blending /= vec3(b);

    vec3 x = texture(tex, p.zy * scale).rgb;
    vec3 y = texture(tex, p.xz * scale).rgb;
    vec3 z = texture(tex, p.xy * scale).rgb;

    return x * blending.x + y * blending.y + z * blending.z;
}

// Optimized triplanar for normals (unpacks [0,1]->[-1,1])
vec3 triplanarNormal(sampler2D tex, vec3 p, vec3 n, float scale) {
    vec3 blending = abs(n);
    blending = normalize(max(blending, 0.00001));
    float b = (blending.x + blending.y + blending.z);
    blending /= vec3(b);

    vec3 x = texture(tex, p.zy * scale).rgb * 2.0 - 1.0;
    vec3 y = texture(tex, p.xz * scale).rgb * 2.0 - 1.0;
    vec3 z = texture(tex, p.xy * scale).rgb * 2.0 - 1.0;

    // Swizzle normals to correctly align with world axes
    x = vec3(x.z, x.y, x.x);
    z = vec3(z.x, z.y, z.z);

    return normalize(x * blending.x + y * blending.y + z * blending.z);
}

void main()
{
    vec3 N = normalize(Normal);
    if (N.y < 0.0) N = -N;

    float range = max(maxHeight - minHeight, 0.001);
    float t  = clamp((WorldY - minHeight) / range, 0.0, 1.0);  // 0=low, 1=Kasbah peak

    // ── Slope / steepness ─────────────────────────────────────────────────────
    float slope = 1.0 - abs(N.y);        // 0=flat, 1=vertical
    float slopeSq = slope * slope;

    // ── PBR Texture Blending ──────────────────────────────────────────────────
    float sandScaling = 0.15;
    float rockScaling = 0.1;

    // Sample high-quality textures from Poly Haven using triplanar projection
    vec3 sandCol = triplanar(sandDiff, FragPos, N, sandScaling);
    vec3 rockCol = triplanar(rockDiff, FragPos, N, rockScaling);
    vec3 sandN   = triplanarNormal(sandNorm, FragPos, N, sandScaling);
    vec3 rockN   = triplanarNormal(rockNorm, FragPos, N, rockScaling);

    // Apply existing white sand tinting and height-based color shifts to the texture
    vec3 c_coast   = vec3(1.0, 0.98, 0.92); // Brightest white
    vec3 c_beach   = vec3(0.95, 0.90, 0.82); 
    vec3 c_plain   = vec3(0.85, 0.78, 0.65);

    vec3 tint;
    if      (t < 0.04) tint = c_coast;
    else if (t < 0.12) tint = mix(c_coast, c_beach, remap(t, 0.04, 0.12));
    else               tint = mix(c_beach, c_plain, remap(t, 0.12, 1.0));

    sandCol *= tint;

    // Blend Sand and Rock based on steepness (slope)
    float rockBlend = smoothstep(0.20, 0.55, slope);
    vec3 col = mix(sandCol, rockCol, rockBlend);
    
    // Perturb geometric normal with the blended PBR normal
    vec3 blendedNormal = normalize(mix(sandN, rockN, rockBlend));
    N = normalize(N + blendedNormal * 0.4); 

    // Procedural variation over the textures to break repeating tiles
    float macro = fbm(FragPos.xz * 0.004, 3);
    col *= (1.0 + macro * 0.15);

    // ── Directional lighting ─────────────────────────────────────────────────
    vec3 L = normalize(lightDir);

    // Soften NdL with a Valve-style half-Lambert wrap
    float wrap     = 0.35;
    float NdL_raw  = dot(N, L);
    float NdL      = clamp((NdL_raw + wrap) / (1.0 + wrap), 0.0, 1.0);
    NdL            = NdL * NdL;     // square for nicer falloff

    // --- WETNESS NEAR WATER ---
    // Use a wider, noise-perturbed smoothstep for a natural, organic shoreline
    // instead of a sharp, straight cutoff
    float waterLvl = 5.0;
    // Perturb the wetness threshold with noise to break straight lines
    float shoreNoise = fbm(FragPos.xz * 0.015, 3) * 2.5;
    float wetEdge = waterLvl + 2.5 + shoreNoise;  // noisy upper shore bound
    float wetness = smoothstep(wetEdge, waterLvl - 0.5, WorldY);
    // Wet sand darkens and desaturates slightly
    col = mix(col, col * vec3(0.80, 0.80, 0.82), wetness * 0.45);

    // Day/night ambient and diffuse levels
    float dayFactor  = smoothstep(-0.15, 0.20, sunTilt);
    float ambientStr = mix(0.06, 0.58, dayFactor);  // very dark at night
    float diffuseStr = mix(0.04, 0.55, dayFactor);

    vec3 ambient  = col * ambientStr;
    vec3 diffuse  = col * NdL * diffuseStr;

    // Night tint — moonlit sand is cool blue-grey, not neutral
    float nightTint = clamp(-sunTilt * 3.0, 0.0, 1.0);
    ambient = mix(ambient, ambient * vec3(0.6, 0.65, 0.80), nightTint);
    diffuse = mix(diffuse, diffuse * vec3(0.5, 0.55, 0.75), nightTint);

    // Specular — wet shimmer on the sand
    vec3  V    = normalize(viewPos - FragPos);
    vec3  H    = normalize(L + V);
    float gloss = mix(8.0, 48.0, rockBlend + wetness * 0.5);
    float spec  = pow(max(dot(N, H), 0.0), gloss) * mix(0.02, 0.25, clamp(rockBlend + wetness * 0.82, 0.0, 1.0));
    
    // Extra moisture glisten
    float moisture = noise2(FragPos.xz * 2.5) * wetness;
    spec += moisture * 0.12;

    // Rim light from the sky (subtle blue-grey fill from above)
    float rim = max(0.0, 1.0 - dot(N, V));
    vec3 rimCol = vec3(0.55, 0.58, 0.65) * rim * rim * 0.10;

    vec3 final = ambient + diffuse + vec3(spec) + rimCol;

    // ── Distance haze — warm Saharan haze colour ──────────────────────────────
    float dist   = length(viewPos - FragPos);
    float fogAmt = 1.0 - exp(-dist * 0.00012);
    vec3  fogCol = vec3(0.80, 0.76, 0.67);  // warm pale haze
    final = mix(final, fogCol, clamp(fogAmt, 0.0, 0.75));

    // --- STORM LIGHTNING DISABLED ---
    // final += lightning * vec3(0.7, 0.8, 1.0);

    FragColor = vec4(clamp(final, 0.0, 1.0), 1.0);
}
