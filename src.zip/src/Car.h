#pragma once

#include "Shader.h"
#include "Vec3.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <string>

class Character;
class Camera;
class Terrain;
class ObjModel;

class Car {
public:
  // ── NESTED TYPES ──────────────────────────────
  enum class State {
      PARKED,
      ROAMING,    // AI logic
      DRIVEN      // Player logic
  };

  struct Engine {
    float rpm = 800.0f;
    int gear = 1; // 0=R, 1-6
    float throttle = 0.0f;
    float clutch = 1.0f; // 1.0 = engaged

    float minRPM = 800.0f;
    float maxRPM = 7500.0f;
    float gearRatios[8] = {-3.4f, 0,    3.8f, 2.6f,
                           1.8f,  1.3f, 1.0f, 0.8f}; // R, N, 1-6
    float finalDrive = 4.1f;

    float torqueCurve(float currentRPM) {
      float x = currentRPM / maxRPM;
      return 650.0f *
             (1.0f - 0.8f * (x - 0.6f) * (x - 0.6f)); // Punchier engine
    }
  };

  struct Wheel {
    glm::vec3 localPos;
    glm::vec3 worldPos;
    float radius = 0.35f;
    float spinAngle = 0.0f;
    float angularVelocity = 0.0f;

    float suspensionRest = 0.6f;
    float currentLength = 0.6f;
    float prevLength = 0.6f;
    float load = 0.0f;
    float compression = 0.0f;

    bool isFront = false;
    bool isDriven = true;

    // Debug Data
    float fx = 0, fy = 0;
    float kappa = 0, alpha = 0;
  };

  Car(State initialState = State::DRIVEN);
  ~Car();

  void update(float deltaTime, Terrain *terrain, float totalTime,
              Camera *camera = nullptr);
  void render(const glm::mat4 &projection, const glm::mat4 &view,
              Terrain *terrain);

  void mountCharacter(Character *character);
  void dismountCharacter(Character *character);

  // ── PUBLIC ACCESSORS ───────────────────────────
  Vec3 getPosition() const { return position; }
  Vec3 getVelocity() const { return velocity; }
  void setVelocity(const Vec3 &v) { velocity = v; }
  void setPositionXZ(float x, float z) {
    position.x = x;
    position.z = z;
  }
  void setPosition(const Vec3 &p) { position = p; }
  bool hasDriver() const { return m_Driver != nullptr; }
  Character *getDriver() const { return m_Driver; }
  float getSpeed() const;
  float getYaw() const { return yaw; }
  State getState() const { return state; }
  void setState(State s) { state = s; }
  int getGear() const { return engine.gear; }
  float getRPM() const { return engine.rpm; }
  float getThrottle() const { return engine.throttle; }
  const Wheel &getWheel(int i) const { return wheels[i]; }
  Shader &getShader() { return *carShader; }
  bool isDriving() const { return m_Driver != nullptr; }

  // ── UNIFIED COORDINATE BASIS ──────────────────
  glm::vec3 getForwardVector() const;
  glm::vec3 getRightVector() const;

private:
  Wheel wheels[4]; // 0:FL, 1:FR, 2:RL, 3:RR
  Engine engine;

  // ── PHYSICS STATE ──────────────────────────────
  Vec3 position;
  Vec3 velocity;
  glm::vec3 angularVel = glm::vec3(0);

  float yaw = 0.0f;
  float steerAngle = 0.0f;
  float driftAngle = 0.0f;

  // AI roaming
  State state;
  float aiTargetYaw = 0.0f;
  float aiThinkTimer = 0.0f;
  float aiLostTimer = 0.0f;
  float aiBestScanYaw = 0.0f;
  bool needsInitialSnap = true;

  float pitchAngle = 0.0f;
  float rollAngle = 0.0f;
  float bodyShake = 0.0f;

  glm::vec3 prevVel = glm::vec3(0);
  int teleLog = 0;

  bool isGrounded = true;
  Character *m_Driver = nullptr;

  ObjModel *model = nullptr;
  Shader *carShader = nullptr;

  int meshBody = -1;
  int meshFL = -1, meshFR = -1, meshBL = -1, meshBR = -1;
  glm::vec3 wheelOffsetFL, wheelOffsetFR, wheelOffsetBL, wheelOffsetBR;
  glm::vec3 carCenter;

  float m_Wheelbase = 2.8f;
  float m_TrackWidth = 1.6f;
  float m_VerticalOffset = 0.0f;

  static constexpr float MASS = 1450.0f;
  static constexpr float GRAVITY = -9.81f;
  static constexpr float MAX_STEER_ANGLE = 0.65f;
  static constexpr float SCALE_FACTOR = 0.033f;
  static constexpr float MAX_SUSPENSION_TRAVEL = 0.15f;

  float SPRING_K = 45000.0f;
  float SPRING_DAMPING = 15000.0f;
  float INERTIA_PITCH = 1200.0f;
  float INERTIA_ROLL = 800.0f;
  float INERTIA_YAW = 2200.0f;
  float BODY_DAMPING = 0.96f;

  void resolveWheelMeshes();
  glm::vec3 getWheelWorld(const glm::vec3 &localOffset) const;
  // Yaw-only wheel XZ contact patch — no pitch/roll feedback, safe for terrain
  // queries
  glm::vec3 getWheelContactPatch(const glm::vec3 &localOffset) const;

  // ── PHYSICS SUBSYSTEMS ────────────────────────
  void updateActivePhysics(float dt, Terrain *terrain);
  void updateIdlePhysics(float dt, Terrain *terrain);
  void updateRoamingAI(float dt, Terrain *terrain, float totalTime);

  void processInput(float dt, bool &gas, bool &braking, bool &handbrake);
  void updateTransmission(float dt, bool gas, bool braking);
  void updateSuspension(float sdt, Terrain *terrain, glm::vec3 &totalForce);
  void calculateTireForces(float sdt, Terrain *terrain, glm::vec3 &totalForce,
                           glm::vec3 &totalTorque);
  void applyStabilityControl(float sdt, Terrain *terrain,
                             glm::vec3 &totalTorque);
  void applyAerodynamics(float dt, glm::vec3 &totalForce);

  float tireForce(float slip, float load);
};