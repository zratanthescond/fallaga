#include "ObjectModel.h"

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <limits>
#include <cmath>
#include <map>
#include <assimp/Exporter.hpp>
#define GLM_ENABLE_EXPERIMENTAL
#include <stb_image.h>
#include <assimp/scene.h>
#include <assimp/Importer.hpp>
#include <assimp/postprocess.h> 
#include <assimp/config.h>
#include <filesystem>
#include "Vec3.h"
#include "TextureEngine.h"
#include "Shader.h"
#include <glm/glm.hpp>
#include <glm/gtx/norm.hpp> // For glm::normalize
#include <glm/gtc/matrix_inverse.hpp> // For glm::inverse
#include <glm/gtc/matrix_transform.hpp> // For matrix operations
bool ObjModel::rayTriangleIntersect(
     const Vec3& rayOrigin,
     const Vec3& rayDir,
     const Vec3& v0, 
     const Vec3& v1, 
     const Vec3& v2,
     float& outT) const {
     const float EPSILON = 0.0000001f;

     Vec3 edge1 = v1 - v0;
     Vec3 edge2 = v2 - v0;

     Vec3 h = rayDir.cross(edge2); 

     float a = edge1.dot( h);

     if (a > -EPSILON && a < EPSILON) { return false; }

     float f = 1.0f / a;
     Vec3 s = rayOrigin - v0;

     float u = f * s.dot( h);

     if (u < 0.0f || u > 1.0f) { return false; }

     Vec3 q = s.cross( edge1);

     float v = f * rayDir.dot( q);

     if (v < 0.0f || u + v > 1.0f) { return false; }

     float t = f * edge2.dot( q);

     if (t > EPSILON) {
         outT = t;
         return true;
     }

     return false;
}

static glm::vec3 closestPointOnTriangle(glm::vec3 p, glm::vec3 a, glm::vec3 b, glm::vec3 c) {
    glm::vec3 ab = b - a;
    glm::vec3 ac = c - a;
    glm::vec3 ap = p - a;
    
    float d1 = glm::dot(ab, ap);
    float d2 = glm::dot(ac, ap);
    if (d1 <= 0.0f && d2 <= 0.0f) return a;
    
    glm::vec3 bp = p - b;
    float d3 = glm::dot(ab, bp);
    float d4 = glm::dot(ac, bp);
    if (d3 >= 0.0f && d4 <= d3) return b;
    
    float vc = d1*d4 - d3*d2;
    if (vc <= 0.0f && d1 >= 0.0f && d3 <= 0.0f) {
        float v = d1 / (d1 - d3);
        return a + v * ab;
    }
    
    glm::vec3 cp = p - c;
    float d5 = glm::dot(ab, cp);
    float d6 = glm::dot(ac, cp);
    if (d6 >= 0.0f && d5 <= d6) return c;
    
    float vb = d5*d2 - d1*d6;
    if (vb <= 0.0f && d2 >= 0.0f && d6 <= 0.0f) {
        float w = d2 / (d2 - d6);
        return a + w * ac;
    }
    
    float va = d3*d6 - d5*d4;
    if (va <= 0.0f && (d4 - d3) >= 0.0f && (d5 - d6) >= 0.0f) {
        float w = (d4 - d3) / ((d4 - d3) + (d5 - d6));
        return b + w * (c - b);
    }
    
    float denom = 1.0f / (va + vb + vc);
    float v = vb * denom;
    float w = vc * denom;
    return a + ab * v + ac * w;
}

bool ObjModel::checkSphereCollision(const glm::vec3& centerLocal, float radiusLocal, glm::vec3& outNormalLocal, float& outDepthLocal) const {
    float maxDepth = -1.0f;
    glm::vec3 bestNormal(0.0f, 1.0f, 0.0f);
    bool hit = false;
    float radSq = radiusLocal * radiusLocal;

    for (const auto& mesh : meshes) {
        // Broadphase: Check against mesh AABB
        if (centerLocal.x + radiusLocal < mesh.minBound.x || centerLocal.x - radiusLocal > mesh.maxBound.x ||
            centerLocal.y + radiusLocal < mesh.minBound.y || centerLocal.y - radiusLocal > mesh.maxBound.y ||
            centerLocal.z + radiusLocal < mesh.minBound.z || centerLocal.z - radiusLocal > mesh.maxBound.z) {
            continue;
        }

        const aiMesh* aimesh = mesh.assimpMesh;
        if (!aimesh || !aimesh->HasPositions()) continue;

        for (size_t i = 0; i + 2 < mesh.indices.size(); i += 3) {
            const aiVector3D& av0 = aimesh->mVertices[mesh.indices[i]];
            const aiVector3D& av1 = aimesh->mVertices[mesh.indices[i+1]];
            const aiVector3D& av2 = aimesh->mVertices[mesh.indices[i+2]];
            
            glm::vec3 v0(av0.x, av0.y, av0.z);
            glm::vec3 v1(av1.x, av1.y, av1.z);
            glm::vec3 v2(av2.x, av2.y, av2.z);

            glm::vec3 closest = closestPointOnTriangle(centerLocal, v0, v1, v2);
            glm::vec3 diff = centerLocal - closest;
            float distSq = glm::dot(diff, diff);
            
            if (distSq < radSq && distSq > 0.000001f) {
                float dist = std::sqrt(distSq);
                float depth = radiusLocal - dist;
                
                // Calculate actual triangle normal
                glm::vec3 edge1 = v1 - v0;
                glm::vec3 edge2 = v2 - v0;
                glm::vec3 triNormal = glm::normalize(glm::cross(edge1, edge2));
                
                // FIX: Ensure normal points TOWARD the sphere center (consistent winding)
                // If diff points away from triNormal, flip the normal
                if (glm::dot(diff, triNormal) < 0.0f) {
                    triNormal = -triNormal;
                }
                
                if (depth > maxDepth) {
                    maxDepth = depth;
                    bestNormal = triNormal;
                    hit = true;
                }
            }
        }
    }
    
    if (hit) {
        outNormalLocal = bestNormal;
        outDepthLocal = maxDepth;
    }
    return hit;
}

// NEW: Sphere collision test with automatic world-to-local space transform
bool ObjModel::checkSphereCollisionWorld(
    const glm::vec3& centerWorld,        // Car position in world space
    float radiusWorld,                   // Car radius
    const glm::mat4& modelMatrix,        // Wall's model matrix
    glm::vec3& outNormalWorld,           // Output collision normal in world space
    float& outDepthWorld) const {
    
    // ────────────────────────────────────
    // Step 1: Transform sphere to local space
    // ────────────────────────────────────
    
    glm::mat4 invModel = glm::inverse(modelMatrix);
    glm::vec3 centerLocal = glm::vec3(invModel * glm::vec4(centerWorld, 1.0f));
    
    // Scale radius: The radius also needs to be scaled by the model matrix.
    // Extract uniform scale from the model matrix
    glm::vec3 scaleVec(
        glm::length(glm::vec3(modelMatrix[0])),
        glm::length(glm::vec3(modelMatrix[1])),
        glm::length(glm::vec3(modelMatrix[2]))
    );
    
    // For a sphere, use average scale (or you could use max for conservative collision)
    float avgScale = (scaleVec.x + scaleVec.y + scaleVec.z) / 3.0f;
    float radiusLocal = radiusWorld / avgScale;
    
    // ────────────────────────────────────
    // Step 2: Test collision in local space
    // ────────────────────────────────────
    
    glm::vec3 normalLocal;
    float depthLocal;
    bool hit = checkSphereCollision(centerLocal, radiusLocal, normalLocal, depthLocal);
    
    if (hit) {
        // ────────────────────────────────────
        // Step 3: Transform normal back to world space
        // ────────────────────────────────────
        
        // Use inverse-transpose matrix to transform normals correctly
        glm::mat3 invTransposeModel = glm::transpose(glm::inverse(glm::mat3(modelMatrix)));
        outNormalWorld = glm::normalize(invTransposeModel * normalLocal);
        
        // Depth needs to be scaled back to world space
        outDepthWorld = depthLocal * avgScale;
    }
    
    return hit;
}

// FIXED: Iterates over all vertices in all meshes for min/max Y.
void ObjModel::getMinMaxY(float& minY, float& maxY) const {
    if (meshes.empty()) {
        minY = 0.0f;
        maxY = 0.0f;
        return;
    }

    minY = std::numeric_limits<float>::max();
    maxY = -std::numeric_limits<float>::max();

    for (const auto& mesh : meshes) {
        const aiMesh* aimesh = mesh.assimpMesh;
        if (!aimesh || !aimesh->HasPositions()) continue;

        for (unsigned int i = 0; i < aimesh->mNumVertices; ++i) {
            float y = aimesh->mVertices[i].y;
            minY = std::min(minY, y);
            maxY = std::max(maxY, y);
        }
    }
    
    // Safety check for models with zero vertices in all meshes
    if (minY == std::numeric_limits<float>::max()) {
        minY = 0.0f;
        maxY = 0.0f;
    }
}

// ===============================
// Texture Loading (Kept)
// ===============================
void ObjModel::loadTexture(const std::string& textureFilename, unsigned int& textureID) {
    if (textureFilename.empty()) {
        textureID = 0;
        return;
    }

    std::filesystem::path texPath(textureFilename);
    std::string filenameOnly = texPath.filename().string();
    
    // 1. Try absolute/relative path as provided in MTL (cross-platform normalize)
    std::filesystem::path fullPathObj(basepath);
    fullPathObj /= textureFilename;
    std::string fullPath = fullPathObj.string();

    std::cout << "[ObjModel] Trying to load texture: " << fullPath << std::endl;
    textureID = TextureEngine::Instance().loadTexture(fullPath, true);

    // 2. Fallback: Try searching in the same directory as the model
    if (textureID == 0 && !basepath.empty()) {
        std::filesystem::path fallbackPathObj(basepath);
        fallbackPathObj /= filenameOnly;
        std::string fallbackPath = fallbackPathObj.string();
        
        if (fallbackPath != fullPath) {
            std::cout << "[ObjModel] Texture not found at original path. Trying fallback: " << fallbackPath << std::endl;
            textureID = TextureEngine::Instance().loadTexture(fallbackPath, true);
        }
    }

    if (textureID == 0) {
        std::cerr << "[ObjModel ERROR] : Could not find texture file: " << textureFilename << std::endl;
    }
}

static void loadEmbeddedTexture(const aiTexture* embeddedTexture, unsigned int& textureID) {
    if (!embeddedTexture) return;
    
    int width, height, nrChannels;
    unsigned char* data = nullptr;
    
    if (embeddedTexture->mHeight == 0) {
        data = stbi_load_from_memory(reinterpret_cast<unsigned char*>(embeddedTexture->pcData), 
                                     embeddedTexture->mWidth, &width, &height, &nrChannels, 0);
    } else {
        data = stbi_load_from_memory(reinterpret_cast<unsigned char*>(embeddedTexture->pcData), 
                                     embeddedTexture->mWidth * embeddedTexture->mHeight, &width, &height, &nrChannels, 0);
    }
    
    if (data) {
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);
        
        GLenum format = GL_RGB;
        if (nrChannels == 1) format = GL_RED;
        else if (nrChannels == 3) format = GL_RGB;
        else if (nrChannels == 4) format = GL_RGBA;
        
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
        
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        
        stbi_image_free(data);
        std::cout << "[ObjModel] Successfully extracted embedded texture (" << width << "x" << height << ")" << std::endl;
    }
}

// ===============================
// Material Processing (FIXED: Added color extraction)
// ===============================
void ObjModel::processMaterials() {
    materials.resize(scene->mNumMaterials);

    for (unsigned int i = 0; i < scene->mNumMaterials; i++) {
        aiMaterial* material = scene->mMaterials[i];
        Material& currentMtl = materials[i]; // Use a reference to easily update 
        
        // 1. Get Material Name
        aiString name;
        if (material->Get(AI_MATKEY_NAME, name) == AI_SUCCESS) {
            currentMtl.name = name.C_Str();
        } else {
            currentMtl.name = "default_material_" + std::to_string(i);
        }
        
        // 2. Get and Load Texture (Diffuse Map)
        aiString texturePath;
        if (material->GetTexture(aiTextureType_DIFFUSE, 0, &texturePath) == AI_SUCCESS) {
            const aiTexture* embedded = scene->GetEmbeddedTexture(texturePath.C_Str());
            if (embedded) {
                loadEmbeddedTexture(embedded, currentMtl.textureID);
            } else {
                loadTexture(texturePath.C_Str(), currentMtl.textureID); 
            }
        } else {
            currentMtl.textureID = 0;
        }

        // 2.1 Get and Load Normal Map (Bump Map)
        if (material->GetTexture(aiTextureType_NORMALS, 0, &texturePath) == AI_SUCCESS || 
            material->GetTexture(aiTextureType_HEIGHT, 0, &texturePath) == AI_SUCCESS) {
            const aiTexture* embedded = scene->GetEmbeddedTexture(texturePath.C_Str());
            if (embedded) {
                loadEmbeddedTexture(embedded, currentMtl.normalMapID);
            } else {
                loadTexture(texturePath.C_Str(), currentMtl.normalMapID);
            }
        } else {
            currentMtl.normalMapID = 0;
        }

        // 3. Extract Material Colors and Properties (NEW)
        aiColor3D color;
        float fValue;
        
        // Ambient Color (Ka)
        if (AI_SUCCESS == material->Get(AI_MATKEY_COLOR_AMBIENT, color)) {
            currentMtl.ambient[0] = color.r;
            currentMtl.ambient[1] = color.g;
            currentMtl.ambient[2] = color.b;
        }

        // Diffuse Color (Kd)
        if (AI_SUCCESS == material->Get(AI_MATKEY_COLOR_DIFFUSE, color)) {
            currentMtl.diffuse[0] = color.r;
            currentMtl.diffuse[1] = color.g;
            currentMtl.diffuse[2] = color.b;
        }

        // Specular Color (Ks)
        if (AI_SUCCESS == material->Get(AI_MATKEY_COLOR_SPECULAR, color)) {
            currentMtl.specular[0] = color.r;
            currentMtl.specular[1] = color.g;
            currentMtl.specular[2] = color.b;
        }

        // Shininess (Ns)
        if (AI_SUCCESS == material->Get(AI_MATKEY_SHININESS, fValue)) {
            currentMtl.shininess = fValue;
            // Assimp uses "power of 2" shininess, but OpenGL uses 0-128. 
            // We'll cap it just in case, though 0-100 is common for .mtl.
            currentMtl.shininess = std::min(currentMtl.shininess, 128.0f);
        }
    }
}
glm::vec3 ObjModel::getNormalAt(float x, float z) {
    
    // --- Sample Points ---
    // Use a small offset to sample the height change around the point (x, z)
    // Adjust 'SAMPLE_OFFSET' based on the scale and resolution of your terrain grid.
    const float SAMPLE_OFFSET = 0.1f; 

    // 1. Get the height at the surrounding points
    // NOTE: This assumes you have a public getHeightAt(float x, float z) method.
    float hL = getHeightAt(x - SAMPLE_OFFSET, z); // Left
    float hR = getHeightAt(x + SAMPLE_OFFSET, z); // Right
    float hD = getHeightAt(x, z - SAMPLE_OFFSET); // Down (Back)
    float hU = getHeightAt(x, z + SAMPLE_OFFSET); // Up (Forward)

    // 2. Create the two tangent vectors that define the slope at (x, z)
    
    // Vector pointing from Left to Right (Tangent on X-axis)
    // The Y-component represents the height difference.
    glm::vec3 tangentX = glm::vec3(2.0f * SAMPLE_OFFSET, hR - hL, 0.0f); 

    // Vector pointing from Back to Forward (Tangent on Z-axis)
    // The Y-component represents the height difference.
    glm::vec3 tangentZ = glm::vec3(0.0f, hU - hD, 2.0f * SAMPLE_OFFSET);

    // 3. Calculate the normal vector (Normal is perpendicular to both tangents)
    // The order of the cross product matters for the direction (Up vs. Down).
    // Using cross(tangentX, tangentZ) gives the standard upward-pointing normal.
    glm::vec3 normal = glm::cross(tangentX, tangentZ);

    // 4. Normalize the result
    if (glm::length2(normal) > 1e-6) { // Safety check against a zero vector (perfectly flat area)
        return glm::normalize(normal);
    }

    // Default to a vertical normal if the area is perfectly flat or calculation failed
    return glm::vec3(0.0f, 1.0f, 0.0f);
}
// ===============================
// Scene Traversal (Kept)
// ===============================
void ObjModel::processNode(aiNode* node) {
    // Process all the node's meshes
    for (unsigned int i = 0; i < node->mNumMeshes; i++) {
        aiMesh* mesh = scene->mMeshes[node->mMeshes[i]];
        
        Mesh newMesh;
        newMesh.assimpMesh = mesh;
        newMesh.materialIndex = mesh->mMaterialIndex;
        // Use the NODE name (Blender object name like "body", "FL_wheel") 
        // not the mesh name (which is auto-generated by Assimp)
        newMesh.name = node->mName.C_Str();

        // Calculate AABB for this mesh
        newMesh.minBound = glm::vec3(std::numeric_limits<float>::max());
        newMesh.maxBound = glm::vec3(-std::numeric_limits<float>::max());
        if (mesh->HasPositions()) {
            for (unsigned int j = 0; j < mesh->mNumVertices; j++) {
                newMesh.minBound.x = std::min(newMesh.minBound.x, mesh->mVertices[j].x);
                newMesh.minBound.y = std::min(newMesh.minBound.y, mesh->mVertices[j].y);
                newMesh.minBound.z = std::min(newMesh.minBound.z, mesh->mVertices[j].z);
                newMesh.maxBound.x = std::max(newMesh.maxBound.x, mesh->mVertices[j].x);
                newMesh.maxBound.y = std::max(newMesh.maxBound.y, mesh->mVertices[j].y);
                newMesh.maxBound.z = std::max(newMesh.maxBound.z, mesh->mVertices[j].z);
            }
        }

        // Extract indices (faces) from Assimp's face structure
        for (unsigned int j = 0; j < mesh->mNumFaces; j++) {
            aiFace face = mesh->mFaces[j];
            for (unsigned int k = 0; k < face.mNumIndices; k++) {
                newMesh.indices.push_back(face.mIndices[k]);
            }
        }
        
        meshes.push_back(newMesh);
    }
    
    // Recurse for all children
    for (unsigned int i = 0; i < node->mNumChildren; i++) {
        processNode(node->mChildren[i]);
    }
}


// ===============================
// Model Loader (Main Constructor)
// ===============================
ObjModel::ObjModel(const std::string& filename) : scene(nullptr), displayList(0), filename(filename) {
    std::cout << "[ObjModel] Trying to load: " << filename << std::endl;

    // 1. Path Normalization & Verification
    std::filesystem::path p(filename);
    
    if (!std::filesystem::exists(p)) {
        std::cerr << "[ObjModel ERROR] : File does not exist at path: " << std::filesystem::absolute(p) << std::endl;
        createFallbackCube();
        return;
    }

    basepath = p.has_parent_path() ? p.parent_path().string() + "/" : "";
    
    // 2. Assimp Import
    Assimp::Importer importer; 
    scene = importer.ReadFile(p.string(), 
        aiProcess_Triangulate |      // Mandatory: ensures all faces are triangles
        aiProcess_GenSmoothNormals | // Generates smooth normals if none are provided
        aiProcess_CalcTangentSpace | // Calculates tangents/bitangents
        aiProcess_FlipUVs |          // Useful for most OpenGL applications
        aiProcess_JoinIdenticalVertices
    );

    if (!scene || scene->mFlags & AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode) {
        std::cerr << "[ObjModel ERROR] : Assimp failed to load " << filename << ". Error: " << importer.GetErrorString() << std::endl;
        createFallbackCube();
        return;
    }
    
    // 1. Process Materials/Textures/Colors
    std::cout << "Processing materials..." << std::endl;
    processMaterials();
    std::cout << "Materials processed." << std::endl;
    
    // 2. Process Nodes/Meshes
    std::cout << "Processing nodes..." << std::endl;
    processNode(scene->mRootNode);
    std::cout << "Nodes processed." << std::endl;

    // 3. Setup OpenGL Buffers (Modern)
    std::cout << "Setting up GPU buffers..." << std::endl;
    setupGPUBuffers();
    std::cout << "GPU buffers ready." << std::endl;

    std::cout << "Successfully loaded model with Assimp. Total meshes: " << meshes.size() << std::endl;
    for (int i = 0; i < (int)meshes.size(); i++) {
        std::cout << "  Mesh[" << i << "]: \"" << meshes[i].name << "\"" << std::endl;
    }

    // 4. Setup OpenGL Display List (Legacy)
    setupDisplayList();
}

ObjModel::~ObjModel()
{
    // Cleanup Modern Buffers
    for (auto& mesh : meshes) {
        if (mesh.VAO) glDeleteVertexArrays(1, &mesh.VAO);
        if (mesh.VBO) glDeleteBuffers(1, &mesh.VBO);
        if (mesh.EBO) glDeleteBuffers(1, &mesh.EBO);
    }
    
    // The importer's destructor automatically handles the deletion of the scene data.
    if (displayList) {
        glDeleteLists(displayList, 1);
        displayList = 0;
    }
}

// ===============================
// Rendering (FIXED: Applies material colors)
// ===============================
void ObjModel::setupDisplayList() {
    displayList = glGenLists(1);
    glNewList(displayList, GL_COMPILE);

    // --- FIX: Force Opaque State ---
    glDisable(GL_BLEND);         // Ensure transparency is OFF for the terrain
    glEnable(GL_DEPTH_TEST);     // Ensure the depth buffer is used correctly
    glDepthMask(GL_TRUE);        // Allow writing to the depth buffer

    glShadeModel(GL_SMOOTH); 

    for (const auto& mesh : meshes) {
        const Material& mtl = materials[mesh.materialIndex];

        // 🌟 BOOST AMBIENT LIGHT FOR ROCKS 🌟
        float boostedAmbient[4] = { mtl.ambient[0], mtl.ambient[1], mtl.ambient[2], 1.0f };
        if (filename.find("Rock") != std::string::npos || filename.find("rock") != std::string::npos) {
            boostedAmbient[0] = 0.8f; boostedAmbient[1] = 0.8f; boostedAmbient[2] = 0.8f;
        }

        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, boostedAmbient);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mtl.diffuse);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mtl.specular);
        glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, mtl.shininess);

        if (mtl.textureID) {
            glEnable(GL_TEXTURE_2D);
            glBindTexture(GL_TEXTURE_2D, mtl.textureID);
            
            // --- FIX: Force Texture to be Opaque ---
            // GL_REPLACE ignores the underlying vertex color/alpha
            // Use GL_MODULATE if you want lighting to affect the texture
            glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
        } else {
            glDisable(GL_TEXTURE_2D);
        }

        glBegin(GL_TRIANGLES);
        const aiMesh* aimesh = mesh.assimpMesh;
        for (unsigned int index : mesh.indices) {
            if (aimesh->HasNormals()) {
                const aiVector3D& n = aimesh->mNormals[index];
                glNormal3f(n.x, n.y, n.z);
            }
            if (aimesh->HasTextureCoords(0)) {
                const aiVector3D& t = aimesh->mTextureCoords[0][index]; 
                glTexCoord2f(t.x, t.y); 
            }
            const aiVector3D& v = aimesh->mVertices[index];
            glVertex3f(v.x, v.y, v.z);
        }
        glEnd();
    }

    glDisable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, 0);

    glEndList();
}

void ObjModel::createFallbackCube() {
    std::cout << "[ObjModel] Creating modern fallback cube..." << std::endl;
    
    // 1. Set up basic material
    Material fallbackMtl;
    fallbackMtl.name = "Fallback";
    fallbackMtl.diffuse[0] = 1.0f; fallbackMtl.diffuse[1] = 0.5f; fallbackMtl.diffuse[2] = 0.2f; // Orange-ish
    materials.push_back(fallbackMtl);

    // 2. Set up Mesh geometry (Standard cube)
    Mesh m;
    m.materialIndex = (unsigned int)materials.size() - 1;
    m.assimpMesh = nullptr; // Safety
    
    // Pre-calculated cube data: Pos(3), Norm(3), UV(2)
    std::vector<float> vertexData = {
        // Back
        -1,-1,-1,  0,0,-1,  0,0,   1,-1,-1,  0,0,-1,  1,0,   1, 1,-1,  0,0,-1,  1,1,  -1, 1,-1,  0,0,-1,  0,1,
        // Front
        -1,-1, 1,  0,0, 1,  0,0,   1,-1, 1,  0,0, 1,  1,0,   1, 1, 1,  0,0, 1,  1,1,  -1, 1, 1,  0,0, 1,  0,1,
        // Left
        -1, 1, 1, -1,0, 0,  1,0,  -1, 1,-1, -1,0, 0,  1,1,  -1,-1,-1, -1,0, 0,  0,1,  -1,-1, 1, -1,0, 0,  0,0,
        // Right
         1, 1, 1,  1,0, 0,  1,0,   1, 1,-1,  1,0, 0,  1,1,   1,-1,-1,  1,0, 0,  0,1,   1,-1, 1,  1,0, 0,  0,0,
        // Bottom
        -1,-1,-1,  0,-1,0,  0,1,   1,-1,-1,  0,-1,0,  1,1,   1,-1, 1,  0,-1,0,  1,0,  -1,-1, 1,  0,-1,0,  0,0,
        // Top
        -1, 1,-1,  0, 1,0,  0,1,   1, 1,-1,  0, 1,0,  1,1,   1, 1, 1,  0, 1,0,  1,0,  -1, 1, 1,  0, 1,0,  0,0
    };
    std::vector<unsigned int> indices = {
         0, 1, 2,  2, 3, 0,   4, 5, 6,  6, 7, 4,   8, 9,10, 10,11, 8,
        12,13,14, 14,15,12,  16,17,18, 18,19,16,  20,21,22, 22,23,20
    };

    m.indexCount = (unsigned int)indices.size();
    glGenVertexArrays(1, &m.VAO);
    glGenBuffers(1, &m.VBO);
    glGenBuffers(1, &m.EBO);

    glBindVertexArray(m.VAO);
    glBindBuffer(GL_ARRAY_BUFFER, m.VBO);
    glBufferData(GL_ARRAY_BUFFER, vertexData.size() * sizeof(float), vertexData.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);

    GLsizei stride = 8 * sizeof(float);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
    glBindVertexArray(0);

    meshes.push_back(m);

    // 3. Create legacy display list (just in case)
    displayList = glGenLists(1);
    glNewList(displayList, GL_COMPILE);
    glColor3f(1, 0.5f, 0.2f);
    glBegin(GL_QUADS);
    glVertex3f(-1,-1,1); glVertex3f(1,-1,1); glVertex3f(1,1,1); glVertex3f(-1,1,1);
    glEnd();
    glEndList();
}

void ObjModel::setupGPUBuffers() {
    for (auto& mesh : meshes) {
        std::vector<float> vertexData;
        const aiMesh* aimesh = mesh.assimpMesh;

        for (unsigned int i = 0; i < aimesh->mNumVertices; i++) {
            // Position (location 0)
            vertexData.push_back(aimesh->mVertices[i].x);
            vertexData.push_back(aimesh->mVertices[i].y);
            vertexData.push_back(aimesh->mVertices[i].z);

            // Normal (location 1)
            if (aimesh->HasNormals()) {
                vertexData.push_back(aimesh->mNormals[i].x);
                vertexData.push_back(aimesh->mNormals[i].y);
                vertexData.push_back(aimesh->mNormals[i].z);
            } else {
                vertexData.push_back(0.0f); vertexData.push_back(1.0f); vertexData.push_back(0.0f);
            }

            // TexCoords (location 2)
            if (aimesh->HasTextureCoords(0)) {
                vertexData.push_back(aimesh->mTextureCoords[0][i].x);
                vertexData.push_back(aimesh->mTextureCoords[0][i].y);
            } else {
                vertexData.push_back(0.0f); vertexData.push_back(0.0f);
            }

            // Tangent (location 3)
            if (aimesh->HasTangentsAndBitangents()) {
                vertexData.push_back(aimesh->mTangents[i].x);
                vertexData.push_back(aimesh->mTangents[i].y);
                vertexData.push_back(aimesh->mTangents[i].z);
            } else {
                vertexData.push_back(1.0f); vertexData.push_back(0.0f); vertexData.push_back(0.0f);
            }
        }

        mesh.indexCount = (unsigned int)mesh.indices.size();

        glGenVertexArrays(1, &mesh.VAO);
        glGenBuffers(1, &mesh.VBO);
        glGenBuffers(1, &mesh.EBO);

        glBindVertexArray(mesh.VAO);

        glBindBuffer(GL_ARRAY_BUFFER, mesh.VBO);
        glBufferData(GL_ARRAY_BUFFER, vertexData.size() * sizeof(float), vertexData.data(), GL_STATIC_DRAW);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.EBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, mesh.indices.size() * sizeof(unsigned int), mesh.indices.data(), GL_STATIC_DRAW);

        // Layout: Pos(3), Norm(3), UV(2), Tangent(3) = 11 floats total
        GLsizei stride = 11 * sizeof(float);
        
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
        
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
        
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));

        glEnableVertexAttribArray(7);
        glVertexAttribPointer(7, 3, GL_FLOAT, GL_FALSE, stride, (void*)(8 * sizeof(float)));

        glBindVertexArray(0);
    }
}


void ObjModel::render() const {
    if (displayList) glCallList(displayList);
}

void ObjModel::render(Shader& shader) const {
    shader.setBool("isInstanced", false);
    for (const auto& mesh : meshes) {
        const Material& mtl = materials[mesh.materialIndex];
        
        shader.setVec3("diffuseColor", glm::vec3(mtl.diffuse[0], mtl.diffuse[1], mtl.diffuse[2]));
        shader.setVec3("ambientColor", glm::vec3(mtl.ambient[0], mtl.ambient[1], mtl.ambient[2]));
        
        if (mtl.textureID != 0) {
            shader.setBool("hasTexture", true);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, mtl.textureID);
            shader.setInt("texture_diffuse1", 0);
        } else {
            shader.setBool("hasTexture", false);
        }

        if (mtl.normalMapID != 0) {
            shader.setBool("hasNormalMap", true);
            glActiveTexture(GL_TEXTURE1);
            glBindTexture(GL_TEXTURE_2D, mtl.normalMapID);
            shader.setInt("texture_normal1", 1);
        } else {
            shader.setBool("hasNormalMap", false);
        }

        glBindVertexArray(mesh.VAO);
        glDrawElements(GL_TRIANGLES, mesh.indexCount, GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
    }
}

void ObjModel::renderMesh(int meshIndex, Shader& shader) const {
    if (meshIndex < 0 || meshIndex >= (int)meshes.size()) return;
    
    const auto& mesh = meshes[meshIndex];
    const Material& mtl = materials[mesh.materialIndex];
    
    shader.setVec3("diffuseColor", glm::vec3(mtl.diffuse[0], mtl.diffuse[1], mtl.diffuse[2]));
    
    if (mtl.textureID != 0) {
        shader.setBool("hasTexture", true);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, mtl.textureID);
        shader.setInt("texture_diffuse1", 0);
    } else {
        shader.setBool("hasTexture", false);
    }

    glBindVertexArray(mesh.VAO);
    glDrawElements(GL_TRIANGLES, mesh.indexCount, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

void ObjModel::renderInstanced(Shader& shader, const std::vector<glm::mat4>& instanceMatrices) const {
    if (instanceMatrices.empty()) return;

    shader.setBool("isInstanced", true);

    for (const auto& mesh : meshes) {
        const Material& mtl = materials[mesh.materialIndex];
        
        shader.setVec3("diffuseColor", glm::vec3(mtl.diffuse[0], mtl.diffuse[1], mtl.diffuse[2]));
        shader.setVec3("ambientColor", glm::vec3(mtl.ambient[0], mtl.ambient[1], mtl.ambient[2]));
        
        if (mtl.textureID != 0) {
            shader.setBool("hasTexture", true);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, mtl.textureID);
            shader.setInt("texture_diffuse1", 0);
        } else {
            shader.setBool("hasTexture", false);
        }

        if (mtl.normalMapID != 0) {
            shader.setBool("hasNormalMap", true);
            glActiveTexture(GL_TEXTURE1);
            glBindTexture(GL_TEXTURE_2D, mtl.normalMapID);
            shader.setInt("texture_normal1", 1);
        } else {
            shader.setBool("hasNormalMap", false);
        }

        // Setup/Update Instance VBO
        if (mesh.instanceVBO == 0) {
            // This is a bit of a hack since 'mesh' is const, but we need to create the buffer.
            // In a real engine, we'd initialize this in setupGPUBuffers.
            const_cast<Mesh&>(mesh).instanceVBO = 0;
            glGenBuffers(1, &const_cast<Mesh&>(mesh).instanceVBO);
        }

        glBindVertexArray(mesh.VAO);
        glBindBuffer(GL_ARRAY_BUFFER, mesh.instanceVBO);
        glBufferData(GL_ARRAY_BUFFER, instanceMatrices.size() * sizeof(glm::mat4), instanceMatrices.data(), GL_DYNAMIC_DRAW);

        // Instance Model Matrix is at layout location 3 (takes 4 vec4 slots)
        for (unsigned int i = 0; i < 4; i++) {
            glEnableVertexAttribArray(3 + i);
            glVertexAttribPointer(3 + i, 4, GL_FLOAT, GL_FALSE, sizeof(glm::mat4), (void*)(i * sizeof(glm::vec4)));
            glVertexAttribDivisor(3 + i, 1); // This attribute changes once per instance
        }

        glDrawElementsInstanced(GL_TRIANGLES, mesh.indexCount, GL_UNSIGNED_INT, 0, (GLsizei)instanceMatrices.size());
        
        glBindVertexArray(0);
    }
}

// ===============================
// Height Query (Kept the correct Assimp adaptation)
// ===============================
float ObjModel::getHeightAt(float x, float z) const {
    float maxHeight = -std::numeric_limits<float>::max();
    Vec3 rayOrigin = { x, 1000.0f, z };
    Vec3 rayDir = { 0.0f, -1.0f, 0.0f };
    
    // Iterate over ALL meshes
    for (const auto& mesh : meshes) {
        // Optimization: Skip meshes whose AABB doesn't contain (x, z)
        if (x < mesh.minBound.x || x > mesh.maxBound.x || z < mesh.minBound.z || z > mesh.maxBound.z) {
            continue;
        }

        const aiMesh* aimesh = mesh.assimpMesh;
        if (!aimesh || !aimesh->HasPositions()) continue;

        // Iterate through indices 3 at a time (since they are guaranteed to be triangles)
        for (size_t i = 0; i + 2 < mesh.indices.size(); i += 3) {
            unsigned int idx0 = mesh.indices[i];
            unsigned int idx1 = mesh.indices[i+1];
            unsigned int idx2 = mesh.indices[i+2];

            const aiVector3D& av0 = aimesh->mVertices[idx0];
            const aiVector3D& av1 = aimesh->mVertices[idx1];
            const aiVector3D& av2 = aimesh->mVertices[idx2];
            
            Vec3 v0 = {av0.x, av0.y, av0.z};
            Vec3 v1 = {av1.x, av1.y, av1.z};
            Vec3 v2 = {av2.x, av2.y, av2.z};

            float t = 0.0f;
            if (rayTriangleIntersect(rayOrigin, rayDir, v0, v1, v2, t)) {
                float intersectionY = rayOrigin.y + t * rayDir.y;
                if (intersectionY > maxHeight) {
                    maxHeight = intersectionY;
                }
            }
        }
    }
    
    return (maxHeight == -std::numeric_limits<float>::max()) ? 0.0f : maxHeight;

}



