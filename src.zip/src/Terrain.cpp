#include "Terrain.h"
#include "PhysicsSystem.h"
#include "SousseMapData.h"
#include <GL/glew.h>
#ifdef HAS_GLUT
#include <GL/glut.h>
#endif
#include <GLFW/glfw3.h>
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stb_image.h>
#include <vector>
static constexpr float WATER_BASE = 5.0f; // Deep water mode
static float waterLevelOffset = 0.0f; // Positive raises terrain (lowers water)
// ----------------------------------------------------------------
//  Hash-based value noise — NO sine/cosine grids!
// ----------------------------------------------------------------
static float hashf(int x, int y) {
  // Integer hash with good avalanche mixing
  int h = x * 374761393 + y * 668265263;
  h = (h ^ (h >> 13)) * 1274126177;
  h = (h ^ (h >> 16));
  return (float)(h & 0x7FFFFFFF) / (float)0x7FFFFFFF * 2.0f - 1.0f; // [-1,1]
}

static float valueNoise2D(float x, float y) {
  int ix = (int)floorf(x), iy = (int)floorf(y);
  float fx = x - ix, fy = y - iy;
  // Smoothstep
  float ux = fx * fx * (3.0f - 2.0f * fx);
  float uy = fy * fy * (3.0f - 2.0f * fy);
  float v00 = hashf(ix, iy);
  float v10 = hashf(ix + 1, iy);
  float v01 = hashf(ix, iy + 1);
  float v11 = hashf(ix + 1, iy + 1);
  return v00 * (1 - ux) * (1 - uy) + v10 * ux * (1 - uy) + v01 * (1 - ux) * uy +
         v11 * ux * uy;
}

static float fbmNoise(float x, float y, int octaves) {
  float val = 0.0f, amp = 0.5f, freq = 1.0f;
  for (int i = 0; i < octaves; i++) {
    val += amp * valueNoise2D(x * freq, y * freq);
    freq *= 2.13f; // irrational multiplier avoids overtone cancellation
    amp *= 0.5f;
  }
  return val;
}

static unsigned int buildNormalMap(int sz = 512) {
  std::vector<unsigned char> px(sz * sz * 3);
  float scale = 8.0f; // lower = larger waves on the normal map
  float eps = 1.0f / sz;
  for (int y = 0; y < sz; ++y)
    for (int x = 0; x < sz; ++x) {
      float u = (float)x / sz, v = (float)y / sz;
      float dX = fbmNoise((u + eps) * scale, v * scale, 6) -
                 fbmNoise((u - eps) * scale, v * scale, 6);
      float dZ = fbmNoise(u * scale, (v + eps) * scale, 6) -
                 fbmNoise(u * scale, (v - eps) * scale, 6);
      float sc = 1.0f / (2.0f * eps);
      dX *= sc * 0.8f; // strength of normal
      dZ *= sc * 0.8f;
      float len = sqrtf(dX * dX + 1.0f + dZ * dZ);
      int i = (y * sz + x) * 3;
      auto cv = [](float f) -> unsigned char {
        int v = (int)(f * 255.0f);
        return (unsigned char)(v < 0 ? 0 : (v > 255 ? 255 : v));
      };
      px[i + 0] = cv(0.5f + 0.5f * (-dX / len));
      px[i + 1] = cv(0.5f + 0.5f * (1.0f / len));
      px[i + 2] = cv(0.5f + 0.5f * (-dZ / len));
    }
  unsigned int tid;
  glGenTextures(1, &tid);
  glBindTexture(GL_TEXTURE_2D, tid);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, sz, sz, 0, GL_RGB, GL_UNSIGNED_BYTE,
               px.data());
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
                  GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glGenerateMipmap(GL_TEXTURE_2D);
  glBindTexture(GL_TEXTURE_2D, 0);
  return tid;
}

static unsigned int buildFoamMap(int sz = 512) {
  std::vector<unsigned char> px(sz * sz);
  float scale = 6.0f;
  for (int y = 0; y < sz; ++y)
    for (int x = 0; x < sz; ++x) {
      float u = (float)x / sz, v = (float)y / sz;
      // High-frequency FBM for organic foam blobs
      float n = fbmNoise(u * scale, v * scale, 5);
      // Boost and clip to get bright sparse blobs
      float foam = powf(std::max(0.0f, n * 1.8f + 0.3f), 2.5f);
      int val = (int)(foam * 255.0f);
      px[y * sz + x] = (unsigned char)(val < 0 ? 0 : (val > 255 ? 255 : val));
    }
  unsigned int tid;
  glGenTextures(1, &tid);
  glBindTexture(GL_TEXTURE_2D, tid);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RED, sz, sz, 0, GL_RED, GL_UNSIGNED_BYTE,
               px.data());
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
                  GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glGenerateMipmap(GL_TEXTURE_2D);
  glBindTexture(GL_TEXTURE_2D, 0);
  return tid;
}

static unsigned int loadTexture2D(const char *path) {
  unsigned int textureID;
  glGenTextures(1, &textureID);
  int width, height, nrChannels;
  unsigned char *data = stbi_load(path, &width, &height, &nrChannels, 0);
  if (data) {
    GLenum format =
        (nrChannels == 1) ? GL_RED : (nrChannels == 3 ? GL_RGB : GL_RGBA);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format,
                 GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
                    GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    stbi_image_free(data);
    std::cout << "[Terrain] Loaded Texture: " << path << " (" << width << "x"
              << height << ")" << std::endl;
  } else {
    std::cerr << "[Terrain] FAILED to load texture: " << path << std::endl;
    stbi_image_free(data);
  }
  return textureID;
}

bool Terrain::isFlatMode = false;

Terrain::Terrain() {
  terrainManager = new TerrainManager("assets/terrain/heightmap.png",
                                      "assets/terrain/textureMap.png", -1250.0f,
                                      1250.0f, -2500.0f, 2500.0f, 0.0f, 59.9f);
  oceanShader = new Shader("src/shaders/ocean.vert", "src/shaders/ocean.frag");
  streetShader =
      new Shader("src/shaders/street.vert", "src/shaders/street.frag");
  modelShader = new Shader("src/shaders/model.vert", "src/shaders/model.frag");

  std::cout << "[Terrain] Initializing Water Mesh..." << std::endl;
  buildWaterMesh();
  flatNormalTex = buildNormalMap(512);
  normalMap1 = flatNormalTex;
  normalMap2 = buildNormalMap(512);
  foamTex = buildFoamMap(512);
  cityWallModel = new ObjModel("assets/moniment/mycityWall.fbx");
  rockModel = new ObjModel("assets/terrain/rocks/rock_moss_set_05_4k.obj");

  std::cout << "[Terrain] Initialization done." << std::endl;
}

Terrain::~Terrain() {
  if (waterVAO)
    glDeleteVertexArrays(1, &waterVAO);
  if (waterVBO)
    glDeleteBuffers(1, &waterVBO);
  if (waterEBO)
    glDeleteBuffers(1, &waterEBO);
  if (streetVAO)
    glDeleteVertexArrays(1, &streetVAO);
  if (streetVBO)
    glDeleteBuffers(1, &streetVBO);
  if (wallVAO)
    glDeleteVertexArrays(1, &wallVAO);
  if (wallVBO)
    glDeleteBuffers(1, &wallVBO);
  if (wallEBO)
    glDeleteBuffers(1, &wallEBO);

  // Cleanup Dynamic Asset Cache
  for (auto const &[path, model] : assetCache) {
    delete model;
  }
  assetCache.clear();

  delete terrainManager;
  delete terrainShader;
  delete oceanShader;
  delete streetShader;
  delete modelShader;
  delete cityWallModel;
  delete rockModel;
}

void Terrain::initStreets() {}
void Terrain::buildStreetMesh() {}
void Terrain::renderStreets(const glm::mat4 &proj, const glm::mat4 &view,
                            const glm::vec3 &lightDir) const {}
float Terrain::distToSegment(float px, float pz, float x1, float z1, float x2,
                             float z2) const {
  return 0.0f;
}

void Terrain::buildWaterMesh() {
  std::vector<glm::vec3> verts;
  std::vector<unsigned int> idx;
  int W = 512, H = 512; // Rust-Style density for sharp Gerstner waves
  float startX = -1250.0f, endX = 1250.0f;
  float startZ = -2500.0f, endZ = 2500.0f;

  for (int i = 0; i < H; ++i) {
    float fz = (float)i / (H - 1);
    float z = startZ + fz * (endZ - startZ);
    if (i == 0)
      z = -100000.0f;
    else if (i == H - 1)
      z = 100000.0f;
    for (int j = 0; j < W; ++j) {
      float fx = (float)j / (W - 1);
      float x = startX + fx * (endX - startX);
      if (j == 0)
        x = -100000.0f;
      else if (j == W - 1)
        x = 100000.0f;
      verts.push_back({x, WATER_BASE, z});
    }
  }
  for (int i = 0; i < H - 1; ++i) {
    for (int j = 0; j < W - 1; ++j) {
      int tl = i * W + j, tr = tl + 1, bl = tl + W, br = tl + W + 1;
      idx.push_back(tl);
      idx.push_back(bl);
      idx.push_back(tr);
      idx.push_back(tr);
      idx.push_back(bl);
      idx.push_back(br);
    }
  }
  waterIndexCount = (int)idx.size();
  glGenVertexArrays(1, &waterVAO);
  glGenBuffers(1, &waterVBO);
  glGenBuffers(1, &waterEBO);
  glBindVertexArray(waterVAO);
  glBindBuffer(GL_ARRAY_BUFFER, waterVBO);
  glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(glm::vec3), verts.data(),
               GL_STATIC_DRAW);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, waterEBO);
  glBufferData(GL_ELEMENT_ARRAY_BUFFER, idx.size() * sizeof(unsigned int),
               idx.data(), GL_STATIC_DRAW);
  glEnableVertexAttribArray(0);
  glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(glm::vec3), (void *)0);
  glBindVertexArray(0);
}

void Terrain::renderOpaque(const glm::mat4 &proj, const glm::mat4 &view,
                           const glm::vec3 &cam, const glm::vec3 &light,
                           const glm::vec3 &lightColor, int selectedIdx,
                           bool editMode) const {
  if (terrainManager) {
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    terrainManager->render(proj, view, cam, light, lightColor);
  }

  // --- PHASE 1: CACHED BATCH COLLECTION ---
  // Rebuild the matrix cache once per frame IF dirty.
  static bool firstRebuildDone = false;
  if (SousseMapData::layoutDirty || batchesDirty ||
      (!firstRebuildDone && cachedBatches.empty())) {
    cachedBatches.clear();

    // --- PROCEDURAL CITY WALL REBUILD ---
    if (wallVAO != 0) {
      glDeleteVertexArrays(1, &wallVAO);
      glDeleteBuffers(1, &wallVBO);
      glDeleteBuffers(1, &wallEBO);
      wallVAO = 0;
    }

    std::vector<glm::vec2> perimeter = SousseMapData::getMedinaPerimeter();
    struct WallVertex {
      glm::vec3 position;
      glm::vec3 normal;
      glm::vec2 texCoords;
      glm::vec3 tangent;
    };
    std::vector<WallVertex> vertices;
    std::vector<unsigned int> indices;

    float W = 20.0f; // thickness
    float H = 80.0f; // height (high walls!)

    for (size_t i = 0; i < perimeter.size() - 1; ++i) {
      glm::vec2 A = perimeter[i];
      glm::vec2 B = perimeter[i + 1];
      if (glm::length(B - A) < 0.1f)
        continue;

      float yA = terrainManager ? terrainManager->getHeightAt(A.x, A.y) : 0.0f;
      float yB = terrainManager ? terrainManager->getHeightAt(B.x, B.y) : 0.0f;

      glm::vec2 D = glm::normalize(B - A);
      glm::vec2 N = glm::vec2(-D.y, D.x);

      glm::vec2 C1 = A - N * (W / 2.0f);
      glm::vec2 C2 = B - N * (W / 2.0f);
      glm::vec2 C3 = B + N * (W / 2.0f);
      glm::vec2 C4 = A + N * (W / 2.0f);

      glm::vec3 V1b(C1.x, yA, C1.y);
      glm::vec3 V2b(C2.x, yB, C2.y);
      glm::vec3 V3b(C3.x, yB, C3.y);
      glm::vec3 V4b(C4.x, yA, C4.y);

      glm::vec3 V1t(C1.x, yA + H, C1.y);
      glm::vec3 V2t(C2.x, yB + H, C2.y);
      glm::vec3 V3t(C3.x, yB + H, C3.y);
      glm::vec3 V4t(C4.x, yA + H, C4.y);

      auto addQuad = [&](const glm::vec3 &p1, const glm::vec3 &p2,
                         const glm::vec3 &p3, const glm::vec3 &p4,
                         const glm::vec3 &normal) {
        unsigned int baseIdx = vertices.size();
        vertices.push_back(
            {p1, normal, glm::vec2(0.0f, 0.0f), glm::vec3(1.0f, 0.0f, 0.0f)});
        vertices.push_back(
            {p2, normal, glm::vec2(1.0f, 0.0f), glm::vec3(1.0f, 0.0f, 0.0f)});
        vertices.push_back(
            {p3, normal, glm::vec2(1.0f, 1.0f), glm::vec3(1.0f, 0.0f, 0.0f)});
        vertices.push_back(
            {p4, normal, glm::vec2(0.0f, 1.0f), glm::vec3(1.0f, 0.0f, 0.0f)});

        indices.push_back(baseIdx + 0);
        indices.push_back(baseIdx + 1);
        indices.push_back(baseIdx + 2);
        indices.push_back(baseIdx + 0);
        indices.push_back(baseIdx + 2);
        indices.push_back(baseIdx + 3);
      };

      // Outer side: V1b -> V2b -> V2t -> V1t
      addQuad(V1b, V2b, V2t, V1t, glm::vec3(-N.x, 0.0f, -N.y));

      // Inner side: V3b -> V4b -> V4t -> V3t
      addQuad(V3b, V4b, V4t, V3t, glm::vec3(N.x, 0.0f, N.y));

      // Top face: V1t -> V4t -> V3t -> V2t
      addQuad(V1t, V4t, V3t, V2t, glm::vec3(0.0f, 1.0f, 0.0f));
    }

    wallIndexCount = indices.size();
    if (wallIndexCount > 0) {
      glGenVertexArrays(1, &wallVAO);
      glGenBuffers(1, &wallVBO);
      glGenBuffers(1, &wallEBO);

      glBindVertexArray(wallVAO);

      glBindBuffer(GL_ARRAY_BUFFER, wallVBO);
      glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(WallVertex),
                   vertices.data(), GL_STATIC_DRAW);

      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, wallEBO);
      glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                   indices.size() * sizeof(unsigned int), indices.data(),
                   GL_STATIC_DRAW);

      // Position
      glEnableVertexAttribArray(0);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(WallVertex),
                            (void *)0);
      // Normal
      glEnableVertexAttribArray(1);
      glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(WallVertex),
                            (void *)offsetof(WallVertex, normal));
      // TexCoords
      glEnableVertexAttribArray(2);
      glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(WallVertex),
                            (void *)offsetof(WallVertex, texCoords));
      // Tangent
      glEnableVertexAttribArray(7);
      glVertexAttribPointer(7, 3, GL_FLOAT, GL_FALSE, sizeof(WallVertex),
                            (void *)offsetof(WallVertex, tangent));

      glBindVertexArray(0);
    }

    int placedCount = 0;
    for (auto &landmark : SousseMapData::liveLandmarks) {
      if (!landmark.placed)
        continue;
      if (landmark.modelPath.empty())
        continue;

      glm::vec2 worldPos = SousseMapData::toWorld(landmark.localOffset);
      float finalY = landmark.bakedY;
      if (finalY < -500000.0) { // Not baked
        Vec3 snapPos(worldPos.x, 0, worldPos.y);
        PhysicsSystem::snapToGround(snapPos, this, 0.1f);
        landmark.bakedY = snapPos.y;
        finalY = snapPos.y;
      }

      // Calculate Transform ONCE and store in cache
      glm::mat4 modelMat = glm::translate(
          glm::mat4(1.0f),
          glm::vec3(worldPos.x, finalY + landmark.yOffset, worldPos.y));
      modelMat = glm::rotate(modelMat, glm::radians(landmark.angle),
                             glm::vec3(0, 1, 0));
      modelMat =
          glm::scale(modelMat, glm::vec3(landmark.xScale, landmark.yScale,
                                         landmark.zScale));

      cachedBatches[landmark.modelPath].push_back(modelMat);
      placedCount++;
    }
    SousseMapData::layoutDirty = false;
    batchesDirty = false;
    firstRebuildDone = true;
    if (placedCount > 0) {
      std::cout << "[Librarian] : Rendering cache rebuilt for " << placedCount
                << " objects.\n";
    }
  }

  // --- PHASE 2: MODERN INSTANCED RENDERING ---
  if (modelShader) {
    modelShader->use();
    modelShader->setMat4("projection", proj);
    modelShader->setMat4("view", view);
    modelShader->setVec3("viewPos", cam);
    modelShader->setVec3("lightDir", light);
    modelShader->setVec3("lightColor", glm::vec3(1.1f, 1.05f, 0.95f));
    modelShader->setVec3("ambientColor", glm::vec3(0.4f, 0.45f, 0.5f));
    modelShader->setBool("hasTexture", true);
    modelShader->setBool("hasNormalMap", true);
    modelShader->setBool("deformToTerrain", false);

    for (auto const &[path, matrices] : cachedBatches) {
      if (assetCache.find(path) == assetCache.end()) {
        assetCache[path] = new ObjModel(path.c_str());
      }
      ObjModel *m = assetCache[path];
      if (m) {
        bool isDebris = (path.find("rock") != std::string::npos ||
                         path.find("rubble") != std::string::npos);
        if (isDebris) {
          glm::vec4 firstPos = matrices[0][3];
          float d2 =
              glm::dot(glm::vec3(firstPos) - cam, glm::vec3(firstPos) - cam);
          if (d2 > (400.0f * 400.0f))
            continue;
        }
        m->renderInstanced(*modelShader, matrices);
      }
    }
  }

  // --- PHASE 3: USER-PROVIDED CITY WALLS ---
  // CPU-side terrain grounding: sample terrain densely along perimeter,
  // find the lowest point, and bury the wall so it intersects ground
  // everywhere.
  if (cityWallModel && modelShader) {
    static bool wallDebugPrinted = false;

    std::vector<glm::vec2> perimeter = SousseMapData::getMedinaPerimeter();
    glm::vec2 pMin(1e9f, 1e9f), pMax(-1e9f, -1e9f);
    for (const auto &p : perimeter) {
      pMin = glm::min(pMin, p);
      pMax = glm::max(pMax, p);
    }

    glm::vec3 mMin(1e9f, 1e9f, 1e9f), mMax(-1e9f, -1e9f, -1e9f);
    for (int i = 0; i < cityWallModel->getMeshCount(); ++i) {
      mMin = glm::min(mMin, cityWallModel->getMeshMinBound(i));
      mMax = glm::max(mMax, cityWallModel->getMeshMaxBound(i));
    }

    float footprintX = pMax.x - pMin.x;
    float footprintZ = pMax.y - pMin.y;
    float modelX = mMax.x - mMin.x;
    float modelZ = mMax.z - mMin.z;

    float scaleXZ = 1.0f;
    if (modelX > 0.001f && modelZ > 0.001f) {
      scaleXZ = std::max(footprintX / modelX, footprintZ / modelZ);
    }

    // --- MANUAL TWEAKS ---
    auto& manualScaleX = SousseMapData::CityWallConfig::manualScaleX;
    auto& manualScaleY = SousseMapData::CityWallConfig::manualScaleY;
    auto& manualScaleZ = SousseMapData::CityWallConfig::manualScaleZ;
    auto& manualOffsetX = SousseMapData::CityWallConfig::manualOffsetX;
    auto& manualOffsetY = SousseMapData::CityWallConfig::manualOffsetY;
    auto& manualOffsetZ = SousseMapData::CityWallConfig::manualOffsetZ;
    auto& manualRotationY = SousseMapData::CityWallConfig::manualRotationY;

    GLFWwindow *window = glfwGetCurrentContext();
    if (window) {
      float speed = 100.0f * 0.016f;
      if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
        manualOffsetZ -= speed;
      if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
        manualOffsetZ += speed;
      if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        manualOffsetX -= speed;
      if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        manualOffsetX += speed;
      if (glfwGetKey(window, GLFW_KEY_PAGE_UP) == GLFW_PRESS)
        manualOffsetY += speed;
      if (glfwGetKey(window, GLFW_KEY_PAGE_DOWN) == GLFW_PRESS)
        manualOffsetY -= speed;
      if (glfwGetKey(window, GLFW_KEY_KP_ADD) == GLFW_PRESS ||
          glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        manualScaleX += 0.01f;
        manualScaleY += 0.01f;
        manualScaleZ += 0.01f;
      }
      if (glfwGetKey(window, GLFW_KEY_KP_SUBTRACT) == GLFW_PRESS ||
          glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) {
        manualScaleX -= 0.01f;
        manualScaleY -= 0.01f;
        manualScaleZ -= 0.01f;
      }
      if (glfwGetKey(window, GLFW_KEY_U) == GLFW_PRESS)
        manualScaleX -= 0.01f;
      if (glfwGetKey(window, GLFW_KEY_I) == GLFW_PRESS)
        manualScaleX += 0.01f;
      if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS)
        manualScaleZ -= 0.01f;
      if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS)
        manualScaleZ += 0.01f;
      if (glfwGetKey(window, GLFW_KEY_DELETE) == GLFW_PRESS ||
          glfwGetKey(window, GLFW_KEY_K) == GLFW_PRESS)
        manualRotationY -= 1.0f;
      if (glfwGetKey(window, GLFW_KEY_END) == GLFW_PRESS ||
          glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS)
        manualRotationY += 1.0f;

      static double lastPrint = 0.0;
      double now = glfwGetTime();
      if (now - lastPrint > 1.0) {
        std::cout << "[Live Wall Editor] Scale=(" << manualScaleX << ", "
                  << manualScaleY << ", " << manualScaleZ << ") Offset=("
                  << manualOffsetX << ", " << manualOffsetY << ", "
                  << manualOffsetZ << ") Rot=" << manualRotationY << std::endl;
        lastPrint = now;
      }
    }

    glm::vec3 scale(scaleXZ * manualScaleX, scaleXZ * manualScaleY,
                    scaleXZ * manualScaleZ);
    glm::vec2 pCenter = (pMin + pMax) * 0.5f;
    glm::vec3 mCenter = (mMin + mMax) * 0.5f;

    // --- Dense terrain sampling at ACTUAL wall positions (perimeter + offset)
    // --- The wall is shifted by manualOffsetX/Z, so sample terrain there, not
    // --- Dense terrain sampling at ACTUAL wall positions (transformed perimeter)
    auto transformedPerimeter = SousseMapData::getTransformedMedinaPerimeter();
    float minTerrainH = 1e9f;
    float maxTerrainH = -1e9f;
    if (terrainManager) {
      for (size_t i = 0; i + 1 < transformedPerimeter.size(); ++i) {
        glm::vec2 A = transformedPerimeter[i];
        glm::vec2 B = transformedPerimeter[i + 1];
        float segLen = glm::length(B - A);
        int steps = std::max(1, (int)(segLen / 5.0f));
        for (int s = 0; s <= steps; ++s) {
          float t = (float)s / (float)steps;
          glm::vec2 pt = A + t * (B - A);
          float h = terrainManager->getHeightAt(pt.x, pt.y);
          minTerrainH = std::min(minTerrainH, h);
          maxTerrainH = std::max(maxTerrainH, h);
        }
      }
      // Also sample at the offset center
      float hCenter = terrainManager->getHeightAt(pCenter.x + manualOffsetX,
                                                  pCenter.y + manualOffsetZ);
      minTerrainH = std::min(minTerrainH, hCenter);
      maxTerrainH = std::max(maxTerrainH, hCenter);
    } else {
      minTerrainH = 0.0f;
      maxTerrainH = 0.0f;
    }

    // The wall model has pillars/buttresses below the main wall body.
    // Bury the bottom half so the main wall section sits at terrain level.
    float modelScaledHeight = (mMax.y - mMin.y) * scale.y;
    float buryOffset = modelScaledHeight * 0.5f; // Hide bottom half underground
    float groundY = maxTerrainH - buryOffset;

    if (!wallDebugPrinted) {
      std::cout << "[CityWall] Model bounds: min=(" << mMin.x << "," << mMin.y
                << "," << mMin.z << ") max=(" << mMax.x << "," << mMax.y << ","
                << mMax.z << ")" << std::endl;
      std::cout << "[CityWall] Perimeter center=(" << pCenter.x << ","
                << pCenter.y << ") footprint=(" << footprintX << "x"
                << footprintZ << ")" << std::endl;
      std::cout << "[CityWall] scaleXZ=" << scaleXZ << " finalScale=("
                << scale.x << "," << scale.y << "," << scale.z << ")"
                << std::endl;
      std::cout << "[CityWall] Terrain range: min=" << minTerrainH
                << " max=" << maxTerrainH << std::endl;
      std::cout << "[CityWall] Wall base placed at Y=" << groundY
                << " (bury=" << buryOffset << ")" << std::endl;
      wallDebugPrinted = true;
    }

    glm::mat4 modelMat(1.0f);
    modelMat = glm::translate(modelMat, glm::vec3(pCenter.x + manualOffsetX,
                                                  groundY + manualOffsetY,
                                                  pCenter.y + manualOffsetZ));
    modelMat = glm::rotate(modelMat, glm::radians(manualRotationY),
                           glm::vec3(0, 1, 0));
    modelMat = glm::scale(modelMat, scale);
    modelMat =
        glm::translate(modelMat, glm::vec3(-mCenter.x, -mMin.y, -mCenter.z));
    
    cityWallModelMat = modelMat; // Store for physics engine

    modelShader->use();
    // Rigid placement — no per-vertex deformation (keeps wall shape intact)
    modelShader->setBool("deformToTerrain", false);

    modelShader->setMat4("projection", proj);
    modelShader->setMat4("view", view);
    modelShader->setVec3("viewPos", cam);
    modelShader->setVec3("lightDir", light);
    modelShader->setVec3("lightColor", glm::vec3(1.1f, 1.05f, 0.95f));
    modelShader->setVec3("ambientColor", glm::vec3(0.4f, 0.45f, 0.5f));
    modelShader->setBool("hasTexture", true);
    modelShader->setBool("hasNormalMap", true);
    modelShader->setVec3("diffuseColor", glm::vec3(0.85f, 0.75f, 0.6f));
    modelShader->setMat4("model", modelMat);
    modelShader->setBool("isInstanced", false);

    cityWallModel->render(*modelShader);

    if (rockModel) {
        std::vector<glm::mat4> rockInstances;
        for (size_t i = 0; i + 1 < transformedPerimeter.size(); ++i) {
            glm::vec2 A = transformedPerimeter[i];
            glm::vec2 B = transformedPerimeter[i + 1];
            glm::vec2 dir = B - A;
            float segLen = glm::length(dir);
            if (segLen < 0.1f) continue;
            dir /= segLen;
            
            glm::vec2 perp(-dir.y, dir.x);
            
            int numRocks = (int)(segLen / 12.0f); 
            srand((unsigned int)(i * 1234));
            for (int r = 0; r <= numRocks; ++r) {
                float t = (float)r * 12.0f;
                // Place a few rocks to form a solid base/rubble
                for (int w = -1; w <= 1; ++w) {
                    float rx = (rand() % 100 / 100.0f - 0.5f) * 6.0f; 
                    float rz = (rand() % 100 / 100.0f - 0.5f) * 6.0f;
                    
                    glm::vec2 pt = A + dir * (t + rx) + perp * ((float)w * 5.0f + rz);
                    
                    float h = 0.0f;
                    if (terrainManager) h = terrainManager->getHeightAt(pt.x, pt.y);
                    
                    float gap = groundY - h;
                    if (gap < -2.0f) continue; // Terrain is above wall base
                    
                    glm::mat4 mat(1.0f);
                    mat = glm::translate(mat, glm::vec3(pt.x, h - 1.0f, pt.y));
                    mat = glm::rotate(mat, (float)(rand() % 360) * 3.14159f / 180.0f, glm::vec3(0,1,0));
                    mat = glm::rotate(mat, (float)(rand() % 40 - 20) * 3.14159f / 180.0f, glm::vec3(1,0,0));
                    mat = glm::rotate(mat, (float)(rand() % 40 - 20) * 3.14159f / 180.0f, glm::vec3(0,0,1));
                    
                    // Scale it large enough to cover the gap
                    float rscale = 4.0f + (rand() % 100 / 50.0f);
                    float yscale = rscale * (1.0f + std::max(0.0f, gap / 8.0f)); 
                    mat = glm::scale(mat, glm::vec3(rscale, yscale, rscale));
                    rockInstances.push_back(mat);
                }
            }
        }
        
        if (!rockInstances.empty()) {
            modelShader->setBool("isInstanced", true);
            rockModel->renderInstanced(*modelShader, rockInstances);
            modelShader->setBool("isInstanced", false);
        }
    }
  }

  // --- PHASE 4: SELECTION GIZMOS / HUD ---
  if (editMode) {
    for (int i = 0; i < (int)SousseMapData::liveLandmarks.size(); ++i) {
      auto &landmark = SousseMapData::liveLandmarks[i];
      if (!landmark.placed)
        continue;

      bool isSelected = (i == selectedIdx);
      glm::vec2 worldPos = SousseMapData::toWorld(landmark.localOffset);
      float finalY = landmark.bakedY;
      if (finalY < -500000.0)
        continue;

      glDisable(GL_LIGHTING);
      glDisable(GL_TEXTURE_2D);

      if (isSelected) {
        glColor3f(0.0f, 1.0f, 1.0f);
        glLineWidth(4);
        glBegin(GL_LINES);
        glVertex3f(worldPos.x, finalY, worldPos.y);
        glVertex3f(worldPos.x, finalY + 150.0f, worldPos.y);
        glEnd();

        glPushMatrix();
        glTranslatef(worldPos.x + 2.0f, finalY + 10.0f, worldPos.y);
        glColor3f(1, 1, 1);
        std::stringstream hud;
        hud << landmark.name << " [R: " << (int)landmark.angle
            << " S: " << std::fixed << std::setprecision(1) << landmark.xScale
            << "]";
        std::string msg = hud.str();
        glRasterPos3f(0, 0, 0);
        for (char c : msg) {
#ifdef HAS_GLUT
          glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, c);
#endif
        }
        glPopMatrix();
      } else {
        float distSq = glm::dot(worldPos - glm::vec2(cam.x, cam.z),
                                worldPos - glm::vec2(cam.x, cam.z));
        if (distSq < (50.0f * 50.0f)) {
          glColor3f(0.3f, 0.3f, 0.3f);
          glLineWidth(1);
          glBegin(GL_LINES);
          glVertex3f(worldPos.x, finalY, worldPos.y);
          glVertex3f(worldPos.x, finalY + 30.0f, worldPos.y);
          glEnd();
        }
      }
      glEnable(GL_LIGHTING);
    }
  }

  // --- CITY WALL WIPED (User requested removal) ---
}

void Terrain::renderWater(const glm::mat4 &proj, const glm::mat4 &view,
                          const glm::vec3 &cam, const glm::vec3 &light,
                          const glm::vec3 &lightColor,
                          unsigned int sceneColorTex,
                          unsigned int sceneDepthTex) const {
  if (!waterVAO || !oceanShader)
    return;

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDepthMask(GL_FALSE); // Don't write water to depth buffer, just read from it

  oceanShader->use();
  oceanShader->setMat4("projection", proj);
  oceanShader->setMat4("view", view);
  oceanShader->setMat4("model", glm::mat4(1.0f));
  oceanShader->setVec3("cameraPos", cam);
  oceanShader->setVec3("lightDir", light);   // Real-time sun/moon direction
  oceanShader->setFloat("sunTilt", light.y); // >0 = day, <0 = night
  oceanShader->setVec3("lightColor", lightColor);
  oceanShader->setFloat("time", (float)glfwGetTime());

  // Bind Textures
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, sceneColorTex);
  oceanShader->setInt("sceneColor", 0);

  glActiveTexture(GL_TEXTURE1);
  glBindTexture(GL_TEXTURE_2D, sceneDepthTex);
  oceanShader->setInt("depthMap", 1);

  glActiveTexture(GL_TEXTURE2);
  glBindTexture(GL_TEXTURE_2D, normalMap1 ? normalMap1 : flatNormalTex);
  oceanShader->setInt("normalMap1", 2);

  glActiveTexture(GL_TEXTURE3);
  glBindTexture(GL_TEXTURE_2D, normalMap2 ? normalMap2 : flatNormalTex);
  oceanShader->setInt("normalMap2", 3);

  glActiveTexture(GL_TEXTURE4);
  glBindTexture(GL_TEXTURE_2D, foamTex ? foamTex : flatNormalTex);
  oceanShader->setInt("foamTexture", 4);

  // New Uniforms from user
  glActiveTexture(GL_TEXTURE5);
  glBindTexture(GL_TEXTURE_2D,
                sceneColorTex); // Fallback planar reflection to scene color
  oceanShader->setInt("reflectionTex", 5);

  glActiveTexture(GL_TEXTURE6);
  glBindTexture(GL_TEXTURE_2D,
                flatNormalTex); // Fallback caustics to a normal texture noise
  oceanShader->setInt("causticsTex", 6);

  glActiveTexture(GL_TEXTURE7);
  glBindTexture(GL_TEXTURE_2D, foamTex ? foamTex : flatNormalTex);
  oceanShader->setInt("noiseTex", 7);

  // Heightmap masking
  if (terrainManager) {
    glActiveTexture(GL_TEXTURE8);
    glBindTexture(GL_TEXTURE_2D, terrainManager->getHeightmapTexture());
    oceanShader->setInt("heightmapTex", 8);
    oceanShader->setFloat("hmMinElev", 0.0f);
    oceanShader->setFloat("hmMaxElev", 59.9f);
    oceanShader->setFloat("hmWorldMinX", -1250.0f);
    oceanShader->setFloat("hmWorldMaxX", 1250.0f);
    oceanShader->setFloat("hmWorldMinZ", -2500.0f);
    oceanShader->setFloat("hmWorldMaxZ", 2500.0f);
    oceanShader->setFloat("waterLevel", 5.0f);
    oceanShader->setInt("useHeightmap", 1);
  } else {
    oceanShader->setInt("useHeightmap", 0);
  }

  glBindVertexArray(waterVAO);
  glDrawElements(GL_TRIANGLES, waterIndexCount, GL_UNSIGNED_INT, nullptr);
  glBindVertexArray(0);

  glDepthMask(GL_TRUE);
  glDisable(GL_BLEND);
  glUseProgram(0);
}

float Terrain::getHeight(float x, float z) const {
  if (isFlatMode)
    return WATER_LEVEL;
  return terrainManager ? terrainManager->getHeightAt(x, z) : 0.0f;
}
glm::vec3 Terrain::getNormalAt(float x, float z) const {
  if (terrainManager)
    return terrainManager->getNormalAt(x, z);
  return glm::vec3(0, 1, 0);
}
float Terrain::getRoadAt(float x, float z) const {
  return terrainManager ? terrainManager->getRoadAt(x, z) : 0.0f;
}

Terrain::Zone Terrain::getZoneAt(float x, float z) const { return Zone::PLAIN; }
bool Terrain::pointInPolygon(float x, float z,
                             const std::vector<glm::vec2> &polygon) const {
  return false;
}