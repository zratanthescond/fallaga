#include "TerrainChunk.h"
#include <algorithm>

TerrainChunk::TerrainChunk(int x, int z, int size) : gridX(x), gridZ(z), size(size) {}
TerrainChunk::~TerrainChunk() {
    if (VAO) glDeleteVertexArrays(1, &VAO);
    if (VBO) glDeleteBuffers(1, &VBO);
    if (EBO) glDeleteBuffers(1, &EBO);
}

void TerrainChunk::generateMesh(const std::vector<float>& globalHeights, int globalW, int globalH,
                                float worldMinX, float worldMaxX, float worldMinZ, float worldMaxZ,
                                const std::vector<unsigned char>* roadMaskData, int roadW, int roadH) {
    std::vector<Vertex> vertices;
    std::vector<unsigned int> indices;
    int startCol = gridX * (size - 1);
    int startRow = gridZ * (size - 1);
    float dux = 1.0f / (globalW - 1);
    float duz = 1.0f / (globalH - 1);
    float stepX = 2.0f * dux * (worldMaxX - worldMinX);
    float stepZ = 2.0f * duz * (worldMaxZ - worldMinZ);

    // Road elevation parameters
    const float ROAD_HEIGHT_BOOST = 0.8f;  // How much roads bump up
    const float ROAD_WIDTH_FALLOFF = 2.0f; // How wide the crown extends
    const float SHOULDER_FALLOFF = 3.5f;   // How gradually roads blend to terrain
    const float MAX_SHOULDER_HEIGHT = 0.3f;// Max height of road shoulders

    for (int row = 0; row < size; ++row) {
        for (int col = 0; col < size; ++col) {
            int gCol = std::min(startCol + col, globalW - 1);
            int gRow = std::min(startRow + row, globalH - 1);
            
            float ux = (float)gCol / (globalW - 1);
            float uz = (float)gRow / (globalH - 1);
            float wx = worldMinX + ux * (worldMaxX - worldMinX);
            float wz = worldMinZ + uz * (worldMaxZ - worldMinZ);
            float wy = globalHeights[gRow * globalW + gCol];

            // --- Sample road mask to determine elevation boost ---
            float roadInfluence = 0.0f;
            if (roadMaskData && roadW > 0 && roadH > 0) {
                int roadX = (int)(ux * (roadW - 1));
                int roadZ = (int)(uz * (roadH - 1));
                roadX = std::min(std::max(roadX, 0), roadW - 1);
                roadZ = std::min(std::max(roadZ, 0), roadH - 1);
                
                // Sample road mask (red channel indicates road)
                float roadMaskVal = ((*roadMaskData)[(roadZ * roadW + roadX) * 4 + 0] / 255.0f);
                roadInfluence = (roadMaskVal < 0.8f) ? 0.0f : (roadMaskVal - 0.8f) / 0.2f;
            }

            // Apply road elevation with crown effect (parabolic shape)
            // The crown peaks at the center and falls off at edges
            float crowningFactor = 1.0f - (roadInfluence * roadInfluence); // Squared falloff for smooth crown
            float roadElevation = roadInfluence * ROAD_HEIGHT_BOOST * (1.0f - crowningFactor * ROAD_WIDTH_FALLOFF * 0.3f);
            
            // Add shoulder transition: roads gradually degrade to terrain at edges
            float shoulderBlend = 1.0f - std::pow(roadInfluence, 2.5f); // Steep initial, then gradual falloff
            float shoulderHeight = MAX_SHOULDER_HEIGHT * (1.0f - shoulderBlend) * shoulderBlend * SHOULDER_FALLOFF;
            
            wy += roadElevation + shoulderHeight;

            // --- Central Difference Normals (now accounting for road elevation) ---
            float hL = globalHeights[gRow * globalW + std::max(0, gCol - 1)];
            float hR = globalHeights[gRow * globalW + std::min(globalW - 1, gCol + 1)];
            float hN = globalHeights[std::min(globalH - 1, gRow + 1) * globalW + gCol];
            float hS = globalHeights[std::max(0, gRow - 1) * globalW + gCol];

            // Sample road influence at neighboring points for smooth normal transitions
            float roadInfluenceL = 0.0f, roadInfluenceR = 0.0f, roadInfluenceN = 0.0f, roadInfluenceS = 0.0f;
            if (roadMaskData && roadW > 0 && roadH > 0) {
                auto getRoadInfluence = [&](int gx, int gz) -> float {
                    int rx = (int)((float)gx / (globalW - 1) * (roadW - 1));
                    int rz = (int)((float)gz / (globalH - 1) * (roadH - 1));
                    rx = std::min(std::max(rx, 0), roadW - 1);
                    rz = std::min(std::max(rz, 0), roadH - 1);
                    float val = ((*roadMaskData)[(rz * roadW + rx) * 4 + 0] / 255.0f);
                    return (val < 0.8f) ? 0.0f : (val - 0.8f) / 0.2f;
                };
                roadInfluenceL = getRoadInfluence(std::max(0, gCol - 1), gRow);
                roadInfluenceR = getRoadInfluence(std::min(globalW - 1, gCol + 1), gRow);
                roadInfluenceN = getRoadInfluence(gCol, std::min(globalH - 1, gRow + 1));
                roadInfluenceS = getRoadInfluence(gCol, std::max(0, gRow - 1));
            }

            // Apply road elevation to neighbor heights
            auto applyRoadElevation = [&](float roadInf) -> float {
                float crown = 1.0f - (roadInf * roadInf);
                float elev = roadInf * ROAD_HEIGHT_BOOST * (1.0f - crown * ROAD_WIDTH_FALLOFF * 0.3f);
                float shouldBlend = 1.0f - std::pow(roadInf, 2.5f);
                float shoulder = MAX_SHOULDER_HEIGHT * (1.0f - shouldBlend) * shouldBlend * SHOULDER_FALLOFF;
                return elev + shoulder;
            };
            hL += applyRoadElevation(roadInfluenceL);
            hR += applyRoadElevation(roadInfluenceR);
            hN += applyRoadElevation(roadInfluenceN);
            hS += applyRoadElevation(roadInfluenceS);

            glm::vec3 normal = glm::normalize(glm::vec3(
                (hL - hR) / stepX,
                1.0f,
                (hN - hS) / stepZ
            ));

            vertices.push_back({ glm::vec3(wx, wy, wz), normal, glm::vec2(ux, uz) });
        }
    }
    for (int r = 0; r < size - 1; ++r) {
        for (int c = 0; c < size - 1; ++c) {
            unsigned int tl = r * size + c, tr = tl + 1, bl = tl + size, br = bl + 1;
            indices.push_back(tl); indices.push_back(bl); indices.push_back(tr);
            indices.push_back(tr); indices.push_back(bl); indices.push_back(br);
        }
    }
    indexCount = (int)indices.size();
    glGenVertexArrays(1, &VAO); glGenBuffers(1, &VBO); glGenBuffers(1, &EBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO); glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vertex), vertices.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO); glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)sizeof(glm::vec3));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)(2 * sizeof(glm::vec3)));
    glBindVertexArray(0);
}

void TerrainChunk::render() {
    if (VAO) { glBindVertexArray(VAO); glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, 0); glBindVertexArray(0); }
}
