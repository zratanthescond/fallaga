#pragma once
#include <vector>
#include <string>
#include <GL/glew.h>
#include <glm/glm.hpp>
#include "TerrainChunk.h"
#include "Shader.h"

class TerrainManager {
public:
    TerrainManager(const std::string& hmPath, const std::string& pmPath, float minX, float maxX, float minZ, float maxZ, float minH, float maxH);
    ~TerrainManager();
    void update(const glm::vec3& camPos);
    void render(const glm::mat4& proj, const glm::mat4& view, const glm::vec3& camPos, const glm::vec3& lightDir, const glm::vec3& lightColor);
    float getHeightAt(float x, float z) const;
    void exportToOBJ(const std::string& filename, int downsample = 4) const;
    glm::vec3 getNormalAt(float x, float z) const;
    float getRoadAt(float x, float z) const;
    GLuint getHeightmapTexture() const { return heightmapTexID; }

private:
    void loadHeightmap(const std::string& path);
    void setupTextures(const std::string& pmPath);
    std::vector<float> heights;
    std::vector<unsigned char> roadMaskData;
    int gridW=0, gridH=0;
    int roadW=0, roadH=0;
    float worldMinX, worldMaxX, worldMinZ, worldMaxZ, minHeight, maxHeight;
    std::vector<TerrainChunk*> chunks;
    GLuint terrainLayerArray=0, terrainNormalArray=0, terrainDispArray=0, terrainRoughArray=0, portMask=0, roadMask=0, heightmapTexID=0;
    bool hasRoadMask = false;
    Shader* terrainShader=nullptr;
    const int CHUNK_SIZE = 129;
};
