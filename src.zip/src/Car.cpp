#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <algorithm>
#include <cmath>
#include <glm/glm.hpp>
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>

#include "AudioSystem.h"
#include "Camera.h"
#include "Car.h"
#include "Character.h"
#include "ObjectModel.h"
#include "Shader.h"
#include "Terrain.h"

// ================================================================
// MESH RESOLVER
// ================================================================
// Shared resources across all Car instances to save memory and avoid redundant loading
static ObjModel* sharedCarModel = nullptr;
static Shader* sharedCarShader = nullptr;
static int carInstanceCount = 0;

void Car::resolveWheelMeshes() {
  if (!model)
    return;
  meshBody = meshFL = meshFR = meshBL = meshBR = -1;

  const int total = model->getMeshCount();
  std::cout << "[Car] " << total << " meshes:\n";
  for (int i = 0; i < total; i++)
    std::cout << "  [" << i << "] \"" << model->getMeshName(i) << "\"\n";

  std::vector<int> wheelCandidates;
  for (int i = 0; i < total; i++) {
    std::string lo = model->getMeshName(i);
    for (auto &c : lo)
      c = (char)std::tolower(c);

    if (lo.find("body") != std::string::npos ||
        lo.find("chassis") != std::string::npos ||
        lo.find("frame") != std::string::npos ||
        lo.find("car") != std::string::npos) {
      meshBody = i;
      continue;
    }
    if (lo.find("fl") != std::string::npos ||
        (lo.find("front") != std::string::npos &&
         lo.find("left") != std::string::npos)) {
      meshFL = i;
      continue;
    } else if (lo.find("fr") != std::string::npos ||
               (lo.find("front") != std::string::npos &&
                lo.find("right") != std::string::npos)) {
      meshFR = i;
      continue;
    } else if (lo.find("bl") != std::string::npos ||
               lo.find("rl") != std::string::npos ||
               (lo.find("rear") != std::string::npos &&
                lo.find("left") != std::string::npos)) {
      meshBL = i;
      continue;
    } else if (lo.find("br") != std::string::npos ||
               lo.find("rr") != std::string::npos ||
               lo.find("lr") != std::string::npos ||
               (lo.find("rear") != std::string::npos &&
                lo.find("right") != std::string::npos)) {
      meshBR = i;
      continue;
    }
    if (lo.find("wheel") != std::string::npos ||
        lo.find("weel") != std::string::npos ||
        lo.find("tyre") != std::string::npos ||
        lo.find("tire") != std::string::npos)
      wheelCandidates.push_back(i);
  }

  auto spatialAssign = [&](std::vector<int> &ids) {
    if (ids.size() < 4)
      return;
    float minZ = 1e9, maxZ = -1e9, minX = 1e9, maxX = -1e9;
    for (int x : ids) {
      glm::vec3 c = model->getMeshCenter(x);
      minZ = std::min(minZ, c.z);
      maxZ = std::max(maxZ, c.z);
      minX = std::min(minX, c.x);
      maxX = std::max(maxX, c.x);
    }
    float mz = (minZ + maxZ) * 0.5f, mx = (minX + maxX) * 0.5f;
    for (int x : ids) {
      glm::vec3 c = model->getMeshCenter(x);
      bool f = c.z > mz, l = c.x < mx;
      if (f && l && meshFL < 0)
        meshFL = x;
      else if (f && !l && meshFR < 0)
        meshFR = x;
      else if (!f && l && meshBL < 0)
        meshBL = x;
      else if (!f && !l && meshBR < 0)
        meshBR = x;
    }
  };

  if (meshFL < 0 && wheelCandidates.size() >= 4)
    spatialAssign(wheelCandidates);
  if (!(meshFL >= 0 && meshFR >= 0 && meshBL >= 0 && meshBR >= 0)) {
    if (total == 5) {
      meshBody = 0;
      meshFL = 1;
      meshFR = 2;
      meshBL = 3;
      meshBR = 4;
    } else if (total >= 5) {
      std::vector<int> all;
      for (int i = 0; i < total; i++)
        if (i != meshBody)
          all.push_back(i);
      spatialAssign(all);
    }
  }
  if (meshBody < 0 && total > 0)
    meshBody = 0;

  if (meshFL >= 0)
    wheelOffsetFL = model->getMeshCenter(meshFL);
  if (meshFR >= 0)
    wheelOffsetFR = model->getMeshCenter(meshFR);
  if (meshBL >= 0)
    wheelOffsetBL = model->getMeshCenter(meshBL);
  if (meshBR >= 0)
    wheelOffsetBR = model->getMeshCenter(meshBR);

  if (meshFL >= 0 && meshBL >= 0) {
    m_Wheelbase = std::abs(wheelOffsetFL.z - wheelOffsetBL.z) * SCALE_FACTOR;
    m_TrackWidth = (meshFR >= 0) ? std::abs(wheelOffsetFL.x - wheelOffsetFR.x) *
                                       SCALE_FACTOR
                                 : 1.4f;
  }
  if (m_Wheelbase < 0.5f)
    m_Wheelbase = 2.8f;
  if (m_TrackWidth < 0.3f)
    m_TrackWidth = 1.4f;

  int rs = (meshBL >= 0) ? meshBL : (meshFL >= 0 ? meshFL : -1);
  if (rs >= 0) {
    float r =
        std::abs(model->getMeshCenter(rs).y - model->getMeshMinBound(rs).y) *
        SCALE_FACTOR;
    for (int i = 0; i < 4; i++)
      wheels[i].radius = (r < 0.1f || r > 1.0f) ? 0.35f : r;
    std::cout << "[Car] Wheel Radius: " << wheels[0].radius << "m\n";
  }

  for (int i = 0; i < 4; i++) {
    wheels[i].isFront = (i < 2);
    wheels[i].isDriven = true;
  }
  wheels[0].localPos = wheelOffsetFL;
  wheels[1].localPos = wheelOffsetFR;
  wheels[2].localPos = wheelOffsetBL;
  wheels[3].localPos = wheelOffsetBR;

  int ax = (meshBL >= 0) ? meshBL : (meshFL >= 0 ? meshFL : -1);
  if (ax >= 0)
    m_VerticalOffset = -(model->getMeshCenter(ax).y * SCALE_FACTOR);
  carCenter =
      (wheelOffsetFL + wheelOffsetFR + wheelOffsetBL + wheelOffsetBR) * 0.25f;

  std::cout << "[Car] Body=" << meshBody << " FL=" << meshFL << " FR=" << meshFR
            << " BL=" << meshBL << " BR=" << meshBR
            << "\n[Car] WB=" << m_Wheelbase << "m TW=" << m_TrackWidth
            << "m VO=" << m_VerticalOffset << "m\n";
}

// ================================================================
// SECTION 4 — PACEJKA TIRE MODEL
// ================================================================
float Car::tireForce(float slip, float load) {
  // Sim-Cade Tire Parameters (High grip, forgiving slide)
  const float B = 8.0f, C = 1.2f, E = 1.0f;
  return load * std::sin(C * std::atan(B * slip -
                                       E * (B * slip - std::atan(B * slip))));
}

float Car::getSpeed() const {
  return std::sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
}

// SECTION 8 — Surface grip from terrain zone
static float surfaceGrip(Terrain *t, float x, float z) {
  switch (t->getZoneAt(x, z)) {
  case Terrain::Zone::SEA:
    return 0.10f;
  case Terrain::Zone::BEACH:
    return 0.55f;
  case Terrain::Zone::PLAIN:
    return 0.85f;
  case Terrain::Zone::WADI:
    return 0.70f;
  case Terrain::Zone::PORT:
  case Terrain::Zone::MEDINA:
  case Terrain::Zone::VILLE_NOUVELLE:
  case Terrain::Zone::KASBAH:
    return 1.10f;
  default:
    return 0.90f;
  }
}

// Wheel contact patch XZ (YAW ONLY — pitch/roll are outputs, not inputs)
glm::vec3 Car::getWheelWorld(const glm::vec3 &lo) const {
  glm::vec3 rel = (lo - carCenter) * SCALE_FACTOR;

  glm::mat4 rot(1.0f);
  rot = glm::rotate(rot, -yaw + glm::pi<float>(), glm::vec3(0, 1, 0));
  rot = glm::rotate(rot, pitchAngle, glm::vec3(1, 0, 0));
  rot = glm::rotate(rot, rollAngle, glm::vec3(0, 0, 1));

  glm::vec4 rotatedRel = rot * glm::vec4(rel, 1.0f);

  return glm::vec3(position.x + rotatedRel.x, position.y + rotatedRel.y,
                   position.z + rotatedRel.z);
}

// Yaw-only wheel XZ position — used for terrain height queries.
// Deliberately excludes pitch/roll to break the circular dependency where
// pitch/roll angles would shift the contact patch, changing the sampled
// height, which would then change the angles again.
glm::vec3 Car::getWheelContactPatch(const glm::vec3 &lo) const {
  glm::vec3 rel = (lo - carCenter) * SCALE_FACTOR;
  float angle = -yaw + glm::pi<float>();
  float cy = std::cos(angle), sy = std::sin(angle);
  return glm::vec3(position.x + rel.x * cy - rel.z * sy, position.y,
                   position.z + rel.x * sy + rel.z * cy);
}

// ================================================================
// CONSTRUCTOR / DESTRUCTOR
// ================================================================
Car::Car(State initialState) : isGrounded(true), state(initialState) {
  position = Vec3(-435.0f, 50.0f, 1325.0f);
  velocity = Vec3(0, 0, 0);
  angularVel = glm::vec3(0);
  yaw = steerAngle = driftAngle = bodyShake = pitchAngle = rollAngle = 0.0f;
  m_VerticalOffset = 0.0f;
  m_Driver = nullptr;

  engine.rpm = 800.0f;
  engine.gear = 2; // Start in 1st (gear[1]=N, gear[2]=1st)

  // AI initialization
  aiTargetYaw = yaw;
  aiThinkTimer = 0.0f;
  aiLostTimer = 0.0f;
  needsInitialSnap = true;

  for (int i = 0; i < 4; i++) {
    wheels[i].prevLength = wheels[i].suspensionRest;
    wheels[i].currentLength = wheels[i].suspensionRest;
    wheels[i].spinAngle = 0.0f;
    wheels[i].angularVelocity = 0.0f;
  }

  // Use shared resources if available
  if (!sharedCarModel) {
    sharedCarModel = new ObjModel("assets/cars/R40CV.fbx");
    sharedCarShader = new Shader("src/shaders/model.vert", "src/shaders/model.frag");
  }
  
  model = sharedCarModel;
  carShader = sharedCarShader;
  carInstanceCount++;

  resolveWheelMeshes();
  std::cout << "[Car] Instance " << carInstanceCount << " Ready.\n";
}
Car::~Car() {
  carInstanceCount--;
  if (carInstanceCount <= 0) {
    delete sharedCarModel;
    delete sharedCarShader;
    sharedCarModel = nullptr;
    sharedCarShader = nullptr;
  }
}

// ================================================================
// IDLE PHYSICS
// ================================================================
void Car::updateIdlePhysics(float dt, Terrain *terrain) {
  // ── Sample terrain under each wheel using YAW-ONLY positions ────────────
  // Using getWheelContactPatch() (not getWheelWorld()) deliberately avoids
  // the circular dependency: pitch/roll would shift wheel Y → change sampled
  // height → change pitch/roll → diverge.
  float h[4];
  for (int i = 0; i < 4; i++) {
    glm::vec3 cp = getWheelContactPatch(wheels[i].localPos);
    h[i] = terrain->getHeight(cp.x, cp.z);
  }

  // ── Vertical position: snap car center so wheels rest on ground ─────────
  // On a uniformly sloped surface the average wheel contact height equals
  // the car centre projected down, so adding the wheel radius is correct.
  float avgH = (h[0] + h[1] + h[2] + h[3]) * 0.25f;
  float targetY = avgH + wheels[0].radius;

  // Fast exponential convergence — feels like stiff springs at rest
  float snapK = 12.0f;
  position.y += (targetY - position.y) * (1.0f - std::exp(-snapK * dt));
  velocity.y = 0.0f;

  // ── Pitch: front/rear height difference ─────────────────────────────────
  float frontH = (h[0] + h[1]) * 0.5f;
  float rearH = (h[2] + h[3]) * 0.5f;
  float tgtPitch = std::atan2(frontH - rearH, m_Wheelbase);
  pitchAngle += (tgtPitch - pitchAngle) * (1.0f - std::exp(-10.0f * dt));

  // ── Roll: left/right height difference ──────────────────────────────────
  float leftH = (h[0] + h[2]) * 0.5f;
  float rightH = (h[1] + h[3]) * 0.5f;
  float tgtRoll = std::atan2(rightH - leftH, m_TrackWidth);
  rollAngle += (tgtRoll - rollAngle) * (1.0f - std::exp(-10.0f * dt));

  // ── Dampen residual horizontal motion ────────────────────────────────────
  velocity.x *= std::pow(0.95f, 60.0f * dt);
  velocity.z *= std::pow(0.95f, 60.0f * dt);
  angularVel = glm::vec3(0.0f);
  isGrounded = true;

  // Idle sound - DISABLED TO DEBUG CRASH
  // AudioSystem::getInstance().updateEngine(800.0f, 0.0f, 7000.0f);
}

void Car::updateRoamingAI(float dt, Terrain *terrain, float totalTime) {
  constexpr float PI = 3.14159265f;
  constexpr int RING_SAMPLES = 16;
  constexpr float RING_RADIUS = 15.0f; // sample ring distance

  // 1. Sample road values in a ring around the car
  float ringVal[RING_SAMPLES];
  float ringAngle[RING_SAMPLES];
  for (int i = 0; i < RING_SAMPLES; i++) {
    float a = (float)i * (2.0f * PI / RING_SAMPLES);
    ringAngle[i] = a;
    float sx = position.x + std::sin(a) * RING_RADIUS;
    float sz = position.z - std::cos(a) * RING_RADIUS;
    ringVal[i] = terrain->getRoadAt(sx, sz);
  }

  // 2. Find the best sample direction
  int bestIdx = 0;
  for (int i = 1; i < RING_SAMPLES; i++) {
    if (ringVal[i] > ringVal[bestIdx])
      bestIdx = i;
  }

  float bestVal = ringVal[bestIdx];

  if (bestVal < 0.2f) {
    // No road found anywhere nearby — become parked
    aiLostTimer += dt;
    if (aiLostTimer > 10.0f) {
      state = State::PARKED;
      engine.throttle = 0.0f;
      return;
    }
    // Coast and sweep
    engine.throttle = 0.0f;
    steerAngle = std::sin(totalTime * 0.5f) * 0.3f;
  } else {
    aiLostTimer = 0.0f;

    // 3. Compute desired heading: steer toward the best road sample,
    //    but prefer the direction closest to current heading to avoid U-turns
    float desiredYaw = ringAngle[bestIdx];

    // Also check the opposite direction on the ring for a "road corridor"
    int oppIdx = (bestIdx + RING_SAMPLES / 2) % RING_SAMPLES;
    if (ringVal[oppIdx] > 0.3f) {
      float diffBest = desiredYaw - yaw;
      while (diffBest > PI)
        diffBest -= 2.0f * PI;
      while (diffBest < -PI)
        diffBest += 2.0f * PI;

      float diffOpp = ringAngle[oppIdx] - yaw;
      while (diffOpp > PI)
        diffOpp -= 2.0f * PI;
      while (diffOpp < -PI)
        diffOpp += 2.0f * PI;

      if (std::abs(diffOpp) < std::abs(diffBest)) {
        desiredYaw = ringAngle[oppIdx];
      }
    }

    // 4. Steer toward the desired heading
    float yawDiff = desiredYaw - yaw;
    while (yawDiff > PI)
      yawDiff -= 2.0f * PI;
    while (yawDiff < -PI)
      yawDiff += 2.0f * PI;

    // Set steering angle for physics
    float targetSteer = glm::clamp(yawDiff * 1.5f, -MAX_STEER_ANGLE, MAX_STEER_ANGLE);
    steerAngle += (targetSteer - steerAngle) * (1.0f - std::exp(-5.0f * dt));

    // Throttle control
    float roadQuality = terrain->getRoadAt(position.x, position.z);
    float targetSpeed = 12.0f; // AI cruising speed
    if (roadQuality < 0.4f) targetSpeed = 5.0f;
    
    if (getSpeed() < targetSpeed) {
        engine.throttle = 0.5f;
    } else {
        engine.throttle = 0.0f;
    }
  }
}

void Car::update(float dt, Terrain *terrain, float totalTime, Camera *camera) {
  if (!terrain) return;
  switch (state) {
  case State::DRIVEN:
    updateActivePhysics(dt, terrain);
    break;
  case State::ROAMING:
    updateRoamingAI(dt, terrain, totalTime);
    updateActivePhysics(dt, terrain); 
    break;
  case State::PARKED: 
    updateIdlePhysics(dt, terrain);
    break;
  }
}

// ================================================================
// ACTIVE PHYSICS (MODULAR SUBSYSTEMS)
// ================================================================

glm::vec3 Car::getForwardVector() const {
  return glm::vec3(std::sin(yaw), 0, -std::cos(yaw));
}
glm::vec3 Car::getRightVector() const {
  return glm::vec3(std::cos(yaw), 0, std::sin(yaw));
}

void Car::processInput(float dt, bool &gas, bool &braking, bool &handbrake) {
  gas = m_Driver->keys['w'] || m_Driver->keys['W'] || m_Driver->keys['z'] ||
        m_Driver->keys['Z'];
  braking = m_Driver->keys['s'] || m_Driver->keys['S'];
  bool left = m_Driver->keys['a'] || m_Driver->keys['A'] ||
              m_Driver->keys['q'] || m_Driver->keys['Q'];
  bool right = m_Driver->keys['d'] || m_Driver->keys['D'];
  handbrake = glfwGetKey(glfwGetCurrentContext(), GLFW_KEY_SPACE) == GLFW_PRESS;

  // Steering Input (1 for Left, -1 for Right to match visual turn phase)
  float targetSteer = (left ? 1.0f : 0.0f) - (right ? 1.0f : 0.0f);
  float speed = getSpeed();
  float maxSteer =
      glm::clamp(MAX_STEER_ANGLE - (speed * 0.008f), 0.25f, MAX_STEER_ANGLE);
  float steerSpeed =
      glm::clamp(10.0f - (speed * 0.1f), 3.0f, 10.0f); // Reduced sensitivity

  steerAngle += (targetSteer * maxSteer - steerAngle) *
                (1.0f - std::exp(-steerSpeed * dt));

  // Horn Input (F Key)
  if (glfwGetKey(glfwGetCurrentContext(), GLFW_KEY_F) == GLFW_PRESS) {
    AudioSystem::getInstance().playHorn();
  } else {
    AudioSystem::getInstance().stopHorn();
  }
}

void Car::updateTransmission(float dt, bool gas, bool braking) {
  float currentSpeedKmh = getSpeed() * 3.6f;

  if (currentSpeedKmh < 2.0f) {
    if (gas && engine.gear <= 1)
      engine.gear = 2; // Shift to 1st
    if (braking && engine.gear != 0)
      engine.gear = 0; // Shift to Reverse
  }

  if (engine.gear >= 2) {
    if (engine.rpm > 6000.0f && engine.gear < 7) {
      engine.gear++;
      engine.rpm -= 1500.0f;
    } else if (engine.rpm < 2500.0f && engine.gear > 2 &&
               currentSpeedKmh > 10.0f) {
      engine.gear--;
      engine.rpm += 1000.0f;
    }
  }

  if (engine.gear == 0) { // Reverse
    engine.throttle = braking ? 1.0f : 0.0f;
  } else { // Forward
    engine.throttle = gas ? 1.0f : 0.0f;
  }

  float avgWheelAV =
      (wheels[2].angularVelocity + wheels[3].angularVelocity) * 0.5f;
  float targetRPM = std::abs(avgWheelAV * engine.gearRatios[engine.gear]) *
                    engine.finalDrive * 9.5493f;
  engine.rpm += (std::max(engine.minRPM, targetRPM) - engine.rpm) *
                (1.0f - std::exp(-5.0f * dt));
  engine.rpm = glm::clamp(engine.rpm, engine.minRPM, engine.maxRPM);
}

void Car::updateSuspension(float sdt, Terrain *terrain, glm::vec3 &totalForce) {
  for (int i = 0; i < 4; i++) {
    glm::vec3 wp = getWheelWorld(wheels[i].localPos);
    float groundH = terrain->getHeight(wp.x, wp.z);

    float distToGround = wp.y - groundH;
    wheels[i].currentLength = glm::clamp(distToGround - wheels[i].radius, 0.0f,
                                         wheels[i].suspensionRest);
    wheels[i].compression = wheels[i].suspensionRest - wheels[i].currentLength;

    float compVel = (wheels[i].prevLength - wheels[i].currentLength) / sdt;
    wheels[i].prevLength = wheels[i].currentLength;

    float damping = (compVel > 0) ? SPRING_DAMPING : SPRING_DAMPING * 2.5f;
    float springF = wheels[i].compression * SPRING_K + compVel * damping;

    // Cap the force to prevent physics explosions
    float maxSpringF = MASS * 15.0f;
    if (springF > maxSpringF)
      springF = maxSpringF;
    if (springF < 0)
      springF = 0;

    wheels[i].load = springF;
    if (wheels[i].compression > 0.02f)
      isGrounded = true;

    totalForce.y += springF;
  }
}

void Car::calculateTireForces(float sdt, Terrain *terrain,
                              glm::vec3 &totalForce, glm::vec3 &totalTorque) {
  float engineTorque = engine.torqueCurve(engine.rpm) * engine.throttle;
  float driveTorque = engineTorque * engine.gearRatios[engine.gear] *
                      engine.finalDrive * engine.clutch;
  float torqueSplit[4] = {driveTorque * 0.2f, driveTorque * 0.2f,
                          driveTorque * 0.3f, driveTorque * 0.3f};
  float engineBraking = (engine.throttle < 0.1f) ? 1500.0f : 0.0f;
  float brakeForce = engineBraking;
  if (m_Driver) {
    if (engine.gear > 0 && (m_Driver->keys['s'] || m_Driver->keys['S'])) {
      brakeForce = 8000.0f;
    } else if (engine.gear == 0 &&
               (m_Driver->keys['w'] || m_Driver->keys['W'] ||
                m_Driver->keys['z'] || m_Driver->keys['Z'])) {
      brakeForce = 8000.0f;
    }
  }

  for (int i = 0; i < 4; i++) {
    glm::vec3 wp = getWheelWorld(wheels[i].localPos);
    glm::vec3 rel = wp - glm::vec3(position.x, position.y, position.z);
    glm::vec3 wVel = glm::vec3(velocity.x, velocity.y, velocity.z) +
                     glm::cross(angularVel, rel);

    float wYaw = yaw + (wheels[i].isFront ? steerAngle : 0);
    glm::vec3 tireFwd(std::sin(wYaw), 0, -std::cos(wYaw));
    glm::vec3 tireRgt(std::cos(wYaw), 0, std::sin(wYaw));

    float vLong = glm::dot(wVel, tireFwd);
    float vLat = glm::dot(wVel, tireRgt);

    float vRef = std::max(std::abs(vLong), 2.0f);
    float kappa = (wheels[i].angularVelocity * wheels[i].radius - vLong) / vRef;
    float alpha = std::atan2(vLat, std::abs(vLong) + 0.5f);

    float roadFactor = terrain->getRoadAt(wp.x, wp.z);
    float grip = surfaceGrip(terrain, wp.x, wp.z) * (1.0f + roadFactor * 0.45f);
    float fx = tireForce(kappa, wheels[i].load * grip);
    float fy = -tireForce(alpha, wheels[i].load * grip);

    // GTA Arcade Grip Boost - snappy cornering, minimal slide
    fy *= (wheels[i].isFront ? 5.5f : 7.0f) * (1.0f + roadFactor * 0.6f);
    fx *= 4.0f;

    float maxF = wheels[i].load * grip * 3.0f;
    float totalF = std::sqrt(fx * fx + fy * fy);
    if (totalF > maxF) {
      float ratio = maxF / totalF;
      fx *= std::pow(ratio, 0.5f);
      fy *= ratio;
    }

    // Removed buggy explicitly reversed force. Pacejka handles negative slip
    // correctly.
    if (std::abs(vLat) < 0.8f && std::abs(vLong) < 1.5f) {
      fy += -vLat * 25000.0f * sdt;
      fx += -vLong * 25000.0f * sdt;
    }

    wheels[i].fx = fx;
    wheels[i].fy = fy;
    wheels[i].kappa = kappa;
    wheels[i].alpha = alpha;

    glm::vec3 wForce = tireFwd * fx + tireRgt * fy;
    totalForce += wForce;
    totalTorque += glm::cross(rel, wForce);

    float rollingResistance = 600.0f;
    float wheelTorque = torqueSplit[i] - fx * wheels[i].radius -
                        (brakeForce + rollingResistance) * wheels[i].radius *
                            glm::sign(wheels[i].angularVelocity);

    wheels[i].angularVelocity += (wheelTorque / 45.0f) * sdt;
    float slipLimit = getSpeed() / wheels[i].radius + 5.0f;
    wheels[i].angularVelocity =
        glm::clamp(wheels[i].angularVelocity, -slipLimit, slipLimit);
    wheels[i].spinAngle += wheels[i].angularVelocity * sdt;
  }
}

void Car::applyStabilityControl(float sdt, Terrain *terrain,
                                glm::vec3 &totalTorque) {
  float speed = getSpeed();

  if (!isGrounded) {
    bool gas = engine.throttle > 0.5f;
    bool braking = m_Driver ? (m_Driver->keys['s'] || m_Driver->keys['S']) : false;
    bool left = m_Driver ? (m_Driver->keys['a'] || m_Driver->keys['A'] ||
                            m_Driver->keys['q'] || m_Driver->keys['Q']) : false;
    bool right = m_Driver ? (m_Driver->keys['d'] || m_Driver->keys['D']) : false;

    float pitchInput = (braking ? 1.0f : 0.0f) - (gas ? 1.0f : 0.0f);
    float rollInput = (right ? 1.0f : 0.0f) - (left ? 1.0f : 0.0f);

    totalTorque.x += pitchInput * 15000.0f;
    totalTorque.z += rollInput * 15000.0f;
    totalTorque.x += -pitchAngle * 5000.0f;
    totalTorque.z += -rollAngle * 5000.0f;
  } else {
    bool left = m_Driver ? (m_Driver->keys['a'] || m_Driver->keys['A'] ||
                            m_Driver->keys['q'] || m_Driver->keys['Q']) : false;
    bool right = m_Driver ? (m_Driver->keys['d'] || m_Driver->keys['D']) : false;
    float targetSteer = (left ? 1.0f : 0.0f) - (right ? 1.0f : 0.0f);

    float roadFactor = terrain->getRoadAt(position.x, position.z);
    if (speed > 5.0f && std::abs(targetSteer) < 0.1f) {
      glm::vec2 vel2D(velocity.x, velocity.z);
      if (glm::length(vel2D) > 0.1f) {
        vel2D = glm::normalize(vel2D);
        glm::vec3 fwd = getForwardVector();
        glm::vec2 carDir2D(fwd.x, fwd.z);

        if (glm::dot(carDir2D, vel2D) > 0.2f) {
          float cross2D = carDir2D.x * vel2D.y - carDir2D.y * vel2D.x;
          totalTorque.y += cross2D * 12000.0f * (1.0f + roadFactor * 2.0f);
        }
      }
    }

    if (std::abs(rollAngle) > 0.05f) {
      totalTorque.z += -rollAngle * 60000.0f;
      angularVel.z *= 0.75f;
    }

    float desiredYawRate =
        -steerAngle * speed * 0.35f; // Reduced yaw rate target
    float escTorque = (desiredYawRate - angularVel.y) * 20000.0f *
                      (1.0f + roadFactor * 1.5f); // Reduced ESC intervention
    float steerAssist =
        -targetSteer * speed * 3000.0f; // Reduced artificial steering torque

    totalTorque.y += escTorque + steerAssist;
  }
}

void Car::applyAerodynamics(float dt, glm::vec3 &totalForce) {
  float speedSq = velocity.x * velocity.x + velocity.z * velocity.z;
  if (speedSq > 0.1f) {
    glm::vec3 dragDir = glm::normalize(glm::vec3(-velocity.x, 0, -velocity.z));
    float dragForce = 0.45f * speedSq;
    float downForce = 2.0f * speedSq; // High-speed stability boost
    totalForce += dragDir * dragForce;
    totalForce.y -= downForce;
  }
}

void Car::updateActivePhysics(float dt, Terrain *terrain) {
  if (!terrain)
    return;

  bool gas = false, braking = false, handbrake = false;
  if (state == State::DRIVEN && m_Driver) {
    processInput(dt, gas, braking, handbrake);
    updateTransmission(dt, gas, braking);
  } else {
    // For AI or other modes, transmission is simplified or updated elsewhere
    // We can still call updateTransmission with member variables if needed
    updateTransmission(dt, engine.throttle > 0.1f, false);
  }

  const int SUB_STEPS = 8;
  float sdt = dt / (float)SUB_STEPS;

  isGrounded = false;

  for (int step = 0; step < SUB_STEPS; step++) {
    glm::vec3 totalForce(0, MASS * GRAVITY, 0);
    glm::vec3 totalTorque(0);

    updateSuspension(sdt, terrain, totalForce);
    calculateTireForces(sdt, terrain, totalForce, totalTorque);
    applyStabilityControl(sdt, terrain, totalTorque);
    applyAerodynamics(sdt, totalForce);

    angularVel.x += (totalTorque.x / INERTIA_PITCH) * sdt;
    angularVel.y += (totalTorque.y / INERTIA_YAW) * sdt;
    angularVel.z += (totalTorque.z / INERTIA_ROLL) * sdt;
    angularVel *= BODY_DAMPING;

    yaw += angularVel.y * sdt;

    velocity.x += (totalForce.x / MASS) * sdt;
    velocity.y += (totalForce.y / MASS) * sdt;
    velocity.z += (totalForce.z / MASS) * sdt;

    // Dampen vertical velocity to stop bouncing
    velocity.y *= 0.95f;

    position.x += velocity.x * sdt;
    position.y += velocity.y * sdt;
    position.z += velocity.z * sdt;
  }

  // Minor velocity dampening
  velocity.x *= std::pow(0.9995f, 60.0f * dt);
  velocity.z *= std::pow(0.9995f, 60.0f * dt);

  // Automatic Handbrake / Stopping Logic
  float currentSpeed = getSpeed();
  if (std::abs(engine.throttle) < 0.1f && currentSpeed < 0.4f) {
    velocity = velocity * 0.8f;
    angularVel *= 0.8f;
    if (currentSpeed < 0.05f)
      velocity = Vec3(0, 0, 0);
  }

  // ── Hard terrain floor — prevents sinking through mesh ──────────────────
  // The spring sub-steps can accumulate numerical error between frames;
  // this clamps the car above the ground surface unconditionally.
  {
    float groundH = terrain->getHeight(position.x, position.z);
    float floorY = groundH + wheels[0].radius * 0.85f;
    if (position.y < floorY) {
      position.y = floorY;
      if (velocity.y < 0.0f)
        velocity.y *= -0.05f; // tiny rebound, no bounce
    }
  }

  // Visuals and Audio Update
  if (state == State::DRIVEN) {
    AudioSystem::getInstance().updateEngine(engine.rpm, engine.throttle,
                                            engine.maxRPM);
  }

  bodyShake = 0.0f;
  if (engine.rpm >= engine.maxRPM - 300.0f) {
    bodyShake = ((rand() % 100) / 100.0f - 0.5f) * 0.018f;
  }

  float fwdAccel = 0.0f;
  float latAccel = 0.0f;
  if (dt > 1e-6f) {
    fwdAccel = glm::dot(glm::vec3(velocity.x, 0, velocity.z) -
                            glm::vec3(prevVel.x, 0, prevVel.z),
                        getForwardVector()) /
               dt;
    latAccel = glm::dot(glm::vec3(velocity.x, 0, velocity.z) - prevVel,
                        getRightVector()) /
               dt;
  }
  prevVel = glm::vec3(velocity.x, velocity.y, velocity.z);

  // ── Terrain-aligned pitch & roll ─────────────────────────────────────────
  // Sample actual ground height at each wheel's XZ contact patch (yaw-only,
  // no pitch/roll feedback so the calculation is stable on any slope).
  // Then derive pitch/roll geometrically, exactly as the idle path does,
  // and layer weight-transfer on top for driving dynamics.
  {
    float h[4];
    for (int i = 0; i < 4; i++) {
      glm::vec3 cp = getWheelContactPatch(wheels[i].localPos);
      h[i] = terrain->getHeight(cp.x, cp.z);
    }

    float frontH = (h[0] + h[1]) * 0.5f;
    float rearH = (h[2] + h[3]) * 0.5f;
    float leftH = (h[0] + h[2]) * 0.5f;
    float rightH = (h[1] + h[3]) * 0.5f;

    // Geometric slope angles from terrain geometry
    float terrainPitch = std::atan2(frontH - rearH, m_Wheelbase);
    float terrainRoll = std::atan2(rightH - leftH, m_TrackWidth);

    // Dynamic weight-transfer overlay (acceleration squat / cornering lean)
    float wtPitch = fwdAccel * -0.0015f;
    float wtRoll = latAccel * 0.002f;

    float targetPitch = terrainPitch + wtPitch;
    float targetRoll = terrainRoll + wtRoll;

    // Grounded cars snap quickly to terrain; airborne drift back slowly
    float blendK = isGrounded ? 10.0f : 2.5f;
    float blendFactor = (dt > 1e-6f) ? (1.0f - std::exp(-blendK * dt)) : 0.0f;
    pitchAngle += (targetPitch - pitchAngle) * blendFactor;
    rollAngle += (targetRoll - rollAngle) * blendFactor;
  }

  pitchAngle = glm::clamp(pitchAngle, -0.20f, 0.20f);
  rollAngle = glm::clamp(rollAngle, -0.25f, 0.25f);

  driftAngle +=
      (-(glm::dot(glm::vec3(velocity.x, 0, velocity.z), getRightVector())) *
           0.25f -
       driftAngle) *
      (1.0f - std::exp(-6.0f * dt));

  // Telemetry
  if (teleLog++ % 120 == 0) {
    const char *gearNames[] = {"R", "N", "1", "2", "3", "4", "5", "6"};
    std::cout << "[AAA Physics] " << gearNames[engine.gear] << " | "
              << (int)engine.rpm << " RPM | " << (int)(getSpeed() * 3.6f)
              << " km/h\n";
  }

  if (m_Driver) {
    Vec3 seat = position;
    seat.y += 0.5f;
    m_Driver->setPosition(seat);
    m_Driver->setRotation(yaw, glm::vec3(0, 1, 0));
  }
}

// ================================================================
// MOUNT / DISMOUNT
// ================================================================
void Car::mountCharacter(Character *c) {
  if (!c || m_Driver)
    return;
  m_Driver = c;
  state = State::DRIVEN;
  c->setMountedCar(this);
  angularVel = glm::vec3(0);
  for (int i = 0; i < 4; i++)
    wheels[i].prevLength = 0;

  AudioSystem::getInstance().playIgnition();
  std::cout << "[Car] Mounted.\n";
}
void Car::dismountCharacter(Character *c) {
  if (m_Driver != c)
    return;
  m_Driver = nullptr;
  state = State::PARKED;
  c->setMountedCar(nullptr);
  engine.throttle = 0;
  AudioSystem::getInstance().playStop();
  std::cout << "[Car] Dismounted.\n";
}

// ================================================================
// RENDER
// ================================================================
void Car::render(const glm::mat4 &projection, const glm::mat4 &view,
                 Terrain *terrain) {
  if (!model || !carShader)
    return;

  carShader->use();
  carShader->setMat4("projection", projection);
  carShader->setMat4("view", view);
  carShader->setBool("isInstanced", false);

  glm::mat4 base(1.0f);
  base = glm::translate(
      base, glm::vec3(position.x, position.y + m_VerticalOffset + bodyShake,
                      position.z));
  base = glm::rotate(base, -yaw + driftAngle * 0.1f + glm::pi<float>(),
                     glm::vec3(0, 1, 0));

  // Apply pitch and roll
  base = glm::rotate(base, pitchAngle, glm::vec3(1, 0, 0));
  base = glm::rotate(base, rollAngle, glm::vec3(0, 0, 1));

  base = glm::scale(base, glm::vec3(SCALE_FACTOR));
  base = glm::translate(base, glm::vec3(-carCenter.x, 0, -carCenter.z));

  if (meshBody >= 0) {
    carShader->setMat4("model", base);
    model->renderMesh(meshBody, *carShader);
  }

  auto renderWheel = [&](int idx, int wi, bool front, const glm::vec3 &ctr) {
    if (idx < 0)
      return;

    // Suspension offset
    float suspY = -wheels[wi].compression / SCALE_FACTOR;

    glm::mat4 wm = base;
    wm = glm::translate(wm, ctr + glm::vec3(0, suspY, 0));
    if (front)
      wm = glm::rotate(wm, steerAngle, glm::vec3(0, 1, 0));
    wm = glm::rotate(wm, wheels[wi].spinAngle, glm::vec3(1, 0, 0));
    wm = glm::translate(wm, -ctr);

    carShader->setMat4("model", wm);
    model->renderMesh(idx, *carShader);
  };

  renderWheel(meshFL, 0, true, wheelOffsetFL);
  renderWheel(meshFR, 1, true, wheelOffsetFR);
  renderWheel(meshBL, 2, false, wheelOffsetBL);
  renderWheel(meshBR, 3, false, wheelOffsetBR);

  for (int i = 0; i < model->getMeshCount(); i++)
    if (i != meshBody && i != meshFL && i != meshFR && i != meshBL &&
        i != meshBR) {
      carShader->setMat4("model", base);
      model->renderMesh(i, *carShader);
    }
}