#include <GL/glew.h>
#include <GLFW/glfw3.h>
#ifdef HAS_GLUT
#include <GL/glut.h>
#endif
#include "Camera.h"
#include "Car.h"
#include "Character.h"
#include "ObjectModel.h"
#include "Terrain.h"
#include <cmath>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>

// ================================================================
// CONSTRUCTOR / DESTRUCTOR
// ================================================================

Camera::Camera(Character *target)
    : target(target), distance(CAMERA_DEFAULT_DISTANCE),
      angleAroundTarget(0.0f), pitch(15.0f), terrainModel(nullptr),
      freeCam(false), lastTargetYaw(0.0f), autoAlignTimer(0.0f) {
  Vec3 startPos = target->getPosition();
  goalPosition = startPos;
  smoothedPosition = startPos;
  smoothedTarget = startPos;
  smoothedTarget.y += CAMERA_LOOK_HEIGHT;
  
  if (target) {
    lastTargetYaw = target->getYaw() * 180.0f / 3.14159265f;
  }
}

Camera::~Camera() {
  // Do NOT delete terrainModel here, it's owned by Terrain class
}

void Camera::setTerrain(ObjModel *terrain) { terrainModel = terrain; }

// ================================================================
// FREE CAMERA (Architect Mode)
// ================================================================

void Camera::setFreeCam(bool free) {
  if (free && !freeCam) {
    freePos = smoothedPosition;
    freeYaw = angleAroundTarget + 90.0f;
    freePitch = -pitch;
  }
  freeCam = free;
}

void Camera::moveFree(float dx, float dz, float dy, float dt) {
  if (!freeCam)
    return;
  float speed = 250.0f * dt;

  float radYaw = freeYaw * 3.14159f / 180.0f;
  float radPitch = freePitch * 3.14159f / 180.0f;

  glm::vec3 front;
  front.x = cos(radYaw) * cos(radPitch);
  front.y = sin(radPitch);
  front.z = sin(radYaw) * cos(radPitch);
  glm::vec3 cameraFront = glm::normalize(front);
  glm::vec3 cameraRight =
      glm::normalize(glm::cross(cameraFront, glm::vec3(0, 1, 0)));

  if (dz > 0) {
    freePos.x += cameraFront.x * speed;
    freePos.y += cameraFront.y * speed;
    freePos.z += cameraFront.z * speed;
  }
  if (dz < 0) {
    freePos.x -= cameraFront.x * speed;
    freePos.y -= cameraFront.y * speed;
    freePos.z -= cameraFront.z * speed;
  }
  if (dx > 0) {
    freePos.x += cameraRight.x * speed;
    freePos.y += cameraRight.y * speed;
    freePos.z += cameraRight.z * speed;
  }
  if (dx < 0) {
    freePos.x -= cameraRight.x * speed;
    freePos.y -= cameraRight.y * speed;
    freePos.z -= cameraRight.z * speed;
  }
  if (dy > 0)
    freePos.y += speed;
  if (dy < 0)
    freePos.y -= speed;

  forward = Vec3(cameraFront.x, cameraFront.y, cameraFront.z);
}

// ================================================================
// VIEW MATRIX
// ================================================================

glm::mat4 Camera::getViewMatrix() {
  if (freeCam) {
    glm::vec3 pos(freePos.x, freePos.y, freePos.z);
    float radYaw = freeYaw * 3.14159f / 180.0f;
    float radPitch = freePitch * 3.14159f / 180.0f;
    glm::vec3 front;
    front.x = cos(radYaw) * cos(radPitch);
    front.y = sin(radPitch);
    front.z = sin(radYaw) * cos(radPitch);
    return glm::lookAt(pos, pos + front, glm::vec3(0, 1, 0));
  }

  glm::vec3 cameraPos(smoothedPosition.x, smoothedPosition.y,
                      smoothedPosition.z);
  glm::vec3 cameraTarget(smoothedTarget.x, smoothedTarget.y, smoothedTarget.z);
  glm::vec3 worldUp(0.0f, 1.0f, 0.0f);
  return glm::lookAt(cameraPos, cameraTarget, worldUp);
}

// ================================================================
// UPDATE — The main per-frame call
// ================================================================

void Camera::update(float mouseDeltaX, float mouseDeltaY, float mouseScroll, float dt) {
  if (!target)
    return;

  // --- Free cam handles its own input ---
  if (freeCam) {
    freeYaw += mouseDeltaX * CAMERA_SENSITIVITY;
    freePitch -= mouseDeltaY * CAMERA_SENSITIVITY;
    if (freePitch > 89.0f)
      freePitch = 89.0f;
    if (freePitch < -89.0f)
      freePitch = -89.0f;
    return;
  }

  // ================================================================
  // 1. RELATIVE FOLLOW: Inherit target rotation delta (Vehicles only)
  // ================================================================
  float currentYawDeg = target->getYaw() * 180.0f / 3.14159265f;
  if (target->isDriving()) {
    float deltaYaw = currentYawDeg - lastTargetYaw;
    while (deltaYaw > 180.0f) deltaYaw -= 360.0f;
    while (deltaYaw < -180.0f) deltaYaw += 360.0f;
    
    // Add the car's rotation delta to the camera orbit so it stays behind/relative
    angleAroundTarget += deltaYaw;
  }
  lastTargetYaw = currentYawDeg;

  // ================================================================
  // 2. MOUSE INPUT: Update orbit angles and distance
  // ================================================================
  if (std::abs(mouseDeltaX) > 0.01f || std::abs(mouseDeltaY) > 0.01f) {
    angleAroundTarget += mouseDeltaX * CAMERA_SENSITIVITY;
    pitch -= mouseDeltaY * CAMERA_SENSITIVITY;
    autoAlignTimer = 1.5f; // Wait 1.5s after mouse input before auto-aligning
  } else if (autoAlignTimer > 0.0f) {
    autoAlignTimer -= dt;
  }

  if (pitch > CAMERA_PITCH_MAX)
    pitch = CAMERA_PITCH_MAX;
  if (pitch < CAMERA_PITCH_MIN)
    pitch = CAMERA_PITCH_MIN;

  // Zoom
  distance -= mouseScroll * CAMERA_ZOOM_SENSITIVITY;
  if (distance > CAMERA_MAX_DISTANCE)
    distance = CAMERA_MAX_DISTANCE;
  if (distance < CAMERA_MIN_DISTANCE)
    distance = CAMERA_MIN_DISTANCE;

  // ================================================================
  // 3. CALCULATE GOAL POSITION
  // ================================================================
  calculateGoalPosition();

  // ================================================================
  // 4. SMOOTH & CLAMP
  // ================================================================
  applySmoothingAndClamp(dt);

  // ================================================================
  // 5. AUTO-ALIGNMENT: Gradually center camera behind player
  // ================================================================
  if (target) {
    float targetYawDeg = 0.0f;
    float speed = 0.0f;
    float actualAlignSpeed = CAMERA_AUTO_ALIGN_SPEED;

    if (target->isDriving() && target->getMountedCar()) {
      Car *car = target->getMountedCar();
      speed = std::abs(car->getSpeed());

      float yawDeg = car->getYaw() * 180.0f / 3.14159265f;
      targetYawDeg = 180.0f - yawDeg;

      actualAlignSpeed *= 12.0f; // Significantly faster for cars

    } else {
      // ALIGN TO CHARACTER VELOCITY DIRECTION
      Vec3 vel = target->getVelocity();
      speed = std::sqrt(vel.x * vel.x + vel.z * vel.z);
      targetYawDeg = std::atan2(vel.x, vel.z) * 180.0f / 3.14159265f;
    }

    // Only align if speed is sufficient and user hasn't touched mouse recently
    if (speed > CAMERA_AUTO_ALIGN_THRESHOLD && autoAlignTimer <= 0.0f) {
      float angleDiff = targetYawDeg - angleAroundTarget;
      while (angleDiff > 180.0f)
        angleDiff -= 360.0f;
      while (angleDiff < -180.0f)
        angleDiff += 360.0f;

      float speedFactor =
          glm::clamp((speed - CAMERA_AUTO_ALIGN_THRESHOLD) / 10.0f, 0.0f, 1.0f);
      
      // Use exponential smoothing for better responsiveness
      float smoothing = 1.0f - std::exp(-actualAlignSpeed * speedFactor * dt);
      
      if (std::abs(angleDiff) > 0.1f) {
        angleAroundTarget += angleDiff * smoothing;
      }
    }
  }
}

// ================================================================
// CALCULATE GOAL POSITION
// ================================================================

void Camera::calculateGoalPosition() {
  Vec3 targetPos = target->getPosition();

  float radAngle = angleAroundTarget * 3.14159265f / 180.0f;
  float radPitch = pitch * 3.14159265f / 180.0f;

  float horizontalDistance = distance * cos(radPitch);
  float verticalDistance = distance * sin(radPitch);

  float offsetX = horizontalDistance * sin(radAngle);
  float offsetZ = horizontalDistance * cos(radAngle);

  goalPosition.x = targetPos.x - offsetX;
  goalPosition.y = targetPos.y + verticalDistance;
  goalPosition.z = targetPos.z - offsetZ;

  if (terrainModel) {
    float terrainY = terrainModel->getHeightAt(goalPosition.x, goalPosition.z);
    float minCameraY = terrainY + 0.8f;
    if (goalPosition.y < minCameraY)
      goalPosition.y = minCameraY;
  }
}

// ================================================================
// SMOOTHING & CLAMPING
// ================================================================

void Camera::applySmoothingAndClamp(float dt) {
  Vec3 posForce = (goalPosition - smoothedPosition) * CAMERA_SPRING_STIFFNESS;
  Vec3 posDamping = cameraVelocity * CAMERA_SPRING_DAMPING;
  Vec3 posAccel = (posForce - posDamping) * (1.0f / CAMERA_MASS);
  cameraVelocity += posAccel * dt;
  smoothedPosition += cameraVelocity * dt;

  Vec3 lookAtPoint = target->getPosition();
  lookAtPoint.y += CAMERA_LOOK_HEIGHT;
  Vec3 targetForce = (lookAtPoint - smoothedTarget) * TARGET_SPRING_STIFFNESS;
  Vec3 targetDamp = targetVelocity * TARGET_SPRING_DAMPING;
  Vec3 targetAccel = (targetForce - targetDamp) * (1.0f / CAMERA_MASS);
  targetVelocity += targetAccel * dt;
  smoothedTarget += targetVelocity * dt;

  if (terrainModel) {
    float terrainY =
        terrainModel->getHeightAt(smoothedPosition.x, smoothedPosition.z);
    float minCameraY = terrainY + 1.8f;
    if (smoothedPosition.y < minCameraY) {
      smoothedPosition.y = minCameraY;
      if (cameraVelocity.y < 0)
        cameraVelocity.y = 0.0f;
    }
  }
}

// ================================================================
// ACCESSORS
// ================================================================

Vec3 Camera::getForward() const {
  if (freeCam) {
    float radYaw = freeYaw * 3.14159f / 180.0f;
    float radPitch = freePitch * 3.14159f / 180.0f;
    glm::vec3 front;
    front.x = cos(radYaw) * cos(radPitch);
    front.y = sin(radPitch);
    front.z = sin(radYaw) * cos(radPitch);
    glm::vec3 dir = glm::normalize(front);
    return Vec3(dir.x, dir.y, dir.z);
  }
  Vec3 f = smoothedTarget - smoothedPosition;
  f.normalize();
  return f;
}

Vec3 Camera::getRight() const {
  Vec3 fwd = getForward();
  Vec3 up(0.0f, 1.0f, 0.0f);
  Vec3 r = fwd.cross(up);
  r.normalize();
  return r;
}

Vec3 Camera::getPosition() const {
  return freeCam ? freePos : smoothedPosition;
}

glm::vec3 Camera::getRay(float mx, float my, int w, int h) const {
  float x = (2.0f * mx) / w - 1.0f;
  float y = 1.0f - (2.0f * my) / h;
  glm::vec4 ray_clip = glm::vec4(x, y, -1.0, 1.0);

  glm::mat4 invProj = glm::inverse(
      glm::perspective(glm::radians(45.0f), (float)w / h, 0.1f, 1000.0f));
  glm::vec4 ray_eye = invProj * ray_clip;
  ray_eye = glm::vec4(ray_eye.x, ray_eye.y, -1.0, 0.0);

  glm::mat4 invView = glm::inverse(const_cast<Camera *>(this)->getViewMatrix());
  glm::vec3 ray_world = glm::vec3(invView * ray_eye);
  return glm::normalize(ray_world);
}