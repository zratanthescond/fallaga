#ifndef PHYSICS_SYSTEM_H
#define PHYSICS_SYSTEM_H

#include "Vec3.h"
#include "Terrain.h"
#include "WaterUtils.h"

class PhysicsSystem {
public:
    static constexpr float GRAVITY = -98.1f; // Standard gravity scaled for the world
    
    /**
     * @brief Applies gravity and snaps an entity to the terrain.
     * 
     * @param position Current position (updated)
     * @param velocity Current velocity (updated Y component)
     * @param deltaTime Time since last frame
     * @param terrain Pointer to the terrain for height sampling
     * @param groundOffset Minimum height above terrain (e.g., 0.01f)
     */
    static bool applyGravity(Vec3& position, Vec3& velocity, float deltaTime, const Terrain* terrain, float time, float groundOffset = 0.0f) {
        if (!terrain) return false;

        // 1. Realistic Terminal Velocity (Human in air)
        const float TERMINAL_VELOCITY = -53.0f; // m/s (realistic for a human)
        
        // 2. Apply Gravity to Y Velocity
        velocity.y += GRAVITY * deltaTime;
        if (velocity.y < TERMINAL_VELOCITY) velocity.y = TERMINAL_VELOCITY;

        // 3. DYNAMIC WATER PHYSICS (Bobbing Buoyancy)
        float currentWaveHeight = WaterUtils::getWaveHeight(position.x, position.z, time);
        if (position.y < currentWaveHeight) {
            // Buoyancy: Force proportional to depth below the LOCAL wave height
            float depth = currentWaveHeight - position.y;
            float buoyancy = 180.0f * depth; // Upward acceleration
            velocity.y += buoyancy * deltaTime;

            // Fluid Drag: Slow down everything while in water
            float drag = 0.94f; // Velocity retention factor
            float power = deltaTime * 60.0f;
            velocity.x *= std::pow(drag, power);
            velocity.z *= std::pow(drag, power);
            velocity.y *= std::pow(0.85f, power); // Stronger vertical drag
        }

        // 4. Update Position
        position.y += velocity.y * deltaTime;

        // 5. Collision with REAL ground (underwater or land)
        float terrainHeight = terrain->getHeight(position.x, position.z);
        bool isGrounded = false;

        // RDR2-style "Heavy" grounding: 
        // If we are below the terrain OR very close to it while falling/standing
        float groundThreshold = terrainHeight + groundOffset;
        float snapDistance = 0.2f; // Distance within which we snap to ground if already "grounded"

        if (position.y <= groundThreshold) {
            position.y = groundThreshold;
            velocity.y = 0.0f;
            isGrounded = true;
        } else if (position.y < groundThreshold + snapDistance && velocity.y < 0.1f) {
            // Cling to ground when walking downhill to avoid jittery "micro-falls"
            position.y = groundThreshold;
            velocity.y = 0.0f;
            isGrounded = true;
        }

        return isGrounded;
    }

    /**
     * @brief Instantly snaps an entity to the terrain height. 
     * Useful for spawning buildings or objects that don't move vertically.
     * 
     * @param position Position to snap (updated)
     * @param terrain Pointer to the terrain
     * @param groundOffset Vertical offset from the surface
     */
    static void snapToGround(Vec3& position, const Terrain* terrain, float groundOffset = 0.0f) {
        if (!terrain) return;
        position.y = terrain->getHeight(position.x, position.z) + groundOffset;
    }
};

#endif // PHYSICS_SYSTEM_H
