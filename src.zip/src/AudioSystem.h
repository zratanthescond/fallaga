#ifndef AUDIOSYSTEM_H
#define AUDIOSYSTEM_H

class AudioSystem {
public:
    static AudioSystem& getInstance();

    bool init();
    void cleanup();

    // Set the parameters for the engine sound crossfading/pitching
    void updateEngine(float rpm, float throttle, float maxRpm);
    
    // One-shot events
    void playIgnition();
    void playStop();
    void playHorn();
    void stopHorn();

private:
    AudioSystem();
    ~AudioSystem();

    // Prevent copying
    AudioSystem(const AudioSystem&) = delete;
    AudioSystem& operator=(const AudioSystem&) = delete;

    bool m_initialized;
    
    // miniaudio structs (void* to avoid including miniaudio.h everywhere)
    void* m_engine;
    void* m_soundIdle;
    void* m_soundDriving;
    void* m_soundIgnition;
    void* m_soundStop;
    void* m_soundHorn;
    
    bool m_engineRunning;
};

#endif // AUDIOSYSTEM_H
