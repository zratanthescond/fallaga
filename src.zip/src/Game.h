#pragma once
#include <GL/glew.h>
#include "Character.h"
#include <vector>
#include <stack>
#include "Camera.h"
#include "Terrain.h"
#include "Horse.h"
#include "Car.h"
#include "Sky.h"

class Game {
public:
    Game();
    ~Game();
    void setup(int width, int height);
    void update( float mouseDeltaX, float mouseDeltaY, float mouseScroll);
    void render();
    void keyDown(int key);
    void keyUp(int key);
    void mouseButton(int button, int action, double x, double y);
    
    Camera& getCamera();
    
    // --- FBO Rendering ---
    void setupFBO(int width, int height);
    
private:
    GLuint sceneFBO = 0;
    GLuint sceneColorTex = 0;
    GLuint sceneDepthTex = 0;
    
    Character* player;
    Camera* camera;
    Terrain* terrain;
    Horse* horse;
    Car* car;
    Sky* sky;
    std::vector<Car*> npcCars;
    Car* m_playerNpcCar = nullptr;  // The vehicle the player is currently driving (if any)
    bool editMode;
    int selectedLandmarkIdx; // -1 for global anchor, 0-3 for landmarks
    int windowWidth;
    int windowHeight;
    float sidebarScroll = 0.0f;
    double lastX, lastY;
    bool isRightMouseDown = false;
    bool isShiftDown = false;
    bool isCtrlDown = false;
    std::stack<int> undoStack; // Indices of placed landmarks in SousseMapData::liveLandmarks

    double lastFrameTime;
    double deltaTime;
    double totalTime;
    float lightningIntensity = 0.0f;
    float nextLightningTime = 5.0f;
};
