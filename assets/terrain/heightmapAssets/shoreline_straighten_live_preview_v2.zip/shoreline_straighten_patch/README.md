# Shoreline Straighten tool patch

This patch adds editor tool **8 — Straighten Shoreline** to the supplied C++/OpenGL project.

## Use
1. Enter Terrain Sculpt mode.
2. Choose **8 Straighten Shoreline** in the left panel.
3. Click the first shoreline endpoint, then click the second endpoint.
4. The current brush radius is used as the preview/blend width on both sides; the current `waterLevelAdjust` is used as sea level. After the first click, move the mouse to see a live yellow centerline with dark outline, green fixed endpoint, orange live endpoint, and cyan width guides. Click again to apply.

## Implementation
- `TerrainManager::straightenShoreline(...)` operates on the visual heightfield, edits only the corridor between the endpoints, blends toward a beach/seabed profile around the configured water level, and calls the existing `finalizeSculpt()` path to synchronize physics/native heights, GPU heightmap texture, and terrain chunks.
- `Game.cpp` captures two terrain clicks, draws the live guide overlay without modifying the terrain during mouse movement, invokes the operation on the second click, and refreshes the water map.
- `GameEditorUtils.h` expands the sculpt tool list from seven to eight entries.

## Important limitations
- This is an initial integration patch, not a verified full-project build; compile and test it in the engine before use.
- The selected segment must be clicked on the terrain at the desired shoreline. Because the heightfield is discrete, the visible waterline can be approximately straight at the terrain grid's resolution rather than mathematically exact between every vertex.
- The current deformation method shifts terrain heights in a corridor toward the configured water level based on the sampled height along the reference line. It can still produce undesirable results on complex coastlines; inspect the result on a backup terrain. The preview itself does not modify terrain.
- The current width control is the existing brush-radius slider and applies equally to both sides. Undo integration was not added because no undo API was identified in the inspected files.


## Shoreline algorithm correction

The shoreline height correction was revised after testing revealed that the previous algorithm imposed an invented fixed slope on both sides of the line. The revised method samples the original height along the selected segment, corrects that projected height to the configured water level, and fades only that vertical correction laterally using smoothstep. Original terrain heights are sampled from an immutable snapshot to avoid order-dependent changes.

This reduces unwanted flattening, but it is not a substitute for testing in the full engine. Pick endpoints that lie on the intended waterline and start with a modest width. Back up the terrain before applying it.

## Live preview update

The in-world preview is drawn after the scene using immediate-mode OpenGL with depth testing disabled for visibility over dark water and pale sand. The code restores depth, lighting, blending enable state, line width, and point size after drawing. This overlay has not been compiled against the complete project in this environment.
