# Brush feel upgrade — integration guide

This patch extends the existing SculptTools API without changing tool IDs or existing function signatures.

## New brush controls

`BrushParams` now includes:

- `falloff`: `SculptTools::FalloffMode::Smooth` (default), `Linear`, `Spherical`, or `Constant`.
- `hardness`: 0.0 is a soft full-radius gradient; values such as 0.65–0.85 create a broad full-strength core and a narrower soft rim.

Example:

```cpp
bp.falloff = SculptTools::FalloffMode::Smooth;
bp.hardness = 0.25f; // soft terrain shaping
// For a sharper raise/lower brush:
bp.falloff = SculptTools::FalloffMode::Constant;
bp.hardness = 0.0f;
```

Falloff is now shared by Raise, Lower, Smooth, and Angle Slope. Erosion remains simulation-driven; applying a radial falloff to erosion would require changing droplet influence/erosion deposition behavior rather than only changing the brush edge.

## Continuous strokes

Use `sampleStroke()` for each pointer segment in world X/Z coordinates. A spacing fraction of `0.2f` places brush centers at no more than 20% of the brush radius apart, reducing gaps during fast mouse movement.

```cpp
auto points = SculptTools::sampleStroke(previousX, previousZ,
                                        currentX, currentZ,
                                        bp.radius, 0.2f);
for (const auto& point : points) {
    bp.wx = point.wx;
    bp.wz = point.wz;
    SculptTools::apply(hf, activeToolId, bp);
}
```

Important: this is an integration example, not a complete frame-loop drop-in. To avoid double application, skip the first sample after the first segment or retain the last emitted sample. Also use a fixed per-sample strength/time budget: calling the existing `apply()` with the full frame `dt` for every interpolated point multiplies strength as spacing gets smaller. A proper editor stroke should distribute the frame's time/strength across generated samples, and gather/union the returned `IntBox` values before rebuilding chunks.

## Notes / limitations

- This is an algorithm/API patch based on the supplied SculptTools excerpt. `SculptPanel.cpp` and the real `TerrainManager` implementation were not available, so controls are not yet wired into the UI.
- Existing defaults preserve the previous smooth-falloff style. New fields have defaults, so existing `BrushParams` construction continues to compile.
- The `Constant` mode is intentionally hard-edged and can create visible seams; use it for blockout, not as the default production brush.
- Erosion still needs its own persistent seed and modified-bounds tracking in a later integration pass.
