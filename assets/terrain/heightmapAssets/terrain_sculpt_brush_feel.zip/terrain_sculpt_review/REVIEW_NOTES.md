# Terrain sculpting review — first-pass compatible patch

## Scope
This patch is based only on the supplied `SculptTools.h` / `SculptTools.cpp` excerpt. `TerrainManager.cpp`, `TerrainManager.h`, `SculptPanel.cpp`, and the real `TerrainRefinement.h` were not uploaded, so integration-specific behavior has not been verified. Tool IDs and the public brush signatures are preserved.

## Changes
- Validate heightfield dimensions, vector capacity, finite world bounds, and height range before grid math or brush writes.
- Make footprint bounds use separate X/Z world-to-grid scales and floor/ceil so boundary samples aren't accidentally omitted.
- Raise/lower and smooth use world-space distance, avoiding stretched brushes on non-square terrain mappings.
- Smooth copies only the brush region plus the one-sample kernel border, rather than duplicating the whole heightmap every frame.
- Clamp smoothing falloff and blend factors; cap per-call dt to reduce large frame-spike jumps.
- Local erosion droplet sampling is area-uniform (`sqrt(random) * radius`) instead of clustering toward the center.
- Remove heap allocations from the inner erosion loop by using fixed-size arrays for the radius-3 kernel.
- Guard invalid erosion inputs and cap the per-frame droplet request at 50,000.

## Compatibility / caveats
- Existing public function signatures and brush IDs 1–5 remain unchanged; tool 6 and 7 routing remains external / refinement-backed.
- Strength response changes slightly because `dt` is capped at 0.1 seconds for raise/lower and smooth. Test this against your editor's chosen strength scale.
- Erosion remains deterministic per call because its seed is still reset to 1337. A persistent seed / replay control requires a deliberate API addition and editor integration.
- `apply()` still returns the brush footprint for erosion. Droplets can travel beyond that box, so `TerrainManager` must rebuild a conservative erosion region or the erosion API should be extended to return the true modified bounds. This cannot be fixed safely in `TerrainManager` without its full implementation.
- This patch has not been compiled against your project because the real `TerrainRefinement.h` and project build configuration were not provided.

## Next integration review
Please include the actual `TerrainManager.cpp`, `TerrainManager.h`, `SculptPanel.cpp`, and `TerrainRefinement.h` (or the project ZIP) to validate physics mirroring, texture uploads, chunk rebuild bounds, UI parameter ranges, undo/redo, and the fine-grid mirror.
